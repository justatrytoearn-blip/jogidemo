FIREWALL RULE INTELLIGENCE - DEMO IMPORT FILES
All values are fictional. The headers match the customer POC files.

Import in this order on the portal File Upload Centre:
  1. 1_Firewall_Rule_Inventory_DEMO.xlsx   (60 rules + 4 Section rows + change relationship sheet)
  2. 2_ServiceNow_Change_Tasks_DEMO.xlsx    (51 change tasks)
  3. 3_Firewall_Logs_DEMO.xlsx              (3,585 events over 330 days)

Confirm the automatic column mapping, then click Upload & Analyse.

Expected after analysis: 23 KEEP / 37 REVIEW / 0 DISABLE / 0 DELETE.
The demo dataset also qualifies 6 rules for DISABLE and 4 for DELETE;
those appear when the labelled demo approvals are recorded. The n8n 'demo'
prompt applies those fixtures automatically and ends at:
  23 KEEP / 27 REVIEW / 6 DISABLE / 4 DELETE

No firewall is changed by this platform. DISABLE and DELETE always require
recorded human approval.
