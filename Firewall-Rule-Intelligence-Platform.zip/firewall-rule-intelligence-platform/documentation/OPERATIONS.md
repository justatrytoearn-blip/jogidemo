# Operations guide

## Daily use

1. `start.bat` - starts the API and opens the portal.
2. Upload the current rule inventory, change records and logs (or confirm existing uploads).
3. Start an analysis with a clear label, for example `2026-11 weekly review`.
4. Review the dashboard, filter the rule list by REVIEW/DISABLE/DELETE and open rule details.
5. Record approvals and disable evidence where they exist; the rule re-evaluates immediately.
6. Export the report set, compare with the previous run, and take decisions through ServiceNow.

## Files and locations

| Path | Contents |
| --- | --- |
| `uploads/firewall_rules`, `uploads/change_records`, `uploads/firewall_logs` | Original uploads (never overwritten) |
| `processed/` | Gzipped normalised JSONL caches, safe to delete (rebuilt on demand) |
| `reports/` | Generated Excel/PDF files |
| `database/fip.db` | SQLite database (WAL mode) |
| `config/settings.json` | Settings-page overrides |
| `config/n8n_api_key.txt` | API key for n8n (generated) |
| `config/admin_credentials.txt` | Bootstrap login, generated only when auth is enabled |
| `logs/server.log` | Uvicorn output |
| `logs/platform.log` | Application log |

## Backup

Stop the API (`stop.bat`), then copy `database/fip.db` and `uploads/`. Reports and `processed/` can
be regenerated. Restore by placing the files back and starting the API.

## Changing the policy

Use the Settings page. The policy is captured into each new run; existing runs keep their original
policy so historical reports remain reproducible. To change defaults for fresh installations, edit
`DEFAULT_POLICY` in `backend/config.py` or `config/default_policy.json`.

## n8n operations

```bash
docker compose -f n8n/docker-compose.yml up -d      # start
docker compose -f n8n/docker-compose.yml stop       # stop
docker logs fip-n8n --tail 100                      # inspect
docker exec fip-n8n n8n list:workflow               # confirm active workflows
```

Rebuild workflow JSON after editing `n8n/build_workflows.py`:

```bash
python n8n/build_workflows.py
docker exec fip-n8n n8n import:workflow --separate --input=/workflows
docker exec fip-n8n n8n update:workflow --id=fip-wf-01 --active=true
docker restart fip-n8n
```

The container only binds to `127.0.0.1:5679`; an existing n8n on 5678 is untouched.

## Removing test runs

```bash
python scripts/cleanup_runs.py <run_id> [run_id ...]
```

Deletes the run and its rules, metrics, recommendations, approvals, evidence, links, change records
and report rows. Uploaded files and generated report files remain on disk.

## Health checks

```bat
health_check.bat
```

Checks: API health JSON, portal HTTP status, n8n health endpoint, Ollama tags, container status and
database size. `/api/health` also reports the configured local model and whether the n8n key and
auth are configured.

## Troubleshooting matrix

| Symptom | Check | Action |
| --- | --- | --- |
| Port 8080 in use | `netstat -ano \| findstr 8080` | `stop.bat`, or stop the conflicting process |
| API exits on start | `logs/server.log` | Missing dependency → `setup.bat`; DB locked → stop other instance |
| n8n webhook 404 | `docker ps`, `n8n list:workflow` | Start container and activate workflows |
| n8n 502 | `docker exec fip-n8n wget -qO- http://host.docker.internal:8080/api/health` | Start the API; keep it on 127.0.0.1 |
| AI disabled | `/api/health` `ai.available` | Start Ollama, pull the configured model |
| AI validation failures | Rule detail D section | Inspect caveats; regenerate; deterministic text remains |
| All REVIEW | Run stats traffic identity space | Confirm logs belong to the same firewall estate |
| Reports missing | Reports page, `reports/` | Generate again after the run completes |
| Slow analysis | `stats.traffic` timing, log size | Increase `FIP_CHUNK_SIZE` only with enough RAM |

## Upgrade / restart

Frontend and backend are served by one process. If you rebuild `frontend/dist`, restart the API so
the static mount picks up new assets. Python changes require a restart; policy and settings changes
do not.
