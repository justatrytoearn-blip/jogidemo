# Recommendation rules

The engine is deterministic. AI narration may explain a decision but can never change it.

## Gates

### KEEP
All of the following:

- matching log events in the observation window ≥ `min_keep_events`;
- log coverage ≥ `min_log_coverage_days` and the logs share the inventory identity space;
- last matching event no older than `last_hit_age_threshold_days`;
- at least one linked change record that is documented (state + description);
- a known owner (inventory field or change assignee);
- expiry is not in the past;
- no conflicting change information.

### REVIEW (safe default)
Used when any evidence is missing: no usable logs, short coverage, no change record, undocumented
change, unknown owner, missing source/destination/hit data, unknown or expired validity, conflicting
records, or when a rule qualifies for DISABLE/DELETE but approvals or monitoring evidence are
outstanding. The rule detail lists the exact missing-evidence codes.

### DISABLE
All of the following:

- trustworthy traffic evidence (identity space shared, coverage sufficient);
- zero matching events across the full observation window;
- last matching event at least `last_hit_age_threshold_days` ago;
- business confirmation recorded (`business_confirmation` approval);
- no conflicting change information.

### DELETE
All of the following:

- everything required for DISABLE;
- a completed disable-and-monitor period (`disable_monitoring_days`) with no traffic after
  `disabled_at`;
- deletion approval (`delete_approval`);
- obsolescence confirmation (`obsolescence_confirmation`).

## Safety properties enforced by tests

1. Zero traffic alone never escalates to DISABLE or DELETE.
2. No usable log evidence yields REVIEW, even when the inventory hit counter is zero or blank.
3. A log file that shares no rule identifiers with the inventory never becomes "no traffic"
   evidence.
4. DISABLE without business confirmation stays REVIEW (marked eligible, approval pending).
5. DELETE without completed monitoring or approvals stays below DELETE.
6. Traffic after disabling blocks DELETE.
7. An expired rule is never KEEP.
8. Similar rule names are never merged; ambiguous identifiers produce no match and an explanation.

## Risk and confidence

Risk reflects blast radius and evidence quality (for example any-traffic rules, broad services,
unknown owner). Confidence reflects match method (UID 1.0, number+device 0.95, number 0.8-0.85,
name+device 0.7, name 0.6) and whether the evidence set is complete. Both are explanatory; they do
not override the gates.

## Approval workflow

Approvals are evidence records: `business_confirmation`, `delete_approval`,
`obsolescence_confirmation`, plus review decisions recorded from the rule list. Disable evidence
records `disabled_at`, `monitored_until` and the change reference. Recording evidence triggers
re-evaluation of that rule; it never contacts a firewall.

## Policy defaults

| Setting | Default |
| --- | --- |
| Observation window | 90 days |
| Last-hit threshold | 180 days |
| Post-disable monitoring | 30 days |
| Minimum log coverage | 30 days |
| Minimum events for KEEP | 1 |
| Business approval for DISABLE | required |
| Delete approval / obsolescence | required |
| Disabled+monitored evidence for DELETE | required |
| Expiry unknown forces REVIEW | false |
