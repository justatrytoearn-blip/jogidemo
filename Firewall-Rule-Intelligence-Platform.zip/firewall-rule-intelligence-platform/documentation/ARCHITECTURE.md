# Architecture

```
                        +--------------------------------------+
  Browser  -----------> |  FastAPI (127.0.0.1:8080)             |
                        |  - React SPA from frontend/dist      |
                        |  - REST /api/* and /api/n8n/*        |
                        +------+---------------+---------------+
                               |               |
                    SQLAlchemy |               | httpx (aggregated evidence only)
                               v               v
                        +-------------+   +----------------------+
                        |  SQLite     |   |  Ollama (local)      |
                        |  fip.db     |   |  qwen2.5:1.5b        |
                        +-------------+   +----------------------+

  Files: uploads/ (originals) -> processed/ (normalised JSONL)
         logs streamed in chunks -> aggregates only
         reports/ (xlsx, pdf)
```

## Backend modules

| Module | Responsibility |
| --- | --- |
| `backend/api/*` | HTTP surface: uploads, runs, rules, dashboard, reports, settings, auth, n8n |
| `backend/services/import_service.py` | Store upload, validate, choose sheet, map columns, preview, normalise, cache |
| `backend/services/file_reader.py` | xlsx/csv reading, chunked iteration, checksums, templates |
| `backend/services/column_mapper.py` | Canonical fields, synonyms, confidence scoring |
| `backend/services/normalize.py` | Section-heading detection, dates, hit counters, actions, services |
| `backend/services/correlation.py` | Rule identity index, strict matching, change linking and summaries |
| `backend/analytics/traffic.py` | Chunked log streaming, per-rule metrics, identity-space/absence evidence |
| `backend/recommendation_engine/*` | Deterministic gates, risk/confidence, triggers, missing evidence |
| `backend/services/analysis.py` | Run orchestration, persistence, re-evaluation, rule context |
| `backend/jobs/runner.py` | Background job execution with progress and audit |
| `backend/services/ai_jobs.py` | Batch/single local narration, validation |
| `backend/ai/*` | Ollama client and evidence-only prompt/validation |
| `backend/reports/*` | Report datasets, Excel, PDF, ad-hoc exports |
| `backend/services/comparison.py` | Run-to-run comparison |

## Run-scoped data model

`Run` owns `Rule`, `ChangeRecord`, `RuleChangeLink`, `TrafficMetric`, `Recommendation`,
`Approval`, `DisableEvidence`, `LogDailyStat`, `Report`, `Job` and `Comparison`. Keeping every
analysis separate preserves history, makes comparisons meaningful and lets old runs keep the
policy they were evaluated with. Uploads are shared and never overwritten; replacements are
linked through `is_replacement_of`.

## Processing flow

1. **Upload** - checksum, validate extension/size, detect sheet and header row, score candidate
   sheets, map columns, store original. Manual mapping can override.
2. **Confirm mapping** - normalise rows, detect and skip section headings, persist rules/changes,
   extract change links found in the relationship sheet and rule comments, cache gzipped JSONL.
3. **Analysis job** - load normalised rules and changes, build the identity index, link change
   records, stream logs in chunks (default 200k rows), aggregate per-rule metrics, evaluate every
   rule, persist recommendations and run statistics, optionally queue AI narration.
4. **Review** - filters, detail, approvals, disable evidence, re-evaluation after evidence changes.
5. **Reporting** - Excel/PDF from the persisted dataset, with the policy and source traceability.

## Traffic evidence model

`TrafficMetric` distinguishes four different situations so absence is never over-interpreted:

- `logs_supplied = false` - no log file: no evidence of inactivity.
- logs supplied but `identity_space_ok = false` - the file shares no rule identity with the
  inventory (for example a different firewall): absence is not evidence.
- logs supplied and identity space shared, coverage below `min_log_coverage_days` - insufficient
  observation: absence is not evidence.
- identity space shared and coverage sufficient - zero events in the window is usable evidence.

`absence_is_evidence` records this decision per metric. `window_event_count` is computed from
actual log timestamps, not the inventory hit counter.

## Frontend

React 19 + TypeScript, Vite build, React Router, Recharts. A run selector in the header scopes
all pages. API state is fetched through `src/api.ts`; types mirror the API schemas. The FastAPI
app serves `frontend/dist` with SPA fallback, so one process hosts UI and API.

## Scalability

- Logs are streamed in chunks and never persisted row-by-row.
- Rules and changes are cached as gzipped JSONL after import.
- Database writes are batched per chunk; indexes cover run, rule and category filters.
- Server-side pagination keeps the rule grid responsive.
- Designed for 100k rules and 5-10M log rows; the supplied 76,925-event run completes in about
  four seconds on this CPU-only host.

## Security posture

- Binds to 127.0.0.1 by default; no inbound firewall change is required.
- Upload validation (type, size, sheet structure), checksum duplicate detection, path checks for
  n8n folder ingestion.
- Optional local auth with generated bootstrap password; hashed passwords, session tokens.
- Audit log for uploads, runs, approvals, reports, settings and n8n calls.
- The LLM receives aggregated evidence only and cannot alter the recommendation.
- No hardcoded credentials; n8n key and admin password are generated locally.
