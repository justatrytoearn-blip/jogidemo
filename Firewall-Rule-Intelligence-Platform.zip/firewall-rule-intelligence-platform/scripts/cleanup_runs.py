"""Delete analysis runs and every row that belongs to them.

Used to remove duplicate/failed runs created during testing. Uploads, audits and the
downloaded report files are intentionally left untouched (raw uploads are never deleted
by the platform).

Usage: python scripts/cleanup_runs.py 3 4
"""
from __future__ import annotations

import sys

from sqlalchemy import delete, select

from backend.database.db import init_db, session_scope
from backend.database.models import (
    Approval,
    ChangeRecord,
    DisableEvidence,
    Job,
    LogDailyStat,
    Recommendation,
    Report,
    Rule,
    RuleChangeLink,
    Run,
    TrafficMetric,
)

RUN_SCOPED = (Approval, ChangeRecord, DisableEvidence, Job, LogDailyStat, Recommendation, Report, Rule, RuleChangeLink, TrafficMetric)


def cleanup(run_ids: list[int]) -> dict[str, int]:
    init_db()
    removed: dict[str, int] = {}
    with session_scope() as db:
        existing = db.execute(select(Run.id).where(Run.id.in_(run_ids))).scalars().all()
        if not existing:
            return removed
        for model in RUN_SCOPED:
            result = db.execute(delete(model).where(model.run_id.in_(existing)))
            removed[model.__tablename__] = result.rowcount or 0
        result = db.execute(delete(Run).where(Run.id.in_(existing)))
        removed["runs"] = result.rowcount or 0
    return removed


if __name__ == "__main__":
    ids = [int(arg) for arg in sys.argv[1:]]
    if not ids:
        raise SystemExit("usage: python scripts/cleanup_runs.py <run_id> [run_id ...]")
    print(cleanup(ids))
