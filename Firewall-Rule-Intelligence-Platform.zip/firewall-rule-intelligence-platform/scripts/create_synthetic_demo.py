"""Build a clearly-labelled SYNTHETIC demonstration run covering all four recommendations.

1. Generates synthetic logs keyed to the real inventory UIDs.
2. Uploads the real inventory, the real change tasks and the synthetic logs (marked synthetic).
3. Runs the analysis.
4. Records demonstration approvals / disable evidence so KEEP, REVIEW, DISABLE and DELETE
   are all represented. These approvals are test fixtures for the synthetic run only.

Usage: python scripts/create_synthetic_demo.py [--ai] [--reset]
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from sqlalchemy import select  # noqa: E402

from backend.database.db import init_db, session_scope  # noqa: E402
from backend.database.models import (  # noqa: E402
    Approval,
    DisableEvidence,
    Recommendation,
    Rule,
    Run,
    TrafficMetric,
)
from backend.services import import_service  # noqa: E402
from backend.services.analysis import create_run, execute_run, reevaluate_rule  # noqa: E402


def upload(db, dataset_type: str, path: str, synthetic: bool):
    with open(path, "rb") as fh:
        up = import_service.create_upload(db, dataset_type, Path(path).name, fh, is_synthetic=synthetic)
    stored = json.loads(up.mapping_json or "{}")
    mapping = {k: v for k, v in stored.get("mapping", {}).items() if v}
    return import_service.confirm_mapping(db, up.id, mapping, up.sheet_name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ai", action="store_true", help="also generate AI narration (slow on CPU)")
    args = parser.parse_args()

    log_path = ROOT / "samples" / "synthetic" / "synthetic_firewall_logs.csv"
    if not log_path.exists():
        subprocess.check_call([sys.executable, str(ROOT / "scripts" / "generate_synthetic_logs.py")])

    init_db()
    with session_scope() as db:
        rules = upload(db, "rules", str(ROOT / "samples" / "firewall_rule_list_POC_200_Rules.xlsx"), False)
        changes = upload(db, "changes", str(ROOT / "samples" / "change_task_POC_200_Entries.xlsx"), False)
        logs = upload(db, "logs", str(log_path), True)
        run = create_run(db, rules.id, changes.id, logs.id, "SYNTHETIC demonstration run", ai_enabled=args.ai)
        run_id = run.id
    print(f"run id: {run_id}")
    stats = execute_run(run_id)
    print("initial:", json.dumps({k: stats[k] for k in ("keep", "review", "disable", "delete", "matched_rules")}))

    now = datetime.utcnow()
    with session_scope() as db:
        rows = db.execute(
            select(Rule, Recommendation, TrafficMetric)
            .join(Recommendation, Recommendation.rule_id == Rule.id)
            .join(TrafficMetric, TrafficMetric.rule_id == Rule.id)
            .where(Rule.run_id == run_id)
            .order_by(Rule.id)
        ).all()
        dormant = [r for r, rec, m in rows if m.matched and m.window_event_count == 0 and m.days_since_last_hit and m.days_since_last_hit >= 180]
        silent = [r for r, rec, m in rows if not m.matched and m.absence_is_evidence]

        confirmed = 0
        for rule in dormant[:15]:
            db.add(Approval(run_id=run_id, rule_id=rule.id, kind="business_confirmation", approved_by="demo.owner@example.com", note="Synthetic demo approval - owner confirms rule is no longer required", source="synthetic_demo"))
            confirmed += 1
        deleted = 0
        for rule in silent[:6]:
            db.add(DisableEvidence(run_id=run_id, rule_id=rule.id, disabled_at=now - timedelta(days=75), monitored_until=now - timedelta(days=10), change_reference="CHG_SYNTHETIC_DEMO", note="Synthetic demo: disabled and monitored without traffic", source="synthetic_demo"))
            db.add(Approval(run_id=run_id, rule_id=rule.id, kind="delete_approval", approved_by="demo.owner@example.com", note="Synthetic demo deletion approval", source="synthetic_demo"))
            db.add(Approval(run_id=run_id, rule_id=rule.id, kind="obsolescence_confirmation", approved_by="demo.owner@example.com", note="Synthetic demo obsolescence confirmation", source="synthetic_demo"))
            deleted += 1
        db.commit()

        touched = [r.id for r in dormant[:15]] + [r.id for r in silent[:6]]
        for rule_id in touched:
            reevaluate_rule(db, rule_id)

        counts: dict[str, int] = {}
        for (cat,) in db.execute(select(Recommendation.category).where(Recommendation.run_id == run_id)).all():
            counts[cat] = counts.get(cat, 0) + 1
        run = db.get(Run, run_id)
        stats = json.loads(run.stats_json or "{}")
        stats.update({"keep": counts.get("KEEP", 0), "review": counts.get("REVIEW", 0), "disable": counts.get("DISABLE", 0), "delete": counts.get("DELETE", 0)})
        stats["synthetic_approvals"] = {"business_confirmation": confirmed, "delete_candidates": deleted}
        stats["synthetic_warning"] = "Logs and approval records in this run are SYNTHETIC test fixtures, not customer decisions."
        run.stats_json = json.dumps(stats, default=str)
        db.commit()

    print("final counts:", json.dumps(counts))
    print(f"Open the portal and select run #{run_id}. This run is flagged SYNTHETIC.")

    if args.ai:
        from backend.services import ai_jobs

        result = ai_jobs.generate_for_run(run_id)(lambda p, m: print(f"  {p}% {m}"))
        print(result)


if __name__ == "__main__":
    main()
