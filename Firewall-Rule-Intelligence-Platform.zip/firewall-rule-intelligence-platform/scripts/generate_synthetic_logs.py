"""Generate clearly-labelled SYNTHETIC firewall logs for testing the platform.

The rows are derived from the real inventory (rule UIDs/numbers/names) so the
matching engine can be validated end to end. They are always imported with
is_synthetic=True and are never mixed into a customer analysis run.

Usage: python scripts/generate_synthetic_logs.py [--rules PATH] [--out PATH] [--seed 42]
"""
from __future__ import annotations

import argparse
import csv
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_RULES = ROOT / "samples" / "firewall_rule_list_POC_200_Rules.xlsx"
DEFAULT_OUT = ROOT / "samples" / "synthetic" / "synthetic_firewall_logs.csv"

SERVICES = [("tcp_443", 443, "TCP"), ("tcp_80", 80, "TCP"), ("tcp_8080", 8080, "TCP"), ("tcp_22", 22, "TCP"), ("udp_53", 53, "UDP"), ("tcp_3389", 3389, "TCP")]


def load_rules(path: Path) -> list[dict]:
    df = pd.read_excel(path, sheet_name="FW-Corp 11")
    df = df[df["Type"].astype(str).str.strip() == "Rule"]
    section = ""
    rules = []
    for _, row in pd.read_excel(path, sheet_name="FW-Corp 11").iterrows():
        if str(row.get("Type")).strip() == "Section":
            section = str(row.get("Hits") or "").strip()
            continue
        if str(row.get("Type")).strip() != "Rule":
            continue
        rules.append(
            {
                "number": str(row.get("Rule Number")),
                "name": str(row.get("Name") or ""),
                "uid": str(row.get("Uid") or ""),
                "action": str(row.get("Action") or "Accept"),
                "section": section,
            }
        )
    return rules


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rules", default=str(DEFAULT_RULES))
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--active", type=int, default=140)
    parser.add_argument("--dormant", type=int, default=25)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    rules = load_rules(Path(args.rules))
    if not rules:
        raise SystemExit("No rules found in inventory")
    rules = sorted(rules, key=lambda r: int(r["number"]) if r["number"].isdigit() else 0)
    active = rules[: args.active]
    dormant = rules[args.active: args.active + args.dormant]
    silent = rules[args.active + args.dormant:]

    now = datetime.now().replace(microsecond=0)
    rows: list[dict] = []

    def emit(rule: dict, ts: datetime, src: str, dst: str, port: int, proto: str, svc: str) -> None:
        rows.append(
            {
                "Time": ts.strftime("%Y-%m-%d %H:%M:%S"),
                "Machine Name": "synthetic-fw-01",
                "Rule": rule["number"],
                "Policy Rule UID": rule["uid"],
                "Access Rule Name": rule["name"],
                "Source": src,
                "Destination": dst,
                "security_inzone": "InternalZone",
                "Destination Zone": "External",
                "Destination Port": port,
                "Protocol": proto,
                "Action": rule["action"],
                "Bytes": rng.randint(64, 5_000_000),
                "Packets": rng.randint(1, 4000),
                "Service": svc,
                "Synthetic": "YES",
            }
        )

    for rule in active:
        n = rng.randint(120, 900)
        for _ in range(n):
            ts = now - timedelta(days=rng.randint(0, 59), hours=rng.randint(0, 23), minutes=rng.randint(0, 59))
            svc, port, proto = SERVICES[rng.randrange(len(SERVICES))]
            emit(rule, ts, f"10.{rng.randint(1, 60)}.{rng.randint(1, 250)}.{rng.randint(1, 250)}", f"172.{rng.randint(16, 31)}.{rng.randint(0, 20)}.{rng.randint(1, 250)}", port, proto, svc)
        # Guarantee a very recent event so KEEP is supportable.
        svc, port, proto = SERVICES[0]
        emit(rule, now - timedelta(hours=rng.randint(1, 20)), f"10.{rng.randint(1, 60)}.1.10", "172.16.10.10", port, proto, svc)

    for rule in dormant:
        last = now - timedelta(days=rng.randint(200, 330))
        n = rng.randint(15, 90)
        for _ in range(n):
            ts = last + timedelta(days=rng.randint(0, 5), hours=rng.randint(0, 23))
            svc, port, proto = SERVICES[rng.randrange(len(SERVICES))]
            emit(rule, ts, f"10.{rng.randint(1, 60)}.{rng.randint(1, 250)}.{rng.randint(1, 250)}", "172.16.40.5", port, proto, svc)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    manifest = {
        "synthetic": True,
        "warning": "SYNTHETIC TEST DATA - not customer traffic. Never combine with production analysis.",
        "generated_at": now.isoformat(),
        "seed": args.seed,
        "rules_total": len(rules),
        "rules_with_recent_activity": len(active),
        "rules_dormant": len(dormant),
        "rules_with_no_events": len(silent),
        "events": len(rows),
        "date_range": {
            "min": min(r["Time"] for r in rows),
            "max": max(r["Time"] for r in rows),
        },
        "source_inventory": str(args.rules),
    }
    (out.parent / "synthetic_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k: manifest[k] for k in ("events", "rules_with_recent_activity", "rules_dormant", "rules_with_no_events", "date_range")}, indent=2))
    print(f"written: {out}")


if __name__ == "__main__":
    main()
