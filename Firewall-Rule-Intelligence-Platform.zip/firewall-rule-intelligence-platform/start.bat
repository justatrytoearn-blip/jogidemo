@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "PYTHONPATH=%CD%"
title Firewall Rule Intelligence Platform

echo ============================================================
echo  Firewall Rule Intelligence Platform - starting
echo ============================================================

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Python virtual environment not found.
  echo         Run setup.bat once to install dependencies.
  pause
  exit /b 1
)

netstat -ano | findstr /R /C:"127.0.0.1:8080 .*LISTENING" >nul 2>&1
if errorlevel 1 (
  if not exist "logs" mkdir "logs"
  echo [1/3] Starting API on http://127.0.0.1:8080 ...
  start "FIP API" /min cmd /c ""%CD%\.venv\Scripts\python.exe" -m uvicorn backend.main:app --host 127.0.0.1 --port 8080 >> "%CD%\logs\server.log" 2>&1"
) else (
  echo [1/3] API already running on port 8080.
)

set "READY=0"
for /l %%i in (1,1,30) do (
  if "!READY!"=="0" (
    curl -s -o nul http://127.0.0.1:8080/api/health >nul 2>&1
    if not errorlevel 1 set "READY=1"
    if "!READY!"=="0" ping -n 2 127.0.0.1 >nul
  )
)

where docker >nul 2>&1
if errorlevel 1 (
  echo [2/3] Docker not installed - n8n orchestration skipped ^(portal works without it^).
) else (
  docker info >nul 2>&1
  if errorlevel 1 (
    echo [2/3] Docker is installed but not running - n8n orchestration skipped.
  ) else (
    docker compose -f "n8n\docker-compose.yml" up -d >nul 2>&1
    echo [2/3] n8n orchestration ensured at http://127.0.0.1:5679
  )
)

if "!READY!"=="1" (
  echo [3/3] Portal ready: http://127.0.0.1:8080
  start "" http://127.0.0.1:8080
) else (
  echo [ERROR] The API did not become healthy within 30 seconds.
  echo         Check logs\server.log for details.
  pause
  exit /b 1
)

echo.
echo Leave this window open while you use the portal, or close it - the server
echo keeps running in its own minimised window. Use stop.bat to shut it down.
echo.
