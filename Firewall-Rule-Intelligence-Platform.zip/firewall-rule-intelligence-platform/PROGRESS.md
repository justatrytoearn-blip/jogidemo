# Build progress

Last updated: 2026-11-13

| Phase | Scope | Status |
| --- | --- | --- |
| 1 | Environment discovery, sample workbook inspection, dependency detection | Complete |
| 2 | Backend: import, column mapping, normalisation, correlation, traffic analytics | Complete |
| 3 | Recommendation policy engine, approvals, AI narration, reports | Complete |
| 4 | React portal (dashboard, uploads, rules, detail, runs, reports, settings) | Complete |
| 5 | n8n orchestration (six workflows, dedicated container) | Complete |
| 6 | Automated tests (parsing, matching, policy, pipeline, reports, API) | Complete |
| 7 | Deployment scripts, documentation, final verification | Complete |

## Verified working

- Real inventory import: 200 rules, 6 section headings skipped, 400 change records, 400 links.
- Real log workbook: 2,000 rows scanned, 0 matched (different rule identity space), 200 REVIEW - honest outcome, absence not treated as evidence.
- Synthetic log workbook: 76,925 events, all matched, 330-day coverage; final demo run has KEEP/REVIEW/DISABLE/DELETE populated (see run #2).
- Recommendations are deterministic; zero traffic alone never produces DISABLE or DELETE.
- Local Ollama narration with contradiction validation (model cannot change the category or invent IPs).
- Excel/PDF reports for all kinds; the complete review sheet carries the full 28+ column traceability set.
- n8n: 6 workflows imported and active in a dedicated container on port 5679; every webhook executed successfully against the API.
- Test suite: 38 tests pass in ~16 seconds against a temporary database (`pytest -q`), including independent recomputation of all 200 rules' traffic counts.
- Dashboard: 14 clickable metrics and 8 charts, all computed from the selected run.
- Deployment: cold `start.bat` verified (API + n8n + browser), `stop.bat`, `health_check.bat` verified live.
- AI batch on the synthetic run: 52 of 60 non-KEEP rules narrated and validated; the remaining rules keep deterministic explanations.
- Reports: 22 files generated for the demo run, including the complete review workbook with the full traceability column set.

### Customer package additions

- Single n8n workflow `FIP - 00 Full Review (one prompt)` (form + webhook) now runs ingest → correlate → traffic → AI → reports and returns counts/links. Verified live: run 7, 60 rules, 23 KEEP / 27 REVIEW / 6 DISABLE / 4 DELETE, 18 reports.
- Per-rule **Accept** button on the rule list and **Accept recommendation** on rule detail; stored as `review_accepted` in the audit trail without changing the policy category. Verified live.
- Model switching in Settings: installed-model list, custom name, Refresh, test-before-save, plus per-run `model:` in the n8n prompt. Verified with `qwen2.5:0.5b`.
- Fictional demo dataset with the customer's exact headers: 60 rules, 51 changes, 3,585 log events, all recommendation and blocker combinations, labelled demo fixtures for DISABLE/DELETE. Verified end-to-end.
- New docs: `docs/INSTALL.md`, `docs/USAGE.md`, `docs/DEMO.md`, `docs/AI.md`.
- Hosted n8n chat `FIP - Chat Demo & Model Control` at `http://127.0.0.1:5679/webhook/fip-chat/chat`: runs the demo, lists/change/tests models, checks backend/Ollama connectivity and reads run status without opening the editor. Verified live with a full chat demo (run 8, 23/27/6/4, 18 reports) and with `set model` / `test model`.
- New backend n8n endpoints: `POST /api/n8n/chat`, `GET /api/n8n/connection`, `GET /api/n8n/models`, `PUT /api/n8n/model`.
- `setup.bat` now activates the chat workflow as well as the full-review workflow.

## Known limitations

- No GPU on this machine: 1.5B model, about 10 s per rule for AI narration.
- The supplied real log workbook does not share the inventory's rule identity space, so real-data analysis is all REVIEW. Synthetic logs are clearly labelled and used only to prove calculations.
- `start.bat` opens the portal once the API health endpoint answers; n8n is optional.
- SQLite is the default; switching to PostgreSQL is a `DATABASE_URL` change, not a code change, but has not been exercised here.
