import { useEffect, useState } from 'react';
import { Link, Navigate, NavLink, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { api, fmtDate } from './api';
import { Icon, SyntheticBadge, ToastProvider, useToast } from './ui';
import { useApp } from './state';
import Dashboard from './pages/Dashboard';
import Uploads from './pages/Uploads';
import Rules from './pages/Rules';
import RuleDetail from './pages/RuleDetail';
import Runs from './pages/Runs';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Login from './pages/Login';

const NAV = [
  { to: '/', label: 'Executive Dashboard', icon: 'dashboard', end: true },
  { to: '/uploads', label: 'File Upload Centre', icon: 'upload' },
  { to: '/rules', label: 'Firewall Rule Review', icon: 'rules' },
  { to: '/runs', label: 'Analysis Runs', icon: 'runs' },
  { to: '/reports', label: 'Reports', icon: 'reports' },
  { to: '/settings', label: 'Policy & Settings', icon: 'settings' },
];

function Layout() {
  const { runs, currentRunId, setCurrentRunId, currentRun, loadingRuns, refreshRuns } = useApp();
  const [healthy, setHealthy] = useState<{ ai: boolean; model: string; authEnabled: boolean } | null>(null);
  const location = useLocation();
  const toast = useToast();

  useEffect(() => {
    api.get<any>('/health').then((h) => setHealthy({ ai: h.ai?.available, model: h.ai?.model, authEnabled: h.auth_enabled })).catch(() => setHealthy(null));
  }, []);

  const onRunChange = (value: string) => {
    setCurrentRunId(value ? Number(value) : null);
    toast.push('Analysis run switched');
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Icon name="shield" size={20} /></div>
          <div>
            <div className="brand-title">Firewall Rule<br />Intelligence</div>
            <div className="brand-sub">Review platform</div>
          </div>
        </div>
        <nav className="nav">
          <div className="nav-label">Workspace</div>
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              <Icon name={item.icon} size={16} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div><strong>Analysis only</strong></div>
          <div>Never changes firewall configuration.</div>
          <div style={{ marginTop: 8 }} className="mono">v1.0.0 · localhost</div>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <div className="topbar-title">{NAV.find((n) => (n.end ? location.pathname === n.to : location.pathname.startsWith(n.to)))?.label ?? 'Rule detail'}</div>
          <div className="topbar-spacer" />
          <div className="topbar-meta">
            {loadingRuns ? <span className="spinner" /> : null}
            <label htmlFor="run-select" style={{ fontSize: 11.5 }}>Analysis run</label>
            <select id="run-select" value={currentRunId ?? ''} onChange={(e) => onRunChange(e.target.value)} style={{ minWidth: 210, maxWidth: 340, padding: '5px 8px', fontSize: 12 }}>
              {runs.length === 0 ? <option value="">No runs yet</option> : null}
              {runs.map((r) => (
                <option key={r.id} value={r.id}>
                  #{r.id} · {r.label}{r.is_synthetic ? ' (synthetic)' : ''}{r.status !== 'completed' ? ` · ${r.status}` : ''}
                </option>
              ))}
            </select>
            <button className="btn subtle icon" title="Refresh runs" onClick={() => { refreshRuns(); toast.push('Runs refreshed'); }}><Icon name="refresh" size={15} /></button>
            {currentRun?.is_synthetic ? <SyntheticBadge /> : null}
            <span className="dot" style={{ background: healthy?.ai ? '#3a9b52' : '#9aa7ba' }} title={healthy?.ai ? `Ollama ready (${healthy.model})` : 'Ollama unavailable - deterministic explanations used'} />
            <span style={{ fontSize: 11 }}>{healthy?.ai ? 'Local AI ready' : 'Local AI offline'}</span>
          </div>
        </header>
        {currentRun?.status === 'completed' ? (
          <div style={{ padding: '8px 24px 0' }}>
            <div style={{ fontSize: 11.5, color: '#5d6b82', display: 'flex', gap: 14, flexWrap: 'wrap' }}>
              <span><strong style={{ color: '#1c2536' }}>Run #{currentRun.id}</strong> · {currentRun.label}</span>
              <span>Completed {fmtDate(currentRun.finished_at)}</span>
              <span>Observation window {currentRun.policy?.observation_days ?? '—'} days</span>
              {currentRun.stats?.source_files?.rules ? <span>Rules file: {currentRun.stats.source_files.rules}</span> : null}
              {currentRun.stats?.source_files?.logs ? <span>Logs: {currentRun.stats.source_files.logs}</span> : null}
              <Link to="/runs">All runs</Link>
            </div>
          </div>
        ) : null}
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function Guard() {
  const { auth } = useApp();
  if (!auth) return <div className="login-shell"><span className="spinner" /></div>;
  if (auth.enabled && !auth.authenticated) return <Login />;
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="uploads" element={<Uploads />} />
        <Route path="rules" element={<Rules />} />
        <Route path="rules/:id" element={<RuleDetail />} />
        <Route path="runs" element={<Runs />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Guard />
    </ToastProvider>
  );
}
