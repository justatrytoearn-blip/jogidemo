import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from './api';
import type { RunSummary } from './types';

interface AppState {
  runs: RunSummary[];
  currentRun: RunSummary | null;
  currentRunId: number | null;
  setCurrentRunId: (id: number | null) => void;
  refreshRuns: () => Promise<void>;
  loadingRuns: boolean;
  auth: { enabled: boolean; authenticated: boolean; username?: string; role?: string } | null;
  refreshAuth: () => Promise<void>;
}

const Ctx = createContext<AppState>({
  runs: [], currentRun: null, currentRunId: null, setCurrentRunId: () => {}, refreshRuns: async () => {},
  loadingRuns: true, auth: null, refreshAuth: async () => {},
});

export const useApp = () => useContext(Ctx);
const STORAGE_KEY = 'fip.currentRunId';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [runs, setRuns] = useState<RunSummary[]>([]);
  const [currentRunId, setCurrentRunIdState] = useState<number | null>(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? Number(raw) : NaN;
    return Number.isFinite(parsed) ? parsed : null;
  });
  const [loadingRuns, setLoadingRuns] = useState(true);
  const [auth, setAuth] = useState<AppState['auth']>(null);

  const refreshRuns = useCallback(async () => {
    try {
      const res = await api.get<{ items: RunSummary[] }>('/runs?limit=100');
      const completed = res.items.filter((r) => r.status === 'completed');
      setRuns(res.items);
      setCurrentRunIdState((prev) => {
        if (prev && res.items.some((r) => r.id === prev)) return prev;
        const newest = completed[0] ?? res.items[0] ?? null;
        return newest ? newest.id : null;
      });
    } finally {
      setLoadingRuns(false);
    }
  }, []);

  const refreshAuth = useCallback(async () => {
    try {
      const res = await api.get<any>('/auth/status');
      setAuth({ enabled: res.auth_enabled, authenticated: res.authenticated, username: res.username, role: res.role });
    } catch {
      setAuth({ enabled: true, authenticated: false });
    }
  }, []);

  useEffect(() => {
    refreshRuns().catch(() => setLoadingRuns(false));
    refreshAuth();
  }, [refreshRuns, refreshAuth]);

  const setCurrentRunId = useCallback((id: number | null) => {
    setCurrentRunIdState(id);
    if (id) localStorage.setItem(STORAGE_KEY, String(id));
    else localStorage.removeItem(STORAGE_KEY);
  }, []);

  const currentRun = useMemo(() => runs.find((r) => r.id === currentRunId) ?? null, [runs, currentRunId]);
  const value = useMemo(
    () => ({ runs, currentRun, currentRunId, setCurrentRunId, refreshRuns, loadingRuns, auth, refreshAuth }),
    [runs, currentRun, currentRunId, setCurrentRunId, refreshRuns, loadingRuns, auth, refreshAuth],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
