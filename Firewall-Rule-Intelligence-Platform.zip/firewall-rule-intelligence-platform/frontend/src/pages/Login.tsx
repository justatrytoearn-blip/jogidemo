import { useState } from 'react';
import { api } from '../api';
import { useApp } from '../state';
import { Alert, Icon } from '../ui';

export default function Login() {
  const { refreshAuth } = useApp();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post('/auth/login', { username, password });
      await refreshAuth();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-shell">
      <div className="login-card">
        <div className="flex items-center gap-12 mb-12">
          <div className="brand-mark" style={{ background: '#1F3864' }}><Icon name="shield" size={20} /></div>
          <div>
            <div style={{ fontWeight: 700, color: '#1F3864', letterSpacing: '.02em' }}>FIREWALL RULE INTELLIGENCE PLATFORM</div>
            <div className="spark">Authentication is enabled for this installation</div>
          </div>
        </div>
        <div className="card">
          <div className="card-body">
            <h2 style={{ marginBottom: 12 }}>Sign in</h2>
            {error ? <Alert tone="error">{error}</Alert> : null}
            <form onSubmit={submit}>
              <div className="field"><label>Username</label><input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" /></div>
              <div className="field"><label>Password</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></div>
              <button className="btn primary" type="submit" disabled={busy} style={{ width: '100%' }}>{busy ? <span className="spinner" /> : 'Sign in'}</button>
            </form>
            <p className="spark mt-12">
              Bootstrap credentials are generated on first start and written to <span className="mono">config/admin_credentials.txt</span>. Change them before enabling authentication.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
