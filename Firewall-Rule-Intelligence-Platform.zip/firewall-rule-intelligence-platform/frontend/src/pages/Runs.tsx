import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, fmtDate, fmtNumber } from '../api';
import type { RunSummary } from '../types';
import { useApp } from '../state';
import { Alert, Badge, Card, Icon, Loading, PageHead, Progress, SyntheticBadge, useToast } from '../ui';

export default function Runs() {
  const { runs, refreshRuns, setCurrentRunId, currentRunId } = useApp();
  const navigate = useNavigate();
  const toast = useToast();
  const [comparison, setComparison] = useState<any>(null);
  const [baseRun, setBaseRun] = useState<string>('');
  const [currentRun, setCurrentRun] = useState<string>('');
  const [comparing, setComparing] = useState(false);
  const [loading, setLoading] = useState(false);

  const completed = runs.filter((r) => r.status === 'completed');
  const pending = runs.some((r) => r.status === 'running' || r.status === 'queued');

  const load = useCallback(async () => {
    setLoading(true);
    try { await refreshRuns(); } finally { setLoading(false); }
  }, [refreshRuns]);

  useEffect(() => {
    if (!pending) return;
    const timer = setInterval(() => { refreshRuns(); }, 4000);
    return () => clearInterval(timer);
  }, [pending, refreshRuns]);

  useEffect(() => {
    if (!baseRun && completed.length >= 2) setBaseRun(String(completed[1].id));
    if (!currentRun && completed.length >= 1) setCurrentRun(String(completed[0].id));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [completed.length]);

  const runComparison = async () => {
    if (!baseRun || !currentRun) { toast.push('Select both runs', 'error'); return; }
    setComparing(true);
    try {
      const res = await api.get<any>(`/runs/${currentRun}/comparison?base_run_id=${baseRun}`);
      setComparison(res);
    } catch (e: any) {
      toast.push(e.message, 'error');
      setComparison(null);
    } finally {
      setComparing(false);
    }
  };

  const openRun = (run: RunSummary) => {
    setCurrentRunId(run.id);
    navigate('/');
  };

  return (
    <>
      <PageHead
        title="Analysis Runs"
        lede="Every analysis is stored with its policy snapshot and source files. Re-analysis keeps prior results so changes in rules, traffic, ownership and recommendations can be compared."
        actions={<button className="btn" onClick={load}><Icon name="refresh" size={14} /> Refresh</button>}
      />

      <Card title="Run history" hint={`${runs.length} run(s) · newest first`} tight>
        {loading && !runs.length ? <Loading /> : null}
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Run</th><th>Status</th><th>Created</th><th className="num">Rules</th><th className="num">KEEP</th><th className="num">REVIEW</th><th className="num">DISABLE</th><th className="num">DELETE</th><th>Data</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {runs.map((r) => (
                <tr key={r.id} className={currentRunId === r.id ? 'selected' : ''}>
                  <td>
                    <span className="link-strong" style={{ cursor: 'pointer' }} onClick={() => openRun(r)}>#{r.id} · {r.label}</span>
                    <div className="cell-sub">{r.stats?.source_files?.rules || '—'}{r.parent_run_id ? ` · compared with #${r.parent_run_id}` : ''}</div>
                  </td>
                  <td>
                    <Badge value={r.status} kind="neutral" />
                    {r.status === 'running' || r.status === 'queued' ? <div style={{ minWidth: 120, marginTop: 6 }}><Progress value={r.progress} label={r.message} /></div> : null}
                    {r.error ? <div className="cell-sub" style={{ color: '#b00020' }}>{r.error.slice(0, 120)}</div> : null}
                  </td>
                  <td className="nowrap">{fmtDate(r.created_at)}</td>
                  <td className="num">{fmtNumber(r.stats?.total_rules)}</td>
                  <td className="num">{fmtNumber(r.stats?.keep)}</td>
                  <td className="num">{fmtNumber(r.stats?.review)}</td>
                  <td className="num">{fmtNumber(r.stats?.disable)}</td>
                  <td className="num">{fmtNumber(r.stats?.delete)}</td>
                  <td className="nowrap">{r.is_synthetic ? <SyntheticBadge /> : <span className="badge neutral">customer</span>}</td>
                  <td className="nowrap">
                    <div className="row-actions">
                      <button className="btn small" onClick={() => openRun(r)}>Dashboard</button>
                      {r.status === 'completed' ? <button className="btn small" onClick={() => { setCurrentRunId(r.id); navigate('/reports'); }}>Reports</button> : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!runs.length ? <div className="table-empty">No runs yet.</div> : null}
        </div>
      </Card>

      <Card title="Re-analysis comparison" hint="New, removed and changed rules plus recommendation drift" className="mt-16">
        <div className="grid cols-4">
          <div className="field">
            <label>Baseline run</label>
            <select value={baseRun} onChange={(e) => setBaseRun(e.target.value)}>
              <option value="">Select a completed run</option>
              {completed.map((r) => <option key={r.id} value={r.id}>#{r.id} · {r.label}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Current run</label>
            <select value={currentRun} onChange={(e) => setCurrentRun(e.target.value)}>
              <option value="">Select a completed run</option>
              {completed.map((r) => <option key={r.id} value={r.id}>#{r.id} · {r.label}</option>)}
            </select>
          </div>
          <div className="field" style={{ alignSelf: 'end', paddingBottom: 11 }}>
            <button className="btn primary" onClick={runComparison} disabled={comparing || completed.length < 2}>{comparing ? <span className="spinner" /> : null} Compare runs</button>
          </div>
        </div>

        {comparison ? (
          <>
            <div className="cards mb-12">
              {[
                ['new_rules', 'New rules'],
                ['removed_rules', 'Removed rules'],
                ['changed_rules', 'Changed rules'],
                ['recommendation_changes', 'Recommendation changes'],
                ['traffic_changes', 'Traffic changes'],
                ['newly_linked_changes', 'New change links'],
              ].map(([key, label]) => (
                <div className="metric" key={key} style={{ cursor: 'default' }}>
                  <div className="label">{label}</div>
                  <div className="value">{fmtNumber(comparison.summary?.[key])}</div>
                </div>
              ))}
            </div>

            {comparison.details?.new?.length ? (
              <>
                <h3 className="section-title">New rules ({comparison.details.new.length})</h3>
                <div className="table-wrap" style={{ maxHeight: 220, border: '1px solid #dde3ec', borderRadius: 6 }}>
                  <table><thead><tr><th>Rule</th><th>Name</th><th>Section</th></tr></thead>
                    <tbody>{comparison.details.new.map((r: any) => <tr key={r.rule_uid || r.rule_number}><td className="mono">{r.rule_number}</td><td>{r.rule_name}</td><td>{r.section}</td></tr>)}</tbody>
                  </table>
                </div>
              </>
            ) : null}

            {comparison.details?.removed?.length ? (
              <>
                <h3 className="section-title mt-12">Removed rules ({comparison.details.removed.length})</h3>
                <div className="table-wrap" style={{ maxHeight: 200, border: '1px solid #dde3ec', borderRadius: 6 }}>
                  <table><thead><tr><th>Rule</th><th>Name</th><th>Section</th></tr></thead>
                    <tbody>{comparison.details.removed.map((r: any) => <tr key={r.rule_uid || r.rule_number}><td className="mono">{r.rule_number}</td><td>{r.rule_name}</td><td>{r.section}</td></tr>)}</tbody>
                  </table>
                </div>
              </>
            ) : null}

            <h3 className="section-title mt-12">Changed rules ({comparison.details?.changed?.length ?? 0})</h3>
            <div className="table-wrap" style={{ maxHeight: 380, border: '1px solid #dde3ec', borderRadius: 6 }}>
              <table>
                <thead><tr><th>Rule</th><th>Name</th><th>Field changes</th><th>Traffic changes</th><th>Recommendation</th><th>New change links</th></tr></thead>
                <tbody>
                  {(comparison.details?.changed ?? []).map((c: any, i: number) => (
                    <tr key={`${c.rule_uid}-${i}`}>
                      <td className="mono nowrap">{c.rule_number}</td>
                      <td>{c.rule_name}<div className="cell-sub">{c.section}</div></td>
                      <td style={{ maxWidth: 260 }}>
                        {Object.entries(c.field_changes || {}).map(([k, v]: any) => <div key={k} className="cell-sub">{k}: <span className="text-muted">{String(v.before).slice(0, 40)}</span> → <strong>{String(v.after).slice(0, 40)}</strong></div>)}
                        {!Object.keys(c.field_changes || {}).length ? '—' : null}
                      </td>
                      <td>
                        {Object.entries(c.traffic_changes || {}).map(([k, v]: any) => <div key={k} className="cell-sub">{k}: {fmtNumber(v.before)} → <strong>{fmtNumber(v.after)}</strong></div>)}
                        {!Object.keys(c.traffic_changes || {}).length ? '—' : null}
                      </td>
                      <td className="nowrap">{c.recommendation?.before ? <Badge value={c.recommendation.before} /> : '—'} → {c.recommendation?.after ? <Badge value={c.recommendation.after} /> : '—'}</td>
                      <td style={{ maxWidth: 200 }}>{c.newly_linked_change_records?.length ? c.newly_linked_change_records.join(', ') : '—'}</td>
                    </tr>
                  ))}
                  {!(comparison.details?.changed ?? []).length ? <tr><td colSpan={6} className="text-muted">No differences between these runs.</td></tr> : null}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <Alert tone="info">Select a baseline and a current run to see what changed. Comparison is stored with the current run for audit.</Alert>
        )}
      </Card>
    </>
  );
}
