import { useCallback, useEffect, useState } from 'react';
import { api, fmtBytes, fmtDate } from '../api';
import { useApp } from '../state';
import { Alert, Card, Icon, PageHead, useToast } from '../ui';

const KINDS = [
  ['full', 'Complete firewall rule review'],
  ['keep', 'KEEP report'],
  ['review', 'REVIEW report'],
  ['disable', 'DISABLE report'],
  ['delete', 'DELETE report'],
  ['missing_info', 'Rules with missing information'],
  ['no_change', 'Rules without change history'],
  ['zero_traffic', 'Rules with zero traffic'],
  ['executive', 'Executive summary'],
] as const;

export default function Reports() {
  const { runs, currentRunId, setCurrentRunId } = useApp();
  const toast = useToast();
  const [kinds, setKinds] = useState<string[]>(['full', 'executive']);
  const [formats, setFormats] = useState<string[]>(['xlsx', 'pdf']);
  const [items, setItems] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const completed = runs.filter((r) => r.status === 'completed');

  const load = useCallback(async () => {
    if (!currentRunId) { setItems([]); return; }
    try {
      const res = await api.get<{ items: any[] }>(`/reports?run_id=${currentRunId}`);
      setItems(res.items);
    } catch (e: any) {
      setError(e.message);
    }
  }, [currentRunId]);

  useEffect(() => { load(); }, [load]);

  const toggle = (list: string[], value: string, setter: (v: string[]) => void) => {
    setter(list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);
  };

  const generate = async () => {
    if (!currentRunId) { toast.push('Select an analysis run', 'error'); return; }
    if (!kinds.length || !formats.length) { toast.push('Choose at least one report and format', 'error'); return; }
    setBusy(true);
    setError(null);
    try {
      const res = await api.post<{ items: any[] }>('/reports/generate', { run_id: currentRunId, kinds, formats });
      toast.push(`${res.items.length} report file(s) generated`, 'success');
      await load();
    } catch (e: any) {
      toast.push(e.message, 'error');
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const download = async (item: any) => {
    try {
      await api.download(`/reports/${item.id}/download`, item.filename);
    } catch (e: any) {
      toast.push(e.message, 'error');
    }
  };

  return (
    <>
      <PageHead
        title="Reports"
        lede="Excel and PDF exports contain every requested column plus source file, sheet and row traceability. Traffic and inventory hit counters are reported separately."
      />

      <Card title="Generate reports" hint="Reports are stored per analysis run">
        {completed.length === 0 ? <Alert tone="warn">No completed analysis run yet. <a href="/uploads">Upload files and start an analysis</a>.</Alert> : null}
        <div className="grid cols-2">
          <div className="field">
            <label>Analysis run</label>
            <select value={currentRunId ?? ''} onChange={(e) => setCurrentRunId(Number(e.target.value))}>
              {completed.map((r) => <option key={r.id} value={r.id}>#{r.id} · {r.label}{r.is_synthetic ? ' (synthetic)' : ''}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Formats</label>
            <div className="flex gap-12 mt-8">
              {['xlsx', 'pdf'].map((f) => (
                <label key={f} className="checkbox"><input type="checkbox" checked={formats.includes(f)} onChange={() => toggle(formats, f, setFormats)} /> {f.toUpperCase()}</label>
              ))}
            </div>
          </div>
        </div>
        <div className="field">
          <label>Report contents</label>
          <div className="grid cols-3" style={{ gap: 6 }}>
            {KINDS.map(([key, label]) => (
              <label key={key} className="checkbox"><input type="checkbox" checked={kinds.includes(key)} onChange={() => toggle(kinds, key, setKinds)} /> {label}</label>
            ))}
          </div>
        </div>
        <div className="flex gap-8 mt-12">
          <button className="btn primary" onClick={generate} disabled={busy || !currentRunId}>{busy ? <span className="spinner" /> : <Icon name="reports" size={14} />} Generate selected</button>
          <button className="btn" onClick={() => { setKinds(KINDS.map(([k]) => k)); setFormats(['xlsx', 'pdf']); }}>Select everything</button>
          <button className="btn" onClick={() => { setKinds(['full']); setFormats(['xlsx']); }}>Full Excel only</button>
        </div>
        {error ? <Alert tone="error">{error}</Alert> : null}
      </Card>

      <Card title="Generated reports" hint="Click to download" className="mt-16" tight>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Report</th><th>Run</th><th>Format</th><th className="num">Size</th><th>Generated</th><th>Download</th></tr></thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td>{item.title}</td>
                  <td className="mono">#{item.run_id}</td>
                  <td><span className="badge neutral">{item.fmt.toUpperCase()}</span></td>
                  <td className="num">{fmtBytes(item.size_bytes)}</td>
                  <td className="nowrap">{fmtDate(item.created_at)}</td>
                  <td><button className="btn small" onClick={() => download(item)}><Icon name="download" size={13} /> Download</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {!items.length ? <div className="table-empty">No reports generated for this run yet.</div> : null}
        </div>
      </Card>
      <Alert tone="info">
        The platform analyses and recommends only. It never executes KEEP, DISABLE or DELETE against a firewall; every change remains subject to the customer&apos;s change management process.
      </Alert>
    </>
  );
}
