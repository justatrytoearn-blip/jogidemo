import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, fmtBytes, fmtDate } from '../api';
import type { PreviewResponse, UploadSummary } from '../types';
import { useApp } from '../state';
import { Alert, Badge, Card, Icon, Loading, PageHead, useToast } from '../ui';

type DatasetType = 'rules' | 'changes' | 'logs';

const DATASETS: { key: DatasetType; title: string; hint: string; required: boolean }[] = [
  { key: 'rules', title: '1 · Firewall rule inventory', hint: 'XLSX / XLS / CSV. Section heading rows are detected and skipped, never treated as rules.', required: true },
  { key: 'changes', title: '2 · ServiceNow change records', hint: 'XLSX / XLS / CSV. Linked by CTASK, change request, rule UID or rule number.', required: false },
  { key: 'logs', title: '3 · Firewall logs', hint: 'XLSX / XLS / CSV, including large CSV files (streamed in chunks).', required: false },
];

export default function Uploads() {
  const toast = useToast();
  const navigate = useNavigate();
  const { refreshRuns, currentRunId, runs } = useApp();
  const [active, setActive] = useState<DatasetType>('rules');
  const [uploads, setUploads] = useState<Record<DatasetType, UploadSummary[]>>({ rules: [], changes: [], logs: [] });
  const [selected, setSelected] = useState<Record<DatasetType, UploadSummary | null>>({ rules: null, changes: null, logs: null });
  const [preview, setPreview] = useState<PreviewResponse | null>(null);
  const [mapping, setMapping] = useState<Record<string, string | null>>({});
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [label, setLabel] = useState('');
  const [aiEnabled, setAiEnabled] = useState(true);
  const [syntheticUpload, setSyntheticUpload] = useState(false);
  const [parentRun, setParentRun] = useState<string>('');
  const [starting, setStarting] = useState(false);
  const fileRefs = useRef<Record<DatasetType, HTMLInputElement | null>>({ rules: null, changes: null, logs: null });

  const loadUploads = async () => {
    const [rules, changes, logs] = await Promise.all([
      api.get<{ items: UploadSummary[] }>('/uploads?dataset_type=rules&limit=50'),
      api.get<{ items: UploadSummary[] }>('/uploads?dataset_type=changes&limit=50'),
      api.get<{ items: UploadSummary[] }>('/uploads?dataset_type=logs&limit=50'),
    ]);
    const next = { rules: rules.items, changes: changes.items, logs: logs.items };
    setUploads(next);
    setSelected((prev) => {
      const out = { ...prev };
      (Object.keys(next) as DatasetType[]).forEach((k) => {
        if (!out[k] && next[k].length) out[k] = next[k][0];
      });
      return out;
    });
  };

  useEffect(() => { loadUploads().catch((e) => toast.push(e.message, 'error')); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const openPreview = async (upload: UploadSummary, sheetName?: string) => {
    setLoadingPreview(true);
    try {
      const p = await api.get<PreviewResponse>(`/uploads/${upload.id}/preview${sheetName ? `?sheet_name=${encodeURIComponent(sheetName)}` : ''}`);
      setPreview(p);
      setMapping({ ...Object.fromEntries(p.fields.map((f) => [f.key, null])), ...p.detection.mapping });
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setLoadingPreview(false);
    }
  };

  const selectUpload = (dataset: DatasetType, upload: UploadSummary) => {
    setSelected((prev) => ({ ...prev, [dataset]: upload }));
    openPreview(upload);
  };

  useEffect(() => {
    if (selected[active]) openPreview(selected[active]!);
    else setPreview(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  const doUpload = async (dataset: DatasetType, file: File) => {
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('dataset_type', dataset);
      form.append('is_synthetic', String(dataset === 'logs' ? syntheticUpload : false));
      const current = selected[dataset];
      if (current) form.append('replace_upload_id', String(current.id));
      const created = await api.upload<UploadSummary>('/uploads', form);
      toast.push(`${file.name} uploaded and validated`, 'success');
      await loadUploads();
      setSelected((prev) => ({ ...prev, [dataset]: created }));
      await openPreview(created);
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setUploading(false);
      const ref = fileRefs.current[dataset];
      if (ref) ref.value = '';
    }
  };

  const confirmMapping = async () => {
    const upload = selected[active];
    if (!upload || !preview) return;
    setConfirming(true);
    try {
      const updated = await api.post<UploadSummary>(`/uploads/${upload.id}/mapping`, {
        mapping,
        sheet_name: preview.sheet_name,
      });
      toast.push(`Mapping confirmed: ${updated.row_count.toLocaleString()} ${active === 'logs' ? 'sampled rows' : 'records'} processed`, 'success');
      await loadUploads();
      setSelected((prev) => ({ ...prev, [active]: updated }));
      setPreview(null);
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setConfirming(false);
    }
  };

  const startAnalysis = async () => {
    const rules = selected.rules;
    if (!rules || rules.status !== 'processed') {
      toast.push('Confirm the rule inventory mapping first', 'error');
      return;
    }
    const changes = selected.changes && selected.changes.status === 'processed' ? selected.changes.id : null;
    const logs = selected.logs ? selected.logs.id : null;
    setStarting(true);
    try {
      const res = await api.post<{ run: any; job_id: number }>('/runs', {
        rules_upload_id: rules.id,
        changes_upload_id: changes,
        logs_upload_id: logs,
        label: label || `Review ${new Date().toLocaleString()}`,
        ai_explanations: aiEnabled,
        parent_run_id: parentRun ? Number(parentRun) : currentRunId,
      });
      toast.push(`Analysis #${res.run.id} started in the background`, 'success');
      await refreshRuns();
      navigate('/runs');
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setStarting(false);
    }
  };

  const current = selected[active];
  const history = uploads[active] ?? [];

  return (
    <>
      <PageHead
        title="File Upload Centre"
        lede="Upload the three input files. Columns are detected automatically and every mapping can be corrected before processing. Original files are stored unchanged, and replacement uploads keep their analysis history."
        actions={<button className="btn" onClick={() => loadUploads()}><Icon name="refresh" size={14} /> Refresh</button>}
      />

      <Card title="Start a bulk analysis" hint="Correlate all three inputs and generate recommendations for every rule">
        <div className="grid cols-4">
          <div>
            <div className="field"><label>Rule inventory</label><div className="v">{selected.rules ? `${selected.rules.original_filename} (${selected.rules.row_count || 0} rules)` : 'not selected'}</div></div>
          </div>
          <div>
            <div className="field"><label>Change records</label><div className="v">{selected.changes ? selected.changes.original_filename : 'not selected'}</div></div>
          </div>
          <div>
            <div className="field"><label>Firewall logs</label><div className="v">{selected.logs ? selected.logs.original_filename : 'not selected'}</div></div>
          </div>
          <div>
            <div className="field">
              <label>Re-analysis baseline</label>
              <select value={parentRun} onChange={(e) => setParentRun(e.target.value)}>
                <option value="">No comparison</option>
                {runs.filter((r) => r.status === 'completed').map((r) => <option key={r.id} value={r.id}>Compare against run #{r.id}</option>)}
              </select>
            </div>
          </div>
        </div>
        <div className="grid cols-2">
          <div className="field">
            <label>Run label</label>
            <input type="text" value={label} onChange={(e) => setLabel(e.target.value)} placeholder="e.g. Quarterly firewall review - November" />
          </div>
          <div className="flex items-center gap-12" style={{ alignSelf: 'end', paddingBottom: 11 }}>
            <label className="checkbox"><input type="checkbox" checked={aiEnabled} onChange={(e) => setAiEnabled(e.target.checked)} /> Generate local AI explanations</label>
            <button className="btn primary" disabled={starting || !selected.rules} onClick={startAnalysis}>
              {starting ? <span className="spinner" /> : <Icon name="sparkles" size={14} />} Start analysis
            </button>
          </div>
        </div>
        <div className="spark">Analysis runs in a background worker: the portal stays responsive and progress is shown on the Runs page and dashboard.</div>
      </Card>

      <div className="tabs mt-16">
        {DATASETS.map((d) => (
          <button key={d.key} className={`tab ${active === d.key ? 'active' : ''}`} onClick={() => setActive(d.key)}>
            {d.title} {uploads[d.key].length ? <span className="badge neutral" style={{ marginLeft: 6 }}>{uploads[d.key].length}</span> : null}
          </button>
        ))}
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'minmax(0, 1.1fr) minmax(0, 1fr)' }}>
        <Card
          title={DATASETS.find((d) => d.key === active)!.title}
          hint={DATASETS.find((d) => d.key === active)!.hint}
          actions={
            <button className="btn small" onClick={() => api.download(`/templates/${active}`, `${active}_template.xlsx`)}>
              <Icon name="download" size={13} /> Template
            </button>
          }
        >
          <div
            className="dropzone"
            onClick={() => fileRefs.current[active]?.click()}
            onDragOver={(e) => { e.preventDefault(); (e.currentTarget as HTMLElement).classList.add('drag'); }}
            onDragLeave={(e) => (e.currentTarget as HTMLElement).classList.remove('drag')}
            onDrop={(e) => {
              e.preventDefault();
              (e.currentTarget as HTMLElement).classList.remove('drag');
              const file = e.dataTransfer.files?.[0];
              if (file) doUpload(active, file);
            }}
          >
            <Icon name="upload" size={22} />
            <div className="dz-title">{uploading ? 'Validating and storing…' : 'Drag and drop a file here'}</div>
            <div className="dz-hint">or click to browse · .xlsx, .xls, .csv · max 512 MB</div>
            <input
              ref={(el) => { fileRefs.current[active] = el; }}
              type="file"
              accept=".xlsx,.xls,.csv"
              style={{ display: 'none' }}
              onChange={(e) => { const f = e.target.files?.[0]; if (f) doUpload(active, f); }}
            />
          </div>

          {active === 'logs' ? (
            <label className="checkbox mt-12">
              <input type="checkbox" checked={syntheticUpload} onChange={(e) => setSyntheticUpload(e.target.checked)} />
              Mark this log file as <strong>synthetic test data</strong> (kept separate from customer traffic)
            </label>
          ) : null}

          {current ? (
            <div className="mt-16">
              <div className="file-row">
                <div>
                  <div className="file-name">{current.original_filename}</div>
                  <div className="file-meta">
                    <span>{fmtBytes(current.size_bytes)}</span>
                    <span>{current.file_kind.toUpperCase()}</span>
                    <span>{fmtDate(current.uploaded_at)}</span>
                    <span>{current.row_count ? `${current.row_count.toLocaleString()} records` : 'awaiting mapping'}</span>
                    <Badge value={current.status} kind="neutral" />
                    {current.is_synthetic ? <span className="badge synthetic">Synthetic</span> : null}
                    {current.is_replacement_of ? <span className="badge neutral">replaces #{current.is_replacement_of}</span> : null}
                  </div>
                </div>
                <button className="btn small" onClick={() => openPreview(current)}>Review mapping</button>
              </div>
              {Object.keys(current.validation || {}).length ? (
                <div className="mt-12">
                  <Alert tone={current.validation.invalid_rows || current.validation.duplicates ? 'warn' : 'success'}>
                    <strong>Validation:</strong>{' '}
                    {current.validation.rules !== undefined ? `${current.validation.rules} rules parsed · ${current.validation.section_headings_skipped ?? 0} section headings skipped` : null}
                    {current.validation.change_records !== undefined ? `${current.validation.change_records} change records parsed` : null}
                    {current.validation.sampled_rows !== undefined ? `${current.validation.sampled_rows} rows sampled` : null}
                    {current.validation.invalid_rows ? ` · ${current.validation.invalid_rows} invalid rows` : ''}
                    {current.validation.duplicates ? ` · ${current.validation.duplicates} duplicates skipped` : ''}
                    {current.validation.supplementary_change_records?.imported ? ` · ${current.validation.supplementary_change_records.imported} change links imported from the workbook` : ''}
                    {current.validation.duplicates === 0 && !current.validation.invalid_rows ? ' · no duplicates or invalid rows' : ''}
                  </Alert>
                  {current.validation.duplicate_examples?.length ? <Alert tone="warn">Duplicates skipped: {current.validation.duplicate_examples.join(', ')}</Alert> : null}
                  {current.validation.invalid_examples?.length ? (
                    <Alert tone="warn">Invalid rows: {current.validation.invalid_examples.map((r: any) => `row ${r.row}: ${r.reason}`).join('; ')}</Alert>
                  ) : null}
                </div>
              ) : null}
            </div>
          ) : <Alert tone="info">No <strong>{active}</strong> file uploaded yet.</Alert>}

          <hr className="hr" />
          <h3 className="section-title">Upload history</h3>
          <div className="table-wrap" style={{ maxHeight: 230 }}>
            <table>
              <thead><tr><th>File</th><th>Uploaded</th><th className="num">Records</th><th>Status</th></tr></thead>
              <tbody>
                {history.map((h) => (
                  <tr key={h.id} className={current?.id === h.id ? 'selected' : ''} onClick={() => selectUpload(active, h)} style={{ cursor: 'pointer' }}>
                    <td><span className="link-strong">{h.original_filename}</span><div className="cell-sub">{fmtBytes(h.size_bytes)}{h.is_synthetic ? ' · synthetic' : ''}</div></td>
                    <td className="nowrap">{fmtDate(h.uploaded_at, false)}</td>
                    <td className="num">{h.row_count ? h.row_count.toLocaleString() : '—'}</td>
                    <td><Badge value={h.status} kind="neutral" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {history.length === 0 ? <div className="table-empty">No uploads for this dataset.</div> : null}
          </div>
          <div className="spark mt-8">Uploading a new file while one is selected records it as a replacement; previous uploads and analysis runs are retained.</div>
        </Card>

        <Card title="Column detection, mapping and preview" hint={preview ? `Sheet: ${preview.sheet_name || 'CSV'} · header row ${preview.header_row + 1}` : 'Select or upload a file'}>
          {loadingPreview ? <Loading label="Reading file…" /> : null}
          {!loadingPreview && !preview ? <Alert tone="info">Choose an uploaded file to inspect its detected columns and preview the first records.</Alert> : null}
          {!loadingPreview && preview ? (
            <>
              <div className="grid cols-2">
                <div className="field">
                  <label>Worksheet</label>
                  <select
                    value={preview.sheet_name ?? ''}
                    disabled={!preview.sheets.length}
                    onChange={(e) => current && openPreview(current, e.target.value)}
                  >
                    {preview.sheets.length ? preview.sheets.map((s) => <option key={s} value={s}>{s}</option>) : <option value="">CSV / single sheet</option>}
                  </select>
                </div>
                <div className="field">
                  <label>Detection</label>
                  <div className="v" style={{ fontSize: 12 }}>
                    {Object.values(preview.detection.mapping).filter(Boolean).length} of {preview.fields.length} fields mapped automatically
                    {preview.detection.unmapped_columns.length ? ` · ${preview.detection.unmapped_columns.length} source columns unused` : ''}
                  </div>
                </div>
              </div>

              {preview.warnings.map((w) => <Alert key={w} tone="warn">{w}</Alert>)}
              {preview.detection.missing_required.length ? (
                <Alert tone="error">Required fields still unmapped: {preview.detection.missing_required.join(', ')}</Alert>
              ) : null}

              <div className="table-wrap" style={{ maxHeight: 300, border: '1px solid #dde3ec', borderRadius: 6 }}>
                <table className="mapping-table">
                  <thead><tr><th>Platform field</th><th>Source column</th><th>Match</th></tr></thead>
                  <tbody>
                    {preview.fields.map((f) => {
                      const score = preview.detection.scores?.[f.key];
                      return (
                        <tr key={f.key}>
                          <td>{f.label}{f.required ? <span className="req">*</span> : null}</td>
                          <td>
                            <select value={mapping[f.key] ?? ''} onChange={(e) => setMapping((prev) => ({ ...prev, [f.key]: e.target.value || null }))}>
                              <option value="">— not mapped —</option>
                              {preview.columns.map((c) => <option key={c} value={c}>{c}</option>)}
                            </select>
                          </td>
                          <td className="nowrap">{score ? <span className="badge neutral">{Math.round(score * 100)}%</span> : f.required ? <span className="badge warning">manual</span> : <span className="text-muted">—</span>}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {preview.detection.unmapped_columns.length ? (
                <div className="spark mt-8">Unused source columns (kept in raw payloads): {preview.detection.unmapped_columns.slice(0, 18).join(', ')}{preview.detection.unmapped_columns.length > 18 ? '…' : ''}</div>
              ) : null}

              <h3 className="section-title mt-16">Preview · first {preview.rows.length} records</h3>
              <div className="table-wrap preview-scroll" style={{ border: '1px solid #dde3ec', borderRadius: 6 }}>
                <table>
                  <thead><tr>{preview.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
                  <tbody>
                    {preview.rows.map((r, idx) => (
                      <tr key={idx}>{preview.columns.map((c) => <td key={c} className="nowrap" style={{ maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis' }}>{String(r[c] ?? '')}</td>)}</tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex items-center gap-8 mt-12" style={{ justifyContent: 'flex-end' }}>
                <button className="btn" onClick={() => current && openPreview(current)}>Re-detect</button>
                <button className="btn primary" onClick={confirmMapping} disabled={confirming || preview.detection.missing_required.length > 0}>
                  {confirming ? <span className="spinner" /> : <Icon name="check" size={14} />} Confirm mapping &amp; process
                </button>
              </div>
            </>
          ) : null}
        </Card>
      </div>
    </>
  );
}
