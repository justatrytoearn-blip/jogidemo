import { useEffect, useState } from 'react';
import { api, fmtDate } from '../api';
import { Alert, Card, Icon, Loading, PageHead, useToast } from '../ui';

interface PolicyField { key: string; value: any; type: 'bool' | 'int' | 'float'; hint: string }

export default function Settings() {
  const toast = useToast();
  const [fields, setFields] = useState<PolicyField[]>([]);
  const [values, setValues] = useState<Record<string, any>>({});
  const [ai, setAi] = useState<any>(null);
  const [aiForm, setAiForm] = useState<any>({});
  const [system, setSystem] = useState<any>(null);
  const [audit, setAudit] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [refreshingModels, setRefreshingModels] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [n8nKey, setN8nKey] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const [policy, aiRes, sys, aud] = await Promise.all([
        api.get<any>('/settings/policy'),
        api.get<any>('/settings/ai'),
        api.get<any>('/settings/system'),
        api.get<any>('/settings/audit?limit=80').catch(() => ({ items: [] })),
      ]);
      setFields(policy.fields);
      setValues({ ...policy.policy });
      setAi(aiRes);
      setAiForm({ ...aiRes.config });
      setSystem(sys);
      setAudit(aud.items ?? []);
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const savePolicy = async () => {
    setSaving(true);
    try {
      const res = await api.put<any>('/settings/policy', { policy: values });
      setFields(res.fields);
      setValues({ ...res.policy });
      toast.push('Review policy saved. New analyses and re-evaluations use it immediately.', 'success');
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const saveAi = async () => {
    setSaving(true);
    try {
      const res = await api.put<any>('/settings/ai', aiForm);
      setAi(res);
      setAiForm({ ...res.config });
      toast.push('Local AI settings saved', 'success');
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const refreshModels = async () => {
    setRefreshingModels(true);
    try {
      const res = await api.get<any>('/settings/ai');
      setAi(res);
      toast.push(`Found ${(res.status?.models ?? []).length} installed model(s)`, 'success');
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setRefreshingModels(false);
    }
  };

  const testAi = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await api.post<any>('/settings/ai/test', {
        prompt: 'Reply with OK.',
        model: aiForm.ollama_model,
        ollama_url: aiForm.ollama_url,
      });
      setTestResult(res);
      toast.push(`Local model responded in ${res.seconds}s`, 'success');
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setTesting(false);
    }
  };

  const revealKey = async () => {
    try {
      const res = await api.get<any>('/settings/n8n-key');
      setN8nKey(res.api_key);
    } catch (e: any) {
      toast.push(e.message, 'error');
    }
  };

  if (loading) return <Loading label="Loading settings…" />;

  return (
    <>
      <PageHead
        title="Policy & Settings"
        lede="Recommendations are driven by this policy. Defaults are conservative: missing evidence always yields REVIEW, and no rule can be disabled or deleted without recorded approval."
        actions={<button className="btn" onClick={load}><Icon name="refresh" size={14} /> Reload</button>}
      />

      <div className="grid cols-2">
        <Card title="Recommendation policy" hint="Applies to new analyses and to re-evaluation">
          <div className="grid cols-2" style={{ gap: 10 }}>
            {fields.map((f) => (
              <div className="field" key={f.key} title={f.hint}>
                <label>{f.key.replaceAll('_', ' ')}</label>
                {f.type === 'bool' ? (
                  <label className="checkbox"><input type="checkbox" checked={!!values[f.key]} onChange={(e) => setValues({ ...values, [f.key]: e.target.checked })} /> enabled</label>
                ) : (
                  <input
                    type="number"
                    step={f.type === 'float' ? 0.1 : 1}
                    value={values[f.key] ?? ''}
                    onChange={(e) => setValues({ ...values, [f.key]: e.target.value === '' ? '' : Number(e.target.value) })}
                  />
                )}
                <span className="hint">{f.hint}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-8 mt-12">
            <button className="btn primary" onClick={savePolicy} disabled={saving}>{saving ? <span className="spinner" /> : <Icon name="check" size={14} />} Save policy</button>
            <button className="btn" onClick={() => load()}>Discard changes</button>
          </div>
          <Alert tone="warn">
            Safety guard-rails are enforced server-side: the last-hit threshold can never be shorter than the observation window, and approval requirements cannot be bypassed by the AI.
          </Alert>
        </Card>

        <div>
          <Card title="Local AI (Ollama)" hint="All prompts stay on this machine">
            <div className="grid cols-2">
              <div className="field">
                <label>Enabled</label>
                <label className="checkbox"><input type="checkbox" checked={!!aiForm.ai_enabled} onChange={(e) => setAiForm({ ...aiForm, ai_enabled: e.target.checked })} /> generate narration</label>
              </div>
              <div className="field">
                <label>Model</label>
                <div className="flex gap-8">
                  <input
                    list="installed-models"
                    value={aiForm.ollama_model ?? ''}
                    onChange={(e) => setAiForm({ ...aiForm, ollama_model: e.target.value })}
                    placeholder="qwen2.5:1.5b"
                  />
                  <datalist id="installed-models">
                    {(ai?.status?.models ?? []).map((m: string) => <option key={m} value={m} />)}
                  </datalist>
                  <button className="btn small" onClick={refreshModels} disabled={refreshingModels} title="Re-read installed models from Ollama">
                    {refreshingModels ? <span className="spinner" /> : <Icon name="refresh" size={13} />} Refresh
                  </button>
                </div>
                {!(ai?.status?.models ?? []).includes(aiForm.ollama_model) ? (
                  <span className="hint">{aiForm.ollama_model} is not installed yet. Run <span className="mono">ollama pull {aiForm.ollama_model}</span>, then Refresh.</span>
                ) : <span className="hint">Installed locally. Test before saving if this is a new model.</span>}
              </div>
              <div className="field">
                <label>Ollama URL</label>
                <input value={aiForm.ollama_url ?? ''} onChange={(e) => setAiForm({ ...aiForm, ollama_url: e.target.value })} />
              </div>
              <div className="field">
                <label>Timeout (seconds)</label>
                <input type="number" value={aiForm.ai_timeout ?? 180} onChange={(e) => setAiForm({ ...aiForm, ai_timeout: Number(e.target.value) })} />
              </div>
              <div className="field">
                <label>Max rules per batch</label>
                <input type="number" value={aiForm.ai_max_rules ?? 400} onChange={(e) => setAiForm({ ...aiForm, ai_max_rules: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex gap-8">
              <button className="btn primary" onClick={saveAi} disabled={saving}>Save AI settings</button>
              <button className="btn" onClick={testAi} disabled={testing}>{testing ? <span className="spinner" /> : null} Test this model (before saving)</button>
            </div>
            {testResult ? <Alert tone="success">Model {testResult.model} replied in {testResult.seconds}s: “{testResult.response}”</Alert> : null}
            <Alert tone={ai?.status?.available ? 'success' : 'warn'}>
              {ai?.status?.message}
              {ai?.status?.models?.length ? ` Installed: ${ai.status.models.join(', ')}` : ''}
            </Alert>
            <div className="spark">
              The model explains findings only. It never chooses the recommendation, never sees raw log rows, and every response is validated against the policy engine output.
            </div>
          </Card>

          <Card title="System information" className="mt-16">
            <div className="kv">
              <div className="k">Application</div><div className="v">{system.app?.app_name} · v{system.engine_version}</div>
              <div className="k">Python / platform</div><div className="v">{system.python} · {system.platform}</div>
              <div className="k">CPU cores</div><div className="v">{system.cpu_count}</div>
              <div className="k">Disk free</div><div className="v">{system.disk?.free_gb} GB of {system.disk?.total_gb} GB</div>
              <div className="k">Database</div><div className="v">{system.database?.rules} rules · {system.database?.runs} runs · {system.database?.recommendations} recommendations</div>
              <div className="k">Paths</div><div className="v mono">{system.paths?.uploads}<br />{system.paths?.reports}</div>
              <div className="k">Authentication</div><div className="v">{system.auth_enabled ? 'enabled (session login)' : 'disabled · localhost only'}</div>
              <div className="k">n8n API key</div>
              <div className="v">
                {n8nKey ? <span className="mono">{n8nKey}</span> : <button className="btn small" onClick={revealKey}>Reveal key (admin)</button>}
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Card title="Audit trail" hint="Uploads, mappings, runs, approvals, exports and policy changes" className="mt-16" tight>
        <div className="table-wrap" style={{ maxHeight: 360 }}>
          <table>
            <thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead>
            <tbody>
              {audit.map((a) => (
                <tr key={a.id}>
                  <td className="nowrap">{fmtDate(a.ts)}</td>
                  <td className="nowrap">{a.actor}</td>
                  <td className="mono nowrap">{a.action}</td>
                  <td className="nowrap">{a.entity} {a.entity_id ? `#${a.entity_id}` : ''}</td>
                  <td style={{ maxWidth: 520, overflow: 'hidden', textOverflow: 'ellipsis' }} className="mono">{JSON.stringify(a.details)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!audit.length ? <div className="table-empty">No audit entries (administrator role required).</div> : null}
        </div>
      </Card>
    </>
  );
}
