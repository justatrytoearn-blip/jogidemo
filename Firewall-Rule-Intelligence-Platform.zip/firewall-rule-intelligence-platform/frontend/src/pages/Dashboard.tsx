import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { api, fmtDate, fmtNumber } from '../api';
import type { DashboardData } from '../types';
import { useApp } from '../state';
import { Alert, Badge, Card, EmptyState, Icon, Loading, Metric, PageHead, Progress, SyntheticBadge, useAsync, useToast } from '../ui';

const COLORS: Record<string, string> = { KEEP: '#2E7D32', REVIEW: '#B7791F', DISABLE: '#C05621', DELETE: '#B00020' };

export default function Dashboard() {
  const { currentRunId, currentRun, refreshRuns } = useApp();
  const navigate = useNavigate();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const { data, loading, error, setData } = useAsync<DashboardData>(
    () => api.get<DashboardData>(`/dashboard${currentRunId ? `?run_id=${currentRunId}` : ''}`),
    [currentRunId],
  );

  const pending = (data?.jobs ?? []).some((j) => j.status === 'queued' || j.status === 'running') || currentRun?.status === 'running' || currentRun?.status === 'queued';

  useEffect(() => {
    if (!pending) return;
    const timer = setInterval(async () => {
      try {
        const fresh = await api.get<DashboardData>(`/dashboard${currentRunId ? `?run_id=${currentRunId}` : ''}`);
        setData(fresh);
        refreshRuns();
      } catch { /* keep old view */ }
    }, 4000);
    return () => clearInterval(timer);
  }, [pending, currentRunId, setData, refreshRuns]);

  const generateAi = async () => {
    if (!currentRunId) return;
    setBusy(true);
    try {
      await api.post(`/runs/${currentRunId}/ai`);
      toast.push('AI narration queued. This runs locally and may take a few minutes.', 'success');
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <Loading label="Loading executive dashboard…" />;
  if (error) return <Alert tone="error">{error}</Alert>;
  if (!data || data.empty) {
    return (
      <>
        <PageHead title="Executive Dashboard" lede="Evidence-based review of every firewall rule: traffic, change history, ownership and a policy-controlled recommendation." />
        <Card>
          <EmptyState
            title="No completed analysis yet"
            actions={<><Link className="btn primary" to="/uploads">Open File Upload Centre</Link><Link className="btn" to="/runs">View runs</Link></>}
          >
            Upload a firewall rule inventory, ServiceNow change records and firewall logs, then start an analysis.
            The dashboard is generated from your data — no demonstration metrics are used.
          </EmptyState>
        </Card>
      </>
    );
  }

  const m = data.metrics!;
  const charts = data.charts!;
  const run = data.run!;
  const traffic = data.traffic_summary ?? {};
  const exec = data.executive_summary ?? {};
  const synthetic = run.is_synthetic;

  return (
    <>
      <PageHead
        title="Executive Dashboard"
        lede={`All figures are computed from analysis run #${run.id}. Traffic counts come from matching firewall log events — inventory hit counters are never used as log counts.`}
        actions={
          <>
            <button className="btn" onClick={() => navigate('/reports')}><Icon name="reports" size={14} /> Reports</button>
            <button className="btn primary" onClick={() => navigate('/uploads')}><Icon name="upload" size={14} /> New analysis</button>
          </>
        }
      />

      {synthetic ? (
        <div className="banner-synthetic">
          <SyntheticBadge />
          <span>
            This run uses <strong>synthetic firewall logs and demonstration approval records</strong> generated for validation.
            Synthetic records are stored and flagged separately and are never mixed with customer traffic.
          </span>
        </div>
      ) : null}

      {pending ? (
        <Card title="Processing" hint="Background jobs update automatically">
          <div className="grid cols-2">
            {(data.jobs ?? []).map((j) => (
              <div key={j.id}>
                <div className="flex items-center gap-8 mb-8" style={{ justifyContent: 'space-between' }}>
                  <strong style={{ fontSize: 12.5 }}>{j.kind === 'analysis' ? 'Analysis pipeline' : 'Local AI narration'}</strong>
                  <span className="badge neutral">{j.status}</span>
                </div>
                <Progress value={j.progress} label={j.message} />
              </div>
            ))}
            {run.status !== 'completed' ? <div><Progress value={run.progress} label={run.message || run.stage} /></div> : null}
          </div>
        </Card>
      ) : null}

      {currentRun?.status === 'failed' ? <Alert tone="error"><strong>Analysis failed.</strong> {currentRun.error}</Alert> : null}

      <div className="cards">
        {data.cards!.map((c) => (
          <Metric
            key={c.key}
            label={c.label}
            value={c.value}
            sub={
              c.key === 'total_rules'
                ? `${fmtNumber(m.accept_rules)} accept · ${fmtNumber(m.drop_rules)} drop`
                : c.key === 'zero_traffic'
                ? 'no matching events in window'
                : c.key === 'no_log_evidence'
                ? 'cannot be judged on traffic'
                : undefined
            }
            accent={['keep', 'review', 'disable', 'delete'].includes(c.key) ? c.key : undefined}
            to={c.key === 'total_rules' ? `/rules?run=${run.id}` : `${c.target}${c.target.includes('?') ? '&' : '?'}run=${run.id}`}
          />
        ))}
      </div>

      <div className="grid cols-3 mt-16">
        <Card title="Rule recommendation distribution" hint={`${fmtNumber(m.total_rules)} rules`}>
          <div className="chart-holder">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={charts.recommendations} dataKey="value" nameKey="name" innerRadius={52} outerRadius={82} paddingAngle={2}>
                  {charts.recommendations.map((entry) => <Cell key={entry.name} fill={COLORS[entry.name] ?? '#8a97ab'} />)}
                </Pie>
                <Tooltip formatter={(v: any) => [v, 'Rules']} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="legend-inline">
            {charts.recommendations.map((r) => (
              <span key={r.name}><i style={{ background: COLORS[r.name] }} />{r.name} {fmtNumber(r.value)}</span>
            ))}
          </div>
        </Card>

        <Card title="Traffic activity over time" hint={`${traffic.rows_matched ? fmtNumber(traffic.rows_matched) : 0} matched log events · window ${traffic.observation_window?.days ?? '—'} days`}>
          <div className="chart-holder">
            {charts.traffic_over_time.length ? (
              <ResponsiveContainer>
                <LineChart data={charts.traffic_over_time} margin={{ top: 6, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickFormatter={(v) => String(v).slice(5)} minTickGap={24} />
                  <YAxis tickFormatter={(v) => fmtNumber(v)} width={52} />
                  <Tooltip labelFormatter={(l) => `Date ${l}`} formatter={(v: any) => [fmtNumber(v), 'Log events']} />
                  <Line type="monotone" dataKey="count" stroke="#1F3864" strokeWidth={1.7} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : <EmptyState title="No matched log traffic" >{traffic.identity_space_ok === false ? 'The supplied logs do not reference this inventory\'s rule identifiers.' : 'No log data in this run.'}</EmptyState>}
          </div>
        </Card>

        <Card title="Traffic frequency distribution" hint="Actual matching log events per rule">
          <div className="chart-holder">
            <ResponsiveContainer>
              <BarChart data={charts.traffic_histogram} margin={{ top: 6, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" interval={0} tick={{ fontSize: 9 }} />
                <YAxis allowDecimals={false} width={36} />
                <Tooltip formatter={(v: any) => [fmtNumber(v), 'Rules']} />
                <Bar dataKey="value" fill="#2b4a7d" radius={[2, 2, 0, 0]} maxBarSize={46} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="spark">Rules with no log evidence are shown separately and are never treated as unused.</div>
        </Card>
      </div>

      <div className="grid cols-2 mt-16">
        <Card title="Rule activity by security section" hint="Rules and those with observed traffic">
          <div className="chart-holder tall">
            <ResponsiveContainer>
              <BarChart data={charts.sections} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" allowDecimals={false} />
                <YAxis type="category" dataKey="section" width={128} tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="rules" name="Rules" fill="#c3d4ea" radius={[0, 2, 2, 0]} maxBarSize={16} />
                <Bar dataKey="active" name="With traffic" fill="#1F3864" radius={[0, 2, 2, 0]} maxBarSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Accept vs Drop and change coverage" hint="Rule inventory composition">
          <div className="grid cols-2">
            <div>
              <div className="chart-holder">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={charts.action_split} dataKey="value" nameKey="name" innerRadius={44} outerRadius={72}>
                      <Cell fill="#1F5B8F" />
                      <Cell fill="#8a97ab" />
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="legend-inline">
                {charts.action_split.map((a) => <span key={a.name}><i style={{ background: a.name === 'Accept' ? '#1F5B8F' : '#8a97ab' }} />{a.name} {fmtNumber(a.value)}</span>)}
              </div>
            </div>
            <div>
              <div className="chart-holder">
                <ResponsiveContainer>
                  <BarChart data={charts.change_coverage} margin={{ top: 10, right: 6, left: 0, bottom: 0 }}>
                    <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} />
                    <YAxis allowDecimals={false} width={34} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#2b4a7d" radius={[2, 2, 0, 0]} maxBarSize={54} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="spark">Rules without change records always need review.</div>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid cols-2 mt-16">
        <Card title="Risk distribution" hint="Risk level recorded with each recommendation">
          <div className="chart-holder">
            <ResponsiveContainer>
              <BarChart data={charts.risk} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis allowDecimals={false} width={36} />
                <Tooltip formatter={(v: any) => [fmtNumber(v), 'Rules']} />
                <Bar dataKey="value" fill="#8a6d3b" radius={[2, 2, 0, 0]} maxBarSize={56} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="spark">Risk explains blast radius; it does not change the policy decision.</div>
        </Card>

        <Card title="Top rules by matching log events" hint="Actual event counts, not inventory hit counters">
          <div className="chart-holder">
            {charts.top_rules.length ? (
              <ResponsiveContainer>
                <BarChart data={charts.top_rules.slice(0, 10)} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" tickFormatter={(v) => fmtNumber(v)} />
                  <YAxis type="category" dataKey="name" width={92} tick={{ fontSize: 9 }} />
                  <Tooltip formatter={(v: any) => [fmtNumber(v), 'Log events']} />
                  <Bar dataKey="value" fill="#1F3864" radius={[0, 2, 2, 0]} maxBarSize={14} />
                </BarChart>
              </ResponsiveContainer>
            ) : <EmptyState title="No matched traffic">Rules without log evidence are listed separately.</EmptyState>}
          </div>
        </Card>
      </div>

      <div className="grid cols-2 mt-16">
        <Card title="Top 10 most frequently used rules" hint="Ranked by matching log events" tight>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Rule</th><th>Name</th><th className="num">Log events</th><th>Last seen</th><th>Recommendation</th></tr></thead>
              <tbody>
                {(data.top_used ?? []).map((r) => (
                  <tr key={r.id}>
                    <td className="nowrap mono">{r.rule_number}</td>
                    <td><Link className="link-strong" to={`/rules/${r.id}`}>{r.rule_name}</Link><div className="cell-sub">{r.security_section}</div></td>
                    <td className="num">{fmtNumber(r.event_count)}</td>
                    <td className="nowrap">{r.days_since_last_hit === null ? '—' : `${r.days_since_last_hit}d ago`}</td>
                    <td><Badge value={r.recommendation} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {(data.top_used ?? []).length === 0 ? <div className="table-empty">No rule has matching log events in this run.</div> : null}
          </div>
        </Card>

        <Card title="Top 10 rules with no activity" hint="Zero matching events, ranked by risk" tight>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Rule</th><th>Name</th><th>Action</th><th>Risk</th><th>Recommendation</th></tr></thead>
              <tbody>
                {(data.no_activity ?? []).map((r) => (
                  <tr key={r.id}>
                    <td className="nowrap mono">{r.rule_number}</td>
                    <td><Link className="link-strong" to={`/rules/${r.id}`}>{r.rule_name}</Link><div className="cell-sub">{r.security_section}</div></td>
                    <td><Badge value={r.action} kind="action" /></td>
                    <td><Badge value={r.risk_level} kind="risk" /></td>
                    <td><Badge value={r.recommendation} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {(data.no_activity ?? []).length === 0 ? <div className="table-empty">No inactive rules.</div> : null}
          </div>
        </Card>
      </div>

      <div className="grid cols-2 mt-16">
        <Card
          title="Executive summary"
          hint={exec.generated ? `Written by local model ${exec.model || ''}` : 'Deterministic summary'}
          actions={<button className="btn small" disabled={busy || pending} onClick={generateAi}><Icon name="sparkles" size={13} /> Generate AI narration</button>}
        >
          {exec.text ? <p style={{ margin: 0 }}>{exec.text}</p> : <p className="text-muted">Start an analysis with AI explanations enabled, or generate narration for this run.</p>}
          {exec.warnings?.length ? <Alert tone="warn">{exec.warnings.join(' · ')}</Alert> : null}
          <hr className="hr" />
          <div className="stat-row">
            <div className="stat"><div className="v">{fmtNumber(traffic.rows_scanned)}</div><div className="l">Log rows scanned</div></div>
            <div className="stat"><div className="v">{fmtNumber(traffic.rows_matched)}</div><div className="l">Matched events</div></div>
            <div className="stat"><div className="v">{fmtNumber(traffic.coverage_days)}</div><div className="l">Log coverage (days)</div></div>
            <div className="stat"><div className="v">{traffic.identity_space_ok ? 'Yes' : 'No'}</div><div className="l">Logs share rule identity space</div></div>
          </div>
          {traffic.identity_space_ok === false ? (
            <Alert tone="warn">
              The uploaded log file does not reference any rule UID from this inventory (0 of {fmtNumber(traffic.rows_scanned)} rows matched).
              Absence of traffic is therefore <strong>not</strong> treated as evidence of unused rules, and every rule is held at REVIEW.
            </Alert>
          ) : null}
        </Card>

        <Card title="Run facts" hint="Traceability">
          <div className="kv">
            <div className="k">Analysis run</div><div className="v">#{run.id} · {run.label}</div>
            <div className="k">Completed</div><div className="v">{fmtDate(run.finished_at)}</div>
            <div className="k">Processing time</div><div className="v">{run.stats?.processing_seconds ? `${run.stats.processing_seconds}s` : '—'}</div>
            <div className="k">Rules processed</div><div className="v">{fmtNumber(run.stats?.total_rules)}</div>
            <div className="k">Rules with change records</div><div className="v">{fmtNumber(run.stats?.rules_with_change_records)} · {fmtNumber(run.stats?.rules_without_change_records)} without</div>
            <div className="k">Owner identified</div><div className="v">{fmtNumber(m.total_rules - m.missing_owners)} of {fmtNumber(m.total_rules)}</div>
            <div className="k">Rules file</div><div className="v">{run.stats?.source_files?.rules || '—'}</div>
            <div className="k">Change file</div><div className="v">{run.stats?.source_files?.changes || 'not supplied'}</div>
            <div className="k">Log file</div><div className="v">{run.stats?.source_files?.logs || 'not supplied'}</div>
            <div className="k">Data classification</div><div className="v">{synthetic ? <SyntheticBadge /> : 'Customer data (local only)'}</div>
            <div className="k">Policy</div><div className="v">{run.policy?.observation_days} day window · {run.policy?.last_hit_age_threshold_days} day last-hit threshold · {run.policy?.disable_monitoring_days} day post-disable monitoring</div>
          </div>
          <div className="mt-12"><Link to="/runs" className="btn small">View run history &amp; comparison</Link></div>
        </Card>
      </div>
    </>
  );
}
