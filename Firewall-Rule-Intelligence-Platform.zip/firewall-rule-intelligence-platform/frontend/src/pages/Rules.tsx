import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api, fmtNumber } from '../api';
import type { RuleListResponse } from '../types';
import { useApp } from '../state';
import { Alert, Badge, Card, Icon, Loading, PageHead, useToast } from '../ui';

const FILTER_KEYS = [
  'q', 'rule_name', 'rule_number', 'rule_uid', 'source', 'destination', 'service', 'security_section',
  'action', 'recommendation', 'traffic', 'last_hit_from', 'last_hit_to', 'change_record', 'change_state',
  'owner', 'expiry', 'risk', 'ai_generated',
] as const;

type FilterKey = typeof FILTER_KEYS[number];
type Filters = Partial<Record<FilterKey, string>>;

export default function Rules() {
  const { currentRunId } = useApp();
  const [params, setParams] = useSearchParams();
  const toast = useToast();
  const [filters, setFilters] = useState<Filters>({});
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [sortBy, setSortBy] = useState('rule_number');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [data, setData] = useState<RuleListResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [options, setOptions] = useState<any>(null);
  const [reviewing, setReviewing] = useState(false);
  const [accepting, setAccepting] = useState<number | null>(null);
  const [mode, setMode] = useState<'complete' | 'filtered'>('filtered');
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    const initial: Filters = {};
    FILTER_KEYS.forEach((k) => { const v = params.get(k); if (v) initial[k] = v; });
    setFilters(initial);
    setSearch(initial.q ?? '');
    setPage(Number(params.get('page') || 1));
    if (params.get('sort')) setSortBy(params.get('sort')!);
    if (params.get('dir') === 'desc') setSortDir('desc');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const query = useMemo(() => {
    const f: Record<string, string | number> = {};
    Object.entries(filters).forEach(([k, v]) => { if (v) f[k] = v; });
    if (currentRunId) f.run_id = currentRunId;
    f.page = page;
    f.page_size = pageSize;
    f.sort_by = sortBy;
    f.sort_dir = sortDir;
    return f;
  }, [filters, currentRunId, page, pageSize, sortBy, sortDir]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams(Object.entries(query).map(([k, v]) => [k, String(v)])).toString();
      const res = await api.get<RuleListResponse>(`/rules?${qs}`);
      setData(res);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    api.get<any>(`/dashboard/filters${currentRunId ? `?run_id=${currentRunId}` : ''}`).then(setOptions).catch(() => {});
  }, [currentRunId]);

  useEffect(() => {
    const next = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => { if (v) next.set(k, v); });
    if (page > 1) next.set('page', String(page));
    if (sortBy !== 'rule_number') next.set('sort', sortBy);
    if (sortDir !== 'asc') next.set('dir', sortDir);
    setParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters, page, sortBy, sortDir]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters((prev) => (prev.q === search ? prev : { ...prev, q: search || undefined }));
      setPage(1);
    }, 350);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const setFilter = (key: FilterKey, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value || undefined }));
    setPage(1);
  };

  const reset = () => { setFilters({}); setSearch(''); setPage(1); setSelected(new Set()); };

  const items = data?.items ?? [];
  const allOnPageSelected = items.length > 0 && items.every((i) => selected.has(i.id));

  const toggleAll = () => {
    const next = new Set(selected);
    if (allOnPageSelected) items.forEach((i) => next.delete(i.id));
    else items.forEach((i) => next.add(i.id));
    setSelected(next);
  };

  const toggleOne = (id: number) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
  };

  const sort = (column: string) => {
    if (sortBy === column) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortBy(column); setSortDir('asc'); }
    setPage(1);
  };

  const buildFiltersPayload = () => {
    const f: Record<string, unknown> = {};
    Object.entries(filters).forEach(([k, v]) => { if (v) f[k] = v; });
    if (currentRunId) f.run_id = currentRunId;
    return f;
  };

  const runReview = async (scope: 'selected' | 'mode') => {
    setReviewing(true);
    try {
      const payload: any = { generate_ai: true };
      if (scope === 'selected') {
        if (!selected.size) { toast.push('Select at least one rule', 'error'); return; }
        payload.rule_ids = Array.from(selected);
      } else if (mode === 'complete') {
        payload.filters = { run_id: currentRunId };
      } else {
        payload.filters = buildFiltersPayload();
      }
      const res = await api.post<any>('/review', payload);
      toast.push(`${res.reviewed} rule(s) re-evaluated · ${Object.entries(res.counts).map(([k, v]) => `${k} ${v}`).join(', ')}`, 'success');
      if (res.ai_job_id) toast.push('AI narration queued for the reviewed rules');
      load();
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setReviewing(false);
    }
  };

  const acceptRule = async (id: number) => {
    setAccepting(id);
    try {
      await api.post(`/rules/${id}/accept`, { note: 'Recommendation accepted in the review page' });
      toast.push('Recommendation accepted and written to the audit trail', 'success');
      load();
    } catch (e: any) {
      toast.push(e.message, 'error');
    } finally {
      setAccepting(null);
    }
  };

  const exportRules = async (scope: 'selected' | 'all') => {
    try {
      const body: any = {};
      if (scope === 'selected') {
        if (!selected.size) { toast.push('Select at least one rule', 'error'); return; }
        body.rule_ids = Array.from(selected);
      } else {
        body.filters = buildFiltersPayload();
      }
      await api.postDownload('/rules/export', body, `firewall_rules_${scope}.xlsx`);
      toast.push('Export generated', 'success');
    } catch (e: any) {
      toast.push(e.message, 'error');
    }
  };

  const header = (label: string, column?: string, extra?: string) => (
    <th key={label} className={`${column ? 'sortable' : ''} ${extra ?? ''}`} onClick={column ? () => sort(column) : undefined}>
      {label}{sortBy === column ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
    </th>
  );

  return (
    <>
      <PageHead
        title="Firewall Rule Review"
        lede="Search and filter the complete inventory. Recommendations are policy-driven; AI narration explains them but never overrides them."
        actions={
          <>
            <div className="pillgroup">
              <button className={mode === 'complete' ? 'active' : ''} onClick={() => setMode('complete')}>Complete review</button>
              <button className={mode === 'filtered' ? 'active' : ''} onClick={() => setMode('filtered')}>Filtered review</button>
            </div>
            <button className="btn" onClick={() => exportRules('selected')} disabled={!selected.size}><Icon name="download" size={14} /> Export selected ({selected.size})</button>
            <button className="btn" onClick={() => exportRules('all')}><Icon name="download" size={14} /> Export results</button>
            <button className="btn secondary" onClick={() => runReview('selected')} disabled={reviewing || !selected.size}><Icon name="refresh" size={14} /> Review selected</button>
            <button className="btn primary" onClick={() => runReview('mode')} disabled={reviewing}>
              {reviewing ? <span className="spinner" /> : <Icon name="sparkles" size={14} />} Review {mode === 'complete' ? 'all rules' : 'filtered set'}
            </button>
          </>
        }
      />

      <Card
        title="Filters"
        hint={`${fmtNumber(data?.total ?? 0)} rules match · ${mode === 'complete' ? 'complete review covers every rule in the inventory' : 'filtered review covers only the current matches'}`}
        actions={<button className="btn small" onClick={reset}>Reset filters</button>}
      >
        <div className="search-row mb-12">
          <div className="search-input">
            <Icon name="search" size={15} />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search rule name, number, UID, source, destination, service or comments…" />
          </div>
          <select value={filters.recommendation ?? ''} onChange={(e) => setFilter('recommendation', e.target.value)} style={{ maxWidth: 180 }}>
            <option value="">All recommendations</option>
            {['KEEP', 'REVIEW', 'DISABLE', 'DELETE'].map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
          <select value={filters.traffic ?? ''} onChange={(e) => setFilter('traffic', e.target.value)} style={{ maxWidth: 190 }}>
            <option value="">Any traffic activity</option>
            <option value="recent">Recently active</option>
            <option value="stale">Not recently active</option>
            <option value="active">Any matching traffic</option>
            <option value="zero">Zero traffic in window</option>
            <option value="unknown">No log evidence</option>
          </select>
          <select value={filters.risk ?? ''} onChange={(e) => setFilter('risk', e.target.value)} style={{ maxWidth: 150 }}>
            <option value="">Any risk</option>
            {['Critical', 'High', 'Medium', 'Low'].map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
          <button className="btn small" onClick={() => setShowAdvanced((v) => !v)}>{showAdvanced ? 'Hide advanced' : 'Advanced filters'}</button>
        </div>

        {showAdvanced ? (
          <div className="filters">
            <div className="field"><label>Rule name</label><input value={filters.rule_name ?? ''} onChange={(e) => setFilter('rule_name', e.target.value)} /></div>
            <div className="field"><label>Rule number</label><input value={filters.rule_number ?? ''} onChange={(e) => setFilter('rule_number', e.target.value)} /></div>
            <div className="field"><label>Rule UID</label><input value={filters.rule_uid ?? ''} onChange={(e) => setFilter('rule_uid', e.target.value)} /></div>
            <div className="field"><label>Source</label><input value={filters.source ?? ''} onChange={(e) => setFilter('source', e.target.value)} /></div>
            <div className="field"><label>Destination</label><input value={filters.destination ?? ''} onChange={(e) => setFilter('destination', e.target.value)} /></div>
            <div className="field"><label>Service</label><input value={filters.service ?? ''} onChange={(e) => setFilter('service', e.target.value)} /></div>
            <div className="field"><label>Security section</label>
              <select value={filters.security_section ?? ''} onChange={(e) => setFilter('security_section', e.target.value)}>
                <option value="">All sections</option>
                {(options?.sections ?? []).map((s: string) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="field"><label>Action</label>
              <select value={filters.action ?? ''} onChange={(e) => setFilter('action', e.target.value)}>
                <option value="">Accept &amp; Drop</option>
                <option value="Accept">Accept</option>
                <option value="Drop">Drop</option>
              </select>
            </div>
            <div className="field"><label>Change records</label>
              <select value={filters.change_record ?? ''} onChange={(e) => setFilter('change_record', e.target.value)}>
                <option value="">Any</option><option value="present">Linked</option><option value="missing">Missing</option>
              </select>
            </div>
            <div className="field"><label>Change task state</label>
              <select value={filters.change_state ?? ''} onChange={(e) => setFilter('change_state', e.target.value)}>
                <option value="">Any state</option>
                {(options?.change_states ?? []).map((s: string) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="field"><label>Assigned owner</label>
              <select value={filters.owner ?? ''} onChange={(e) => setFilter('owner', e.target.value)}>
                <option value="">Any owner</option>
                <option value="unknown">Unknown / missing</option>
                {(options?.owners ?? []).map((s: string) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="field"><label>Expiry status</label>
              <select value={filters.expiry ?? ''} onChange={(e) => setFilter('expiry', e.target.value)}>
                <option value="">Any</option><option value="expired">Expired</option><option value="not_expired">Not expired</option><option value="unknown">Unknown</option>
              </select>
            </div>
            <div className="field"><label>Last hit from</label><input type="date" value={filters.last_hit_from ?? ''} onChange={(e) => setFilter('last_hit_from', e.target.value)} /></div>
            <div className="field"><label>Last hit to</label><input type="date" value={filters.last_hit_to ?? ''} onChange={(e) => setFilter('last_hit_to', e.target.value)} /></div>
            <div className="field"><label>AI narration</label>
              <select value={filters.ai_generated ?? ''} onChange={(e) => setFilter('ai_generated', e.target.value)}>
                <option value="">Any</option><option value="yes">Generated</option><option value="no">Not generated</option>
              </select>
            </div>
          </div>
        ) : (
          <div className="spark">
            Quick filters are active above. Use <strong>Advanced filters</strong> for rule UID, owner, expiry, change state and last-hit dates.
          </div>
        )}
      </Card>

      <Card
        className="mt-16"
        title="Rule inventory"
        hint="Click a rule name for the complete traffic, change-history and AI review"
        actions={
          <div className="flex items-center gap-8">
            <span className="spark">{selected.size ? `${selected.size} selected` : ''}</span>
            <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} style={{ width: 110 }}>
              {[25, 50, 100, 200].map((n) => <option key={n} value={n}>{n} / page</option>)}
            </select>
          </div>
        }
        tight
      >
        {error ? <div style={{ padding: 16 }}><Alert tone="error">{error}</Alert></div> : null}
        {loading ? <Loading label="Loading rules…" /> : null}
        {!loading && items.length === 0 ? (
          <div className="table-empty">
            No rules match the current filters.
            {!currentRunId ? <div className="mt-8">No completed analysis run selected. <Link to="/uploads">Start an analysis</Link>.</div> : null}
          </div>
        ) : null}
        {!loading && items.length > 0 ? (
          <>
            <div className="table-wrap" style={{ maxHeight: '62vh' }}>
              <table>
                <thead>
                  <tr>
                    <th style={{ width: 34 }}><input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} aria-label="Select page" /></th>
                    {header('Rule #', 'rule_number', 'nowrap')}
                    {header('Rule name', 'rule_name')}
                    <th>Security section</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Service</th>
                    {header('Action', 'action', 'nowrap')}
                    {header('Hits', 'hit_count', 'num')}
                    {header('Last hit', 'last_hit', 'nowrap')}
                    {header('Avg/day', 'avg_per_day', 'num')}
                    <th>Change request</th>
                    <th>Change task</th>
                    <th>Change status</th>
                    {header('Owner', 'owner')}
                    <th>Expiry</th>
                    {header('Recommendation', 'category', 'nowrap')}
                    {header('Risk', 'risk_level', 'nowrap')}
                    <th>AI</th>
                    <th>Review</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((r) => (
                    <tr key={r.id} className={selected.has(r.id) ? 'selected' : ''}>
                      <td><input type="checkbox" checked={selected.has(r.id)} onChange={() => toggleOne(r.id)} aria-label={`Select rule ${r.rule_number}`} /></td>
                      <td className="nowrap mono">{r.rule_number}</td>
                      <td style={{ minWidth: 190 }}>
                        <Link className="link-strong" to={`/rules/${r.id}`}>{r.rule_name || '(unnamed rule)'}</Link>
                        <div className="cell-sub uid">{r.rule_uid}</div>
                      </td>
                      <td className="nowrap">{r.security_section || '—'}</td>
                      <td style={{ maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis' }} className="nowrap" title={r.source}>{r.source || '—'}</td>
                      <td style={{ maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis' }} className="nowrap" title={r.destination}>{r.destination || '—'}</td>
                      <td style={{ maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis' }} className="nowrap" title={r.service}>{r.service || '—'}</td>
                      <td className="nowrap"><Badge value={r.action} kind="action" /></td>
                      <td className="num nowrap">{r.hit_count === null ? '—' : fmtNumber(r.hit_count)}</td>
                      <td className="nowrap">{r.last_hit ? new Date(r.last_hit).toLocaleDateString() : <span className="text-muted">none</span>}</td>
                      <td className="num">{fmtNumber(r.avg_per_day, 2)}</td>
                      <td className="nowrap mono">{r.change_request || <span className="text-muted">missing</span>}</td>
                      <td className="nowrap mono">{r.change_task || <span className="text-muted">—</span>}</td>
                      <td className="nowrap">{r.change_status || <span className="text-muted">unknown</span>}</td>
                      <td className="nowrap">{r.owner || <span className="text-muted">unknown</span>}</td>
                      <td className="nowrap"><Badge value={r.expiry_status} kind="neutral" /></td>
                      <td className="nowrap"><Badge value={r.recommendation} />{r.eligible_for ? <div className="cell-sub">eligible {r.eligible_for}</div> : null}</td>
                      <td className="nowrap"><Badge value={r.risk_level} kind="risk" /></td>
                      <td className="nowrap" title={r.ai_generated ? 'AI narration generated' : 'No AI narration yet'}>{r.ai_generated ? <span className="dot green" /> : <span className="dot grey" />}</td>
                      <td className="nowrap">
                        {r.accepted ? (
                          <span className="badge keep" title="Recommendation accepted">accepted</span>
                        ) : (
                          <button
                            className="btn small"
                            disabled={accepting === r.id}
                            title="Accept this recommendation (recorded in the audit trail; does not change the category)"
                            onClick={() => acceptRule(r.id)}
                          >
                            {accepting === r.id ? <span className="spinner" /> : <Icon name="check" size={12} />} Accept
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="pagination">
              <span>{fmtNumber(data!.total)} rules · page {data!.page} of {data!.pages || 1}</span>
              <span className="spacer" />
              <div className="pages">
                <button className="page-btn" disabled={page <= 1} onClick={() => setPage(1)}>«</button>
                <button className="page-btn" disabled={page <= 1} onClick={() => setPage(page - 1)}>‹</button>
                {Array.from({ length: Math.min(7, data!.pages || 1) }, (_, i) => {
                  const total = data!.pages || 1;
                  const start = Math.max(1, Math.min(page - 3, total - 6));
                  return start + i;
                }).filter((p) => p >= 1 && p <= (data!.pages || 1)).map((p) => (
                  <button key={p} className={`page-btn ${p === page ? 'active' : ''}`} onClick={() => setPage(p)}>{p}</button>
                ))}
                <button className="page-btn" disabled={page >= (data!.pages || 1)} onClick={() => setPage(page + 1)}>›</button>
                <button className="page-btn" disabled={page >= (data!.pages || 1)} onClick={() => setPage(data!.pages)}>»</button>
              </div>
            </div>
          </>
        ) : null}
      </Card>
      <div className="spark mt-8">
        Average frequency is calculated from matching log events per rule within the observation window. Inventory hit counters are displayed separately and never substituted.
      </div>
    </>
  );
}
