export type Category = 'KEEP' | 'REVIEW' | 'DISABLE' | 'DELETE' | string;

export interface RunSummary {
  id: number;
  label: string;
  status: string;
  stage: string;
  progress: number;
  message: string;
  created_at: string;
  started_at?: string | null;
  finished_at?: string | null;
  is_synthetic: boolean;
  ai_enabled: boolean;
  stats: Record<string, any>;
  policy: Record<string, any>;
  error?: string;
  parent_run_id?: number | null;
  uploads?: { rules?: number; changes?: number; logs?: number };
}

export interface DashboardData {
  empty: boolean;
  message?: string;
  run?: RunSummary;
  policy?: Record<string, any>;
  metrics?: Record<string, number>;
  cards?: { key: string; label: string; value: number; target: string }[];
  charts?: {
    recommendations: { name: string; value: number }[];
    risk: { name: string; value: number }[];
    traffic_histogram: { name: string; value: number }[];
    sections: { section: string; rules: number; active: number; accept: number; drop: number }[];
    action_split: { name: string; value: number }[];
    change_coverage: { name: string; value: number }[];
    traffic_over_time: { date: string; count: number }[];
    top_rules: { name: string; value: number }[];
  };
  top_used?: RuleBrief[];
  no_activity?: RuleBrief[];
  traffic_summary?: Record<string, any>;
  executive_summary?: { text?: string; generated?: boolean; model?: string; warnings?: string[] };
  jobs?: { id: number; kind: string; status: string; progress: number; message: string }[];
}

export interface RuleBrief {
  id: number;
  rule_number: string;
  rule_name: string;
  security_section: string;
  action: string;
  event_count: number;
  days_since_last_hit: number | null;
  recommendation: string;
  risk_level: string;
}

export interface RuleRow extends RuleBrief {
  run_id: number;
  rule_uid: string;
  source: string;
  destination: string;
  service: string;
  hit_count: number | null;
  hits_raw: string;
  first_hit: string | null;
  last_hit: string | null;
  log_event_count: number;
  window_event_count: number;
  avg_per_day: number;
  avg_per_week: number;
  avg_per_month: number;
  days_since_last_hit: number | null;
  last_seen: string | null;
  traffic_state: string;
  logs_supplied: boolean;
  absence_is_evidence: boolean;
  match_method: string;
  match_confidence: number;
  change_request: string;
  change_task: string;
  change_status: string;
  owner: string;
  expiry_status: string;
  recommendation: string;
  risk_level: string;
  confidence: string;
  approval_status: string;
  accepted?: boolean;
  eligible_for: string;
  ai_generated: boolean;
  reason_preview: string;
  missing_count: number;
}

export interface RuleListResponse {
  run_id: number | null;
  items: RuleRow[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
}

export interface UploadSummary {
  id: number;
  dataset_type: 'rules' | 'changes' | 'logs';
  dataset_label: string;
  original_filename: string;
  size_bytes: number;
  file_kind: string;
  sheet_name: string | null;
  sheets: string[];
  row_count: number;
  status: string;
  is_synthetic: boolean;
  is_replacement_of?: number | null;
  uploaded_at: string;
  uploaded_by: string;
  validation: Record<string, any>;
  mapping: Record<string, string | null>;
  mapping_scores: Record<string, number>;
  unmapped_columns: string[];
  warnings: string[];
  missing_required: string[];
  detected_sheets: { sheet_name: string; score: number; missing: string[] }[];
  notes: string;
}

export interface PreviewResponse {
  upload_id: number;
  dataset_type: string;
  dataset_label: string;
  original_filename: string;
  size_bytes: number;
  file_kind: string;
  sheet_name: string | null;
  sheets: string[];
  header_row: number;
  columns: string[];
  rows: Record<string, unknown>[];
  record_count: number;
  detection: {
    mapping: Record<string, string | null>;
    scores: Record<string, number>;
    unmapped_columns: string[];
    missing_required: string[];
    warnings: string[];
    needs_manual_mapping: boolean;
  };
  fields: { key: string; label: string; required: boolean; description: string; value_hint: string }[];
  uploaded_at: string;
  status: string;
  is_synthetic: boolean;
  warnings: string[];
}

export interface RuleDetail {
  accepted?: boolean;
  rule: Record<string, any>;
  traffic: Record<string, any>;
  changes: Record<string, any>[];
  change_summary: { count: number; documented: boolean; multiple: boolean; conflicting: boolean; owners: string[] };
  recommendation: Record<string, any>;
  approvals: { kind: string; approved_by: string; approved_at: string; note: string; source: string }[];
  disable_evidence: { disabled_at: string; monitored_until: string | null; change_reference: string; note: string }[];
  traceability: Record<string, any>;
  policy: Record<string, any>;
}

export interface TrafficWindow {
  matched: boolean;
  absence_is_evidence: boolean;
  notes: string;
  start: string;
  end: string;
  days: number;
  total_events: number;
  active_days: number;
  inactive_days: number;
  avg_per_day: number;
  avg_per_week: number;
  avg_per_month: number;
  avg_per_hour: number;
  first_seen: string | null;
  last_seen: string | null;
  series: { date: string; count: number }[];
  hourly: { hour: number; count: number }[];
  protocols: { protocol: string; count: number }[];
  top_sources: { value: string; count: number }[];
  top_destinations: { value: string; count: number }[];
  match_method: string;
  match_confidence: number;
  log_coverage_days: number;
}
