import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';

/* ---------------- icons ---------------- */
const paths: Record<string, React.ReactNode> = {
  dashboard: <><rect x="3" y="3" width="7" height="8" rx="1" /><rect x="14" y="3" width="7" height="5" rx="1" /><rect x="3" y="15" width="7" height="6" rx="1" /><rect x="14" y="12" width="7" height="9" rx="1" /></>,
  upload: <><path d="M12 16V4" /><path d="m7 9 5-5 5 5" /><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" /></>,
  rules: <><path d="M4 6h16M4 12h16M4 18h10" /><circle cx="18" cy="18" r="2.5" /></>,
  runs: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  reports: <><path d="M6 2h9l4 4v16H6z" /><path d="M15 2v4h4" /><path d="M9 13h6M9 17h6" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 7 19.4a1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a1.7 1.7 0 0 0-1.6-1H1a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 3 9a1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 9 3a1.7 1.7 0 0 0 1-1.6V1a2 2 0 1 1 4 0v.1A1.7 1.7 0 0 0 15 3a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 9h.1a2 2 0 1 1 0 4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
  shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
  download: <><path d="M12 3v12" /><path d="m7 10 5 5 5-5" /><path d="M5 21h14" /></>,
  refresh: <><path d="M21 12a9 9 0 1 1-3-6.7" /><path d="M21 3v6h-6" /></>,
  chevron: <><path d="m9 18 6-6-6-6" /></>,
  sparkles: <><path d="M12 3v4M12 17v4M3 12h4M17 12h4" /><path d="m6.3 6.3 2.8 2.8M14.9 14.9l2.8 2.8M17.7 6.3l-2.8 2.8M9.1 14.9l-2.8 2.8" /></>,
  check: <><path d="m4 12 5 5L20 6" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
};

export function Icon({ name, size = 16 }: { name: keyof typeof paths | string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name] ?? paths.rules}
    </svg>
  );
}

/* ---------------- badges ---------------- */
export function Badge({ value, kind }: { value: string; kind?: 'action' | 'risk' | 'confidence' | 'neutral' }) {
  const raw = String(value ?? '').trim();
  const key = raw.toLowerCase();
  let cls = 'neutral';
  if (kind === 'risk') {
    cls = ['critical', 'high', 'medium', 'low'].includes(key) ? key : 'neutral';
  } else if (kind === 'action') {
    cls = key === 'accept' ? 'accept' : key === 'drop' ? 'drop' : 'neutral';
  } else if (kind === 'confidence') {
    cls = key === 'high' ? 'low' : key === 'medium' ? 'medium' : key === 'low' ? 'high' : 'neutral';
  } else if (['keep', 'review', 'disable', 'delete'].includes(key)) {
    cls = key;
  }
  return <span className={`badge ${cls}`}>{raw || '—'}</span>;
}

export function SyntheticBadge() {
  return <span className="badge synthetic" title="Generated test data, not customer traffic">Synthetic data</span>;
}

/* ---------------- layout bits ---------------- */
export function PageHead({ title, lede, actions }: { title: string; lede?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="page-head">
      <div>
        <h1>{title}</h1>
        {lede ? <div className="lede">{lede}</div> : null}
      </div>
      {actions ? <div className="page-actions">{actions}</div> : null}
    </div>
  );
}

export function Card({ title, hint, actions, children, tight, className }: { title?: React.ReactNode; hint?: React.ReactNode; actions?: React.ReactNode; children: React.ReactNode; tight?: boolean; className?: string }) {
  return (
    <section className={`card ${className ?? ''}`}>
      {title ? (
        <div className="card-header">
          <div>
            <h2>{title}</h2>
            {hint ? <div className="hint">{hint}</div> : null}
          </div>
          {actions}
        </div>
      ) : null}
      <div className={`card-body ${tight ? 'tight' : ''}`}>{children}</div>
    </section>
  );
}

export function Metric({ label, value, sub, accent, to }: { label: string; value: React.ReactNode; sub?: string; accent?: string; to: string }) {
  return (
    <Link to={to} className={`metric ${accent ? `accent-${accent}` : ''}`}>
      <div className="label">{label}</div>
      <div className="value">{typeof value === 'number' ? value.toLocaleString() : value}</div>
      {sub ? <div className="sub">{sub}</div> : null}
    </Link>
  );
}

export function Loading({ label = 'Loading…' }: { label?: string }) {
  return <div className="loading-row"><span className="spinner" />{label}</div>;
}

export function Alert({ tone = 'info', children }: { tone?: 'info' | 'warn' | 'error' | 'success'; children: React.ReactNode }) {
  return <div className={`alert ${tone}`}>{children}</div>;
}

export function EmptyState({ title, children, actions }: { title: string; children?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="empty-state">
      <h2>{title}</h2>
      {children ? <div>{children}</div> : null}
      {actions ? <div className="actions">{actions}</div> : null}
    </div>
  );
}

export function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="btn subtle icon" onClick={onClose} aria-label="Close"><Icon name="close" /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer ? <div className="modal-foot">{footer}</div> : null}
      </div>
    </div>
  );
}

export function Progress({ value, label }: { value: number; label?: string }) {
  return (
    <div>
      <div style={{ height: 5, background: '#e8edf4', borderRadius: 4, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${Math.max(0, Math.min(100, value))}%`, background: '#2b4a7d', transition: 'width .3s ease' }} />
      </div>
      {label ? <div className="cell-sub">{label}</div> : null}
    </div>
  );
}

/* ---------------- toast ---------------- */
type Toast = { id: number; message: string; tone: 'info' | 'success' | 'error' };
const ToastCtx = createContext<{ push: (m: string, tone?: Toast['tone']) => void }>({ push: () => {} });
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((message: string, tone: Toast['tone'] = 'info') => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev, { id, message, tone }]);
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4200);
  }, []);
  const value = useMemo(() => ({ push }), [push]);
  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div className="toast-stack">
        {items.map((t) => <div key={t.id} className={`toast ${t.tone}`}>{t.message}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}

/* ---------------- helpers ---------------- */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fn()
      .then((res) => { if (!cancelled) setData(res); })
      .catch((e) => { if (!cancelled) setError(e?.message || String(e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return { data, error, loading, setData };
}
