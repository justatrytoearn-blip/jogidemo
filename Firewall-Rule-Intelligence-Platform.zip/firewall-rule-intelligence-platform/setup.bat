@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Firewall Rule Intelligence Platform - setup

echo ============================================================
echo  Firewall Rule Intelligence Platform - one-time setup
echo ============================================================
echo This installs Python dependencies and, when available, builds
echo the frontend and starts the local n8n container. Nothing is
echo sent to an external service. No firewall is ever changed.
echo.

set "PY="
where py >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  where python >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo [ERROR] Python 3.11+ was not found on PATH.
  echo         Install it from https://www.python.org/downloads/ and re-run setup.bat
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Creating virtual environment .venv ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo [ERROR] Could not create the virtual environment.
    pause
    exit /b 1
  )
) else (
  echo [1/5] Virtual environment already exists.
)

echo [2/5] Installing Python dependencies ...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERROR] Dependency installation failed. See the output above.
  pause
  exit /b 1
)

echo [3/5] Checking the frontend build ...
where npm >nul 2>&1
if errorlevel 1 (
  echo       Node.js/npm not found - using the existing frontend\dist build if present.
) else (
  if not exist "frontend\dist\index.html" (
    pushd frontend
    call npm install
    call npm run build
    popd
  ) else (
    echo       Frontend build present.
  )
)

echo [4/5] Checking local AI (Ollama) ...
where ollama >nul 2>&1
if errorlevel 1 (
  echo       Ollama not installed - AI explanations stay disabled until it is available.
  echo       Deterministic recommendations and reports work without it.
) else (
  ollama list | findstr /C:"qwen2.5:1.5b" >nul 2>&1
  if errorlevel 1 (
    echo       Pulling qwen2.5:1.5b ^(about 1 GB, CPU-friendly^) ...
    ollama pull qwen2.5:1.5b
  ) else (
    echo       Model qwen2.5:1.5b already present.
  )
)

echo [5/5] Checking n8n orchestration ...
where docker >nul 2>&1
if errorlevel 1 (
  echo       Docker not installed - n8n workflows unavailable. The portal works without them.
  goto finish
)
docker info >nul 2>&1
if errorlevel 1 (
  echo       Docker is not running - start Docker Desktop, then run setup.bat again
  echo       to enable the n8n workflows.
  goto finish
)

if not exist "n8n\.env" (
  echo       Generating the n8n API key and encryption key ...
  ".venv\Scripts\python.exe" -c "from backend.config import api_key; import pathlib, secrets; key=api_key(); pathlib.Path('n8n/.env').write_text('FIP_BASE_URL=http://host.docker.internal:8080
FIP_PORTAL_URL=http://127.0.0.1:8080\nFIP_API_KEY=' + key + '\nN8N_ENCRYPTION_KEY=' + secrets.token_hex(24) + '\nN8N_USER_MANAGEMENT_DISABLED=false\n', encoding='utf-8')"
)

docker compose -f "n8n\docker-compose.yml" up -d
if errorlevel 1 (
  echo       [WARN] Could not start the n8n container. See: docker compose -f n8n\docker-compose.yml logs
  goto finish
)

echo       Waiting for n8n to become ready ...
ping -n 21 127.0.0.1 >nul
docker exec fip-n8n n8n import:workflow --separate --input=/workflows >nul 2>&1
docker exec fip-n8n n8n update:workflow --id=fip-wf-chat --active=true >/dev/null 2>&1
for %%W in (00 01 02 03 04 05 06) do docker exec fip-n8n n8n update:workflow --id=fip-wf-%%W --active=true >nul 2>&1
docker restart fip-n8n >nul 2>&1
echo       n8n ready at http://127.0.0.1:5679 (workflows active).

:finish
echo.
echo Setup finished. Run start.bat to open the portal at http://127.0.0.1:8080
echo First start generates config\admin_credentials.txt (login is disabled by default).
echo.
pause
