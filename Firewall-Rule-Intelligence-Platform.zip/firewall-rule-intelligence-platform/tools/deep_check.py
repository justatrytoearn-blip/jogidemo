import pandas as pd

R = "samples/firewall_rule_list_POC_200_Rules.xlsx"
inv = pd.read_excel(R, sheet_name="FW-Corp 11", header=0)
inv.columns = [str(c).strip() for c in inv.columns]
print("inv cols", list(inv.columns))
print("types", inv["Type"].value_counts(dropna=False).to_dict())
print("sections(raw Hits where Type=Section):", inv.loc[inv["Type"].astype(str).str.strip()=="Section","Hits"].tolist())
rules = inv[inv["Type"].astype(str).str.strip()=="Rule"]
print("rule rows:", len(rules), "unique rule numbers:", rules["Rule Number"].nunique())
print("dup rule numbers:", rules["Rule Number"].duplicated().sum())
print("unique uid:", rules["Uid"].nunique(), "unique names:", rules["Name"].nunique())
print(rules["Action"].value_counts(dropna=False).to_dict())
print("sample hits values:", rules["Hits"].astype(str).unique()[:8])

rel = pd.read_excel(R, sheet_name="Rule_Change_Relationship", header=0)
rel.columns=[str(c).strip() for c in rel.columns]
print("\nrel rows", len(rel), "uniq rule numbers", rel["Rule Number"].nunique(), "uniq uid", rel["Rule UID"].nunique())
print("rel sections", rel["Security Section"].value_counts().to_dict())
print("rel change reqs", rel["Primary Change Request"].nunique(), "ctasks", rel["Linked CTASK Number"].nunique())

ct = pd.read_excel("samples/change_task_POC_200_Entries.xlsx", sheet_name="Page 1", header=0)
ct.columns=[str(c).strip() for c in ct.columns]
print("\nct rows", len(ct), "states", ct["State"].value_counts(dropna=False).to_dict())
print("ct uniq", ct["Number"].nunique(), "chg uniq", ct["Change request"].nunique())
print("ct nulls", ct.isna().sum().to_dict())

logs = pd.read_excel("samples/Logs_Nov_5_2026_Firewall_POC_2000_Entries.xlsx", sheet_name=0, header=0)
logs.columns=[str(c).strip() for c in logs.columns]
print("\nlogs rows", len(logs))
inv_uids = set(rules["Uid"].astype(str).str.lower())
print("log rule uid overlap:", len(set(logs["Rule UID"].astype(str).str.lower()) & inv_uids))
print("log Rule values:", sorted(set(logs["Rule"].astype(str)))[:20], "...count", logs["Rule"].nunique())
inv_nums = set(rules["Rule Number"].astype(str))
print("log Rule numeric overlap (as int before dot):", len({str(x).split('.')[0] for x in logs['Rule'].astype(str)} & inv_nums))
inv_names = set(rules["Name"].astype(str).str.strip().str.lower())
log_names = set(logs["Access Rule Name"].astype(str).str.strip().str.lower())
print("log name overlap with inventory names:", len(log_names & inv_names))
print("log names sample:", list(log_names)[:10])
print("log time range:", logs["Time"].min(), "->", logs["Time"].max())
print("log action:", logs["Action"].value_counts().to_dict())
print("log null counts:", logs.isna().sum().sort_values(ascending=False).head(8).to_dict())

l2 = pd.read_excel("samples/firewall_logs_1000.xlsx", header=0)
l2.columns=[str(c).strip() for c in l2.columns]
print("\nlogs1000 rows", len(l2), "action", l2["Action"].value_counts().to_dict())
print("overlap names", len(set(l2["Access Rule Name"].astype(str).str.lower()) & inv_names))
print("rules", sorted(set(l2["Rule"].astype(str))), "time", l2["Time"].min(), l2["Time"].max())

# do rule numbers restart per section?
sec = None; rows=[]
for _, r in inv.iterrows():
    if str(r["Type"]).strip()=="Section": sec = r["Hits"]
    elif str(r["Type"]).strip()=="Rule": rows.append((sec, r["Rule Number"], r["Name"]))
df = pd.DataFrame(rows, columns=["section","num","name"])
print("\nper-section rule counts:", df.groupby("section").size().to_dict())
print("section+num dup:", df.duplicated(["section","num"]).sum(), "num dup overall:", df["num"].duplicated().sum())
print("first/last per section:", df.groupby("section")["num"].agg(["min","max"]).to_dict())
