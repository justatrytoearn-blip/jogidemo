import pandas as pd, glob, os, sys

pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 60)

for f in sorted(glob.glob("samples/*.xlsx")) + sorted(glob.glob("samples/*.csv")):
    print("=" * 100)
    print("FILE:", f, os.path.getsize(f))
    try:
        if f.endswith(".csv"):
            df = pd.read_csv(f, nrows=8)
            print("CSV shape (sample 8):", df.shape)
            print(df.head(5).to_string())
            print("COLS:", list(df.columns))
            continue
        xl = pd.ExcelFile(f)
        for sh in xl.sheet_names:
            df = pd.read_excel(f, sheet_name=sh, header=None)
            print("-" * 90)
            print("SHEET:", repr(sh), "shape:", df.shape)
            print(df.head(12).to_string(max_colwidth=40))
    except Exception as e:
        print("ERROR", e)
