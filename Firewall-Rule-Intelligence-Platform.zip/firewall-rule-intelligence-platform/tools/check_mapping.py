"""Validate auto-mapping + normalisation against the real sample workbooks."""
from __future__ import annotations

import json

import pandas as pd

from backend.services import file_reader
from backend.services.column_mapper import detect_mapping
from backend.services.normalize import normalize_changes, normalize_rules

FILES = {
    "rules": "samples/firewall_rule_list_POC_200_Rules.xlsx",
    "changes": "samples/change_task_POC_200_Entries.xlsx",
    "logs2000": "samples/Logs_Nov_5_2026_Firewall_POC_2000_Entries.xlsx",
    "logs1000": "samples/firewall_logs_1000.xlsx",
    "rules_csv": "samples/firewall_rules_1000.csv",
}

for label, path in FILES.items():
    dataset = "logs" if label.startswith("logs") else ("changes" if label == "changes" else "rules")
    kind = "csv" if path.endswith(".csv") else "xlsx"
    sheets = file_reader.list_sheets(path, kind) or [None]
    print("=" * 90)
    print(label, "sheets:", sheets)
    for sheet in sheets:
        preview = file_reader.read_preview(path, kind, sheet, nrows=25)
        mapping = detect_mapping(preview["columns"], dataset, pd.DataFrame(preview["rows"]))
        print(f"  sheet={sheet!r} header_row={preview['header_row']} missing={mapping.missing_required}")
        print("   mapping:", {k: v for k, v in mapping.mapping.items() if v})
        if label == "rules" and sheet == "FW-Corp 11":
            recs = []
            for chunk in file_reader.iter_chunks(path, kind, sheet, preview["header_row"], preview["columns"]):
                recs.extend(chunk)
            out = normalize_rules(recs, mapping.mapping, path, sheet)
            print("   STATS:", json.dumps(out["stats"], indent=2)[:900])
            print("   first rule:", {k: out["records"][0][k] for k in ("rule_number", "rule_name", "security_section", "action", "hit_count", "first_hit", "last_hit")})
            print("   sections seen:", sorted({r["security_section"] for r in out["records"]}))
            print("   zero hit rules:", sum(1 for r in out["records"] if r["hit_count"] == 0))
            print("   no last_hit:", sum(1 for r in out["records"] if not r["last_hit"]))
        if label == "changes" and sheet == "Page 1":
            recs = []
            for chunk in file_reader.iter_chunks(path, kind, sheet, preview["header_row"], preview["columns"]):
                recs.extend(chunk)
            out = normalize_changes(recs, mapping.mapping, path, sheet)
            print("   STATS:", json.dumps(out["stats"], indent=2)[:600])
            print("   first:", {k: out["records"][0][k] for k in ("ctask_number", "chg_number", "state", "assigned_to", "planned_end_date")})
        if str(label).startswith("logs"):
            print("   sample:", preview["rows"][0])
