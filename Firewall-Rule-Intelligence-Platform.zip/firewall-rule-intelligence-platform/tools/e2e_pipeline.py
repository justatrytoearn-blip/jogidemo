"""End-to-end pipeline smoke test against the supplied workbooks."""
from __future__ import annotations

import json
import sys

from backend.database.db import init_db, session_scope
from backend.services import import_service
from backend.services.analysis import create_run, execute_run


def upload(db, dataset_type, path, synthetic=False):
    with open(path, "rb") as fh:
        up = import_service.create_upload(db, dataset_type, path.split("/")[-1], fh, is_synthetic=synthetic)
    stored = json.loads(up.mapping_json or "{}")
    mapping = {k: v for k, v in stored.get("mapping", {}).items() if v}
    up = import_service.confirm_mapping(db, up.id, mapping, up.sheet_name)
    print(f"upload {dataset_type}: id={up.id} rows={up.row_count} status={up.status} sheet={up.sheet_name}")
    validation = json.loads(up.validation_json or "{}")
    print("  validation:", json.dumps(validation, default=str)[:400])
    return up


def main():
    init_db()
    with session_scope() as db:
        rules = upload(db, "rules", "samples/firewall_rule_list_POC_200_Rules.xlsx")
        changes = upload(db, "changes", "samples/change_task_POC_200_Entries.xlsx")
        logs = upload(db, "logs", "samples/Logs_Nov_5_2026_Firewall_POC_2000_Entries.xlsx")
        run = create_run(db, rules.id, changes.id, logs.id, "Smoke test - real sample files", ai_enabled=False)
        run_id = run.id
    print("run id", run_id)
    stats = execute_run(run_id)
    print(json.dumps({k: stats[k] for k in ("total_rules", "keep", "review", "disable", "delete", "rules_with_change_records", "rules_without_change_records", "without_owner", "with_zero_traffic", "matched_rules", "unmatched_rules", "processing_seconds")}, indent=2))
    print("traffic summary:", json.dumps(stats["traffic"], indent=2, default=str)[:1500])
    print("change stats:", json.dumps(stats["change_stats"], indent=2, default=str)[:800])

    from backend.database.models import Recommendation, Rule, TrafficMetric
    from backend.database.db import session_scope as ss
    from sqlalchemy import select

    with ss() as db:
        sample = db.execute(select(Rule, Recommendation).join(Recommendation, Recommendation.rule_id == Rule.id).where(Rule.run_id == run_id).order_by(Rule.id)).first()
        rule, rec = sample
        print("\nSample rule:", rule.rule_number, rule.rule_name, rule.action, "hits:", rule.hit_count)
        print("change:", rec.change_request, rec.change_task, rec.change_status, "owner:", rec.owner)
        print("category:", rec.category, "risk:", rec.risk_level, "confidence:", rec.confidence, "expiry:", rec.expiry_status)
        print("missing:", rec.missing_json)
        print("reason:", rec.reason[:400])
        m = db.execute(select(TrafficMetric).where(TrafficMetric.rule_id == rule.id)).scalars().first()
        print("metric:", m.matched, m.event_count, m.match_method)


if __name__ == "__main__":
    sys.exit(main())
