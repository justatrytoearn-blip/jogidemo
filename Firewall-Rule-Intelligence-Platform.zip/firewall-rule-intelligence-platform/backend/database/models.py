"""SQLAlchemy models. Portable between SQLite and PostgreSQL (no SQLite-specific types)."""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def utcnow() -> datetime:
    return datetime.utcnow()


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(16), default="reviewer")  # admin | reviewer
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class SessionToken(Base):
    __tablename__ = "sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    username: Mapped[str] = mapped_column(String(64))
    role: Mapped[str] = mapped_column(String(16))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)


class Upload(Base):
    __tablename__ = "uploads"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dataset_type: Mapped[str] = mapped_column(String(32), index=True)  # rules | changes | logs
    original_filename: Mapped[str] = mapped_column(String(512))
    stored_path: Mapped[str] = mapped_column(String(1024))
    file_kind: Mapped[str] = mapped_column(String(16))  # xlsx | xls | csv
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    checksum: Mapped[str] = mapped_column(String(64), default="")
    sheet_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(24), default="uploaded")  # uploaded|mapped|processed|failed
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    is_replacement_of: Mapped[int | None] = mapped_column(Integer, nullable=True)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    uploaded_by: Mapped[str] = mapped_column(String(64), default="local")
    mapping_json: Mapped[str] = mapped_column(Text, default="{}")
    detection_json: Mapped[str] = mapped_column(Text, default="{}")
    validation_json: Mapped[str] = mapped_column(Text, default="{}")
    sheets_json: Mapped[str] = mapped_column(Text, default="[]")
    notes: Mapped[str] = mapped_column(Text, default="")


class Run(Base):
    __tablename__ = "runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    label: Mapped[str] = mapped_column(String(255), default="Analysis run")
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    stage: Mapped[str] = mapped_column(String(64), default="queued")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_by: Mapped[str] = mapped_column(String(64), default="local")
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    ai_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    ai_model: Mapped[str] = mapped_column(String(128), default="")
    policy_json: Mapped[str] = mapped_column(Text, default="{}")
    stats_json: Mapped[str] = mapped_column(Text, default="{}")
    error: Mapped[str] = mapped_column(Text, default="")
    parent_run_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rules_upload_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    changes_upload_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    logs_upload_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

    rules: Mapped[list["Rule"]] = relationship(back_populates="run", cascade="all, delete-orphan")


class Rule(Base):
    __tablename__ = "rules"
    __table_args__ = (
        Index("ix_rules_run_number", "run_id", "rule_number"),
        Index("ix_rules_run_uid", "run_id", "rule_uid"),
        Index("ix_rules_run_name", "run_id", "rule_name"),
        Index("ix_rules_run_section", "run_id", "security_section"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_number: Mapped[str] = mapped_column(String(64), default="")
    rule_name: Mapped[str] = mapped_column(String(512), default="")
    rule_uid: Mapped[str] = mapped_column(String(128), default="")
    security_section: Mapped[str] = mapped_column(String(255), default="")
    device: Mapped[str] = mapped_column(String(255), default="")
    source: Mapped[str] = mapped_column(String(1024), default="")
    destination: Mapped[str] = mapped_column(String(1024), default="")
    service: Mapped[str] = mapped_column(String(1024), default="")
    action: Mapped[str] = mapped_column(String(32), default="")
    install_on: Mapped[str] = mapped_column(String(255), default="")
    comments: Mapped[str] = mapped_column(Text, default="")
    vpn: Mapped[str] = mapped_column(String(255), default="")
    track: Mapped[str] = mapped_column(String(255), default="")
    hit_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    hits_raw: Mapped[str] = mapped_column(String(255), default="")
    first_hit: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_hit: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expiry_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    owner_hint: Mapped[str] = mapped_column(String(255), default="")
    raw_json: Mapped[str] = mapped_column(Text, default="{}")
    source_file: Mapped[str] = mapped_column(String(512), default="")
    source_sheet: Mapped[str] = mapped_column(String(255), default="")
    source_row: Mapped[int | None] = mapped_column(Integer, nullable=True)

    run: Mapped[Run] = relationship(back_populates="rules")


class ChangeRecord(Base):
    __tablename__ = "change_records"
    __table_args__ = (
        Index("ix_changes_run_ctask", "run_id", "ctask_number"),
        Index("ix_changes_run_chg", "run_id", "chg_number"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    upload_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    source_kind: Mapped[str] = mapped_column(String(32), default="change_task")  # change_task | rule_relationship
    ctask_number: Mapped[str] = mapped_column(String(64), default="")
    chg_number: Mapped[str] = mapped_column(String(64), default="")
    state: Mapped[str] = mapped_column(String(64), default="")
    assigned_to: Mapped[str] = mapped_column(String(255), default="")
    short_description: Mapped[str] = mapped_column(Text, default="")
    planned_end_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    rule_number: Mapped[str] = mapped_column(String(64), default="")
    rule_uid: Mapped[str] = mapped_column(String(128), default="")
    rule_name: Mapped[str] = mapped_column(String(512), default="")
    raw_json: Mapped[str] = mapped_column(Text, default="{}")
    source_file: Mapped[str] = mapped_column(String(512), default="")
    source_sheet: Mapped[str] = mapped_column(String(255), default="")
    source_row: Mapped[int | None] = mapped_column(Integer, nullable=True)


class RuleChangeLink(Base):
    __tablename__ = "rule_change_links"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"), index=True)
    change_record_id: Mapped[int] = mapped_column(ForeignKey("change_records.id", ondelete="CASCADE"))
    match_method: Mapped[str] = mapped_column(String(48), default="")
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    evidence: Mapped[str] = mapped_column(Text, default="")


class TrafficMetric(Base):
    __tablename__ = "traffic_metrics"
    __table_args__ = (UniqueConstraint("run_id", "rule_id", name="uq_metric_run_rule"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"), index=True)
    matched: Mapped[bool] = mapped_column(Boolean, default=False)
    logs_supplied: Mapped[bool] = mapped_column(Boolean, default=False)
    absence_is_evidence: Mapped[bool] = mapped_column(Boolean, default=False)
    match_method: Mapped[str] = mapped_column(String(48), default="none")
    match_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    event_count: Mapped[int] = mapped_column(Integer, default=0)
    window_event_count: Mapped[int] = mapped_column(Integer, default=0)
    first_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    days_since_last_hit: Mapped[int | None] = mapped_column(Integer, nullable=True)
    observation_days: Mapped[int] = mapped_column(Integer, default=0)
    log_coverage_days: Mapped[int] = mapped_column(Integer, default=0)
    active_days: Mapped[int] = mapped_column(Integer, default=0)
    avg_per_day: Mapped[float] = mapped_column(Float, default=0.0)
    avg_per_week: Mapped[float] = mapped_column(Float, default=0.0)
    avg_per_month: Mapped[float] = mapped_column(Float, default=0.0)
    avg_per_hour: Mapped[float] = mapped_column(Float, default=0.0)
    distinct_sources: Mapped[int] = mapped_column(Integer, default=0)
    distinct_destinations: Mapped[int] = mapped_column(Integer, default=0)
    bytes_total: Mapped[int | None] = mapped_column(Integer, nullable=True)
    packets_total: Mapped[int | None] = mapped_column(Integer, nullable=True)
    protocols_json: Mapped[str] = mapped_column(Text, default="[]")
    top_sources_json: Mapped[str] = mapped_column(Text, default="[]")
    top_destinations_json: Mapped[str] = mapped_column(Text, default="[]")
    daily_json: Mapped[str] = mapped_column(Text, default="[]")
    hourly_json: Mapped[str] = mapped_column(Text, default="[]")
    trend: Mapped[str] = mapped_column(String(24), default="unknown")
    notes: Mapped[str] = mapped_column(Text, default="")


class LogDailyStat(Base):
    __tablename__ = "log_daily_stats"
    __table_args__ = (Index("ix_daily_run_rule_day", "run_id", "rule_id", "day"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"), index=True)
    day: Mapped[date] = mapped_column(Date)
    event_count: Mapped[int] = mapped_column(Integer, default=0)
    bytes_total: Mapped[int | None] = mapped_column(Integer, nullable=True)


class Recommendation(Base):
    __tablename__ = "recommendations"
    __table_args__ = (UniqueConstraint("run_id", "rule_id", name="uq_rec_run_rule"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"), index=True)
    category: Mapped[str] = mapped_column(String(16), index=True)  # KEEP|REVIEW|DISABLE|DELETE
    risk_level: Mapped[str] = mapped_column(String(16), default="Medium", index=True)
    confidence: Mapped[str] = mapped_column(String(16), default="Low")
    engine_version: Mapped[str] = mapped_column(String(24), default="1.0.0")
    triggers_json: Mapped[str] = mapped_column(Text, default="[]")
    evidence_json: Mapped[str] = mapped_column(Text, default="{}")
    missing_json: Mapped[str] = mapped_column(Text, default="[]")
    approval_status: Mapped[str] = mapped_column(String(64), default="none")
    reason: Mapped[str] = mapped_column(Text, default="")
    next_action: Mapped[str] = mapped_column(Text, default="")
    business_impact: Mapped[str] = mapped_column(Text, default="")
    technical_impact: Mapped[str] = mapped_column(Text, default="")
    ai_json: Mapped[str] = mapped_column(Text, default="{}")
    ai_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    ai_validated: Mapped[bool] = mapped_column(Boolean, default=False)
    ai_model: Mapped[str] = mapped_column(String(128), default="")
    analyzed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    owner: Mapped[str] = mapped_column(String(255), default="")
    change_status: Mapped[str] = mapped_column(String(64), default="")
    change_request: Mapped[str] = mapped_column(String(64), default="")
    change_task: Mapped[str] = mapped_column(String(64), default="")
    expiry_status: Mapped[str] = mapped_column(String(24), default="unknown")


class Approval(Base):
    __tablename__ = "approvals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(48))  # business_confirmation | disable_approval | delete_approval | obsolescence_confirmation
    approved_by: Mapped[str] = mapped_column(String(255), default="")
    approved_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    note: Mapped[str] = mapped_column(Text, default="")
    source: Mapped[str] = mapped_column(String(48), default="manual")


class DisableEvidence(Base):
    """Records that a rule was actually disabled and monitored (never performed by this platform)."""

    __tablename__ = "disable_evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"), index=True)
    disabled_at: Mapped[datetime] = mapped_column(DateTime)
    monitored_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    change_reference: Mapped[str] = mapped_column(String(64), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    source: Mapped[str] = mapped_column(String(48), default="manual")


class Comparison(Base):
    __tablename__ = "comparisons"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    base_run_id: Mapped[int] = mapped_column(ForeignKey("runs.id"))
    current_run_id: Mapped[int] = mapped_column(ForeignKey("runs.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    summary_json: Mapped[str] = mapped_column(Text, default="{}")
    details_json: Mapped[str] = mapped_column(Text, default="[]")


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(64), default="system")
    action: Mapped[str] = mapped_column(String(96))
    entity: Mapped[str] = mapped_column(String(48), default="")
    entity_id: Mapped[str] = mapped_column(String(64), default="")
    details_json: Mapped[str] = mapped_column(Text, default="{}")


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    kind: Mapped[str] = mapped_column(String(48))
    status: Mapped[str] = mapped_column(String(24), default="queued")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[str] = mapped_column(Text, default="")
    run_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    result_json: Mapped[str] = mapped_column(Text, default="{}")


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(48))  # full|keep|review|disable|delete|missing_info|no_change|zero_traffic|executive
    fmt: Mapped[str] = mapped_column(String(8))  # xlsx|pdf
    path: Mapped[str] = mapped_column(String(1024))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
