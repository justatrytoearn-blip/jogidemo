"""Rule inventory, detail, traffic windows, change history, approvals and review modes."""
from __future__ import annotations

import json
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import exists, func, or_, select
from sqlalchemy.orm import Session

from backend.api.deps import audit, current_user
from backend.config import Settings, load_policy
from backend.database.db import get_db
from backend.database.models import (
    Approval,
    ChangeRecord,
    DisableEvidence,
    Recommendation,
    Rule,
    RuleChangeLink,
    Run,
    TrafficMetric,
    Upload,
)
from backend.jobs import runner
from backend.recommendation_engine.policy import Policy
from backend.reports.ad_hoc import build_filtered_excel
from backend.schemas import ApprovalRequest, DisableEvidenceRequest, RuleFilter
from backend.services import ai_jobs
from backend.services.analysis import reevaluate_rule

router = APIRouter(prefix="/api", tags=["rules"])

SORT_COLUMNS = {
    "rule_number": Rule.rule_number,
    "rule_name": Rule.rule_name,
    "security_section": Rule.security_section,
    "action": Rule.action,
    "hit_count": Rule.hit_count,
    "last_hit": Rule.last_hit,
    "first_hit": Rule.first_hit,
    "category": Recommendation.category,
    "risk_level": Recommendation.risk_level,
    "event_count": TrafficMetric.event_count,
    "avg_per_day": TrafficMetric.avg_per_day,
    "days_since_last_hit": TrafficMetric.days_since_last_hit,
    "owner": Recommendation.owner,
    "confidence": Recommendation.confidence,
}


def _traffic_window(policy: Policy) -> int:
    return int(policy.recent_traffic_lookback_days)


def apply_filters(q, f: RuleFilter, policy: Policy):
    if f.q:
        like = f"%{f.q.strip()}%"
        q = q.filter(
            or_(
                Rule.rule_name.ilike(like),
                Rule.rule_number.ilike(like),
                Rule.rule_uid.ilike(like),
                Rule.source.ilike(like),
                Rule.destination.ilike(like),
                Rule.comments.ilike(like),
                Rule.service.ilike(like),
            )
        )
    for field, column in (
        ("rule_name", Rule.rule_name),
        ("rule_number", Rule.rule_number),
        ("rule_uid", Rule.rule_uid),
        ("source", Rule.source),
        ("destination", Rule.destination),
        ("service", Rule.service),
        ("security_section", Rule.security_section),
    ):
        value = getattr(f, field)
        if value:
            q = q.filter(column.ilike(f"%{value.strip()}%"))
    if f.action:
        q = q.filter(func.lower(Rule.action) == f.action.strip().lower())
    if f.recommendation:
        q = q.filter(Recommendation.category == f.recommendation.upper())
    if f.risk:
        q = q.filter(Recommendation.risk_level == f.risk)
    if f.expiry:
        q = q.filter(Recommendation.expiry_status == f.expiry)
    if f.owner:
        if f.owner.lower() == "unknown":
            q = q.filter(or_(Recommendation.owner == "", Recommendation.owner.is_(None)))
        else:
            q = q.filter(Recommendation.owner.ilike(f"%{f.owner}%"))
    if f.change_state:
        q = q.filter(Recommendation.change_status.ilike(f"%{f.change_state}%"))
    if f.change_record == "present":
        q = q.filter(exists().where(RuleChangeLink.rule_id == Rule.id))
    elif f.change_record == "missing":
        q = q.filter(~exists().where(RuleChangeLink.rule_id == Rule.id))
    if f.last_hit_from:
        q = q.filter(Rule.last_hit >= f.last_hit_from)
    if f.last_hit_to:
        q = q.filter(Rule.last_hit <= f.last_hit_to)
    if f.ai_generated:
        q = q.filter(Recommendation.ai_generated == (f.ai_generated == "yes"))
    if f.traffic:
        lookback = _traffic_window(policy)
        mode = f.traffic
        if mode == "active":
            q = q.filter(TrafficMetric.event_count > 0)
        elif mode == "recent":
            q = q.filter(TrafficMetric.days_since_last_hit.isnot(None), TrafficMetric.days_since_last_hit <= lookback)
        elif mode == "stale":
            q = q.filter(TrafficMetric.days_since_last_hit.isnot(None), TrafficMetric.days_since_last_hit > lookback)
        elif mode == "zero":
            q = q.filter(
                TrafficMetric.window_event_count == 0,
                or_(TrafficMetric.matched.is_(True), TrafficMetric.absence_is_evidence.is_(True)),
            )
        elif mode == "unknown":
            q = q.filter(TrafficMetric.matched.is_(False), TrafficMetric.absence_is_evidence.is_(False))
    return q


def _base_query(db: Session):
    return (
        db.query(Rule, Recommendation, TrafficMetric)
        .join(Recommendation, Recommendation.rule_id == Rule.id)
        .outerjoin(TrafficMetric, TrafficMetric.rule_id == Rule.id)
    )


def _row_payload(rule: Rule, rec: Recommendation, metric: TrafficMetric | None, policy: Policy, accepted: bool = False) -> dict:
    evidence = json.loads(rec.evidence_json or "{}")
    return {
        "id": rule.id,
        "run_id": rule.run_id,
        "rule_number": rule.rule_number,
        "rule_name": rule.rule_name,
        "rule_uid": rule.rule_uid,
        "security_section": rule.security_section,
        "source": rule.source,
        "destination": rule.destination,
        "service": rule.service,
        "action": rule.action,
        "hit_count": rule.hit_count,
        "hits_raw": rule.hits_raw,
        "first_hit": rule.first_hit.isoformat() if rule.first_hit else None,
        "last_hit": rule.last_hit.isoformat() if rule.last_hit else None,
        "log_event_count": metric.event_count if metric else 0,
        "window_event_count": metric.window_event_count if metric else 0,
        "avg_per_day": metric.avg_per_day if metric else 0.0,
        "avg_per_week": metric.avg_per_week if metric else 0.0,
        "avg_per_month": metric.avg_per_month if metric else 0.0,
        "days_since_last_hit": metric.days_since_last_hit if metric else None,
        "last_seen": metric.last_seen.isoformat() if metric and metric.last_seen else None,
        "traffic_state": (
            "no_evidence"
            if not metric or (not metric.matched and not metric.absence_is_evidence)
            else "recent"
            if metric.days_since_last_hit is not None and metric.days_since_last_hit <= policy.recent_traffic_lookback_days
            else "zero"
            if metric.window_event_count == 0
            else "stale"
        ),
        "logs_supplied": bool(metric.logs_supplied) if metric else False,
        "absence_is_evidence": bool(metric.absence_is_evidence) if metric else False,
        "match_method": metric.match_method if metric else "none",
        "match_confidence": metric.match_confidence if metric else 0,
        "change_request": rec.change_request,
        "change_task": rec.change_task,
        "change_status": rec.change_status,
        "owner": rec.owner,
        "expiry_status": rec.expiry_status,
        "recommendation": rec.category,
        "risk_level": rec.risk_level,
        "confidence": rec.confidence,
        "approval_status": rec.approval_status,
        "accepted": accepted,
        "eligible_for": "DISABLE" if rec.approval_status == "pending_business_confirmation" else ("DELETE" if rec.approval_status == "pending_delete_approval" else ""),
        "ai_generated": rec.ai_generated,
        "reason_preview": rec.reason[:220],
        "missing_count": len(evidence.get("missing") or json.loads(rec.missing_json or "[]")),
    }


@router.get("/rules")
def list_rules(
    run_id: int | None = None,
    page: int = 1,
    page_size: int = 50,
    sort_by: str = "rule_number",
    sort_dir: str = "asc",
    db: Session = Depends(get_db),
    user: dict = Depends(current_user),
    f: RuleFilter = Depends(),
):
    policy = Policy.from_dict(load_policy())
    run_id = run_id or f.run_id
    if not run_id:
        latest = db.execute(select(Run.id).where(Run.status == "completed").order_by(Run.created_at.desc())).scalars().first()
        run_id = latest
    if not run_id:
        return {"items": [], "total": 0, "page": 1, "page_size": page_size, "pages": 0, "run_id": None}
    f.run_id = run_id
    q = _base_query(db).filter(Rule.run_id == run_id)
    q = apply_filters(q, f, policy)
    total = q.count()
    column = SORT_COLUMNS.get(sort_by, Rule.rule_number)
    ordering = column.desc() if sort_dir.lower() == "desc" else column.asc()
    if sort_by in {"hit_count", "event_count", "avg_per_day", "days_since_last_hit", "last_hit", "first_hit"}:
        ordering = column.desc().nulls_last() if sort_dir.lower() == "desc" else column.asc().nulls_last()
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    rows = q.order_by(ordering, Rule.id.asc()).offset((page - 1) * page_size).limit(page_size).all()
    accepted_ids = set(
        db.execute(
            select(Approval.rule_id).where(
                Approval.rule_id.in_([rule.id for rule, _r, _m in rows]),
                Approval.kind == "review_accepted",
            )
        ).scalars()
    ) if rows else set()
    return {
        "run_id": run_id,
        "items": [_row_payload(rule, rec, metric, policy, rule.id in accepted_ids) for rule, rec, metric in rows],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": (total + page_size - 1) // page_size if page_size else 0,
    }


def _filtered_rows(db: Session, f: RuleFilter, policy: Policy):
    if not f.run_id:
        raise HTTPException(400, "run_id is required for filtered operations")
    q = _base_query(db).filter(Rule.run_id == f.run_id)
    q = apply_filters(q, f, policy)
    return q.order_by(Rule.security_section, Rule.rule_number).all()


@router.post("/rules/export")
def export_rules(
    payload: dict,
    db: Session = Depends(get_db),
    user: dict = Depends(current_user),
):
    policy = Policy.from_dict(load_policy())
    rule_ids = payload.get("rule_ids") or []
    filters = RuleFilter(**(payload.get("filters") or {}))
    if rule_ids:
        rows = (
            _base_query(db)
            .filter(Rule.id.in_(rule_ids))
            .order_by(Rule.security_section, Rule.rule_number)
            .all()
        )
    else:
        rows = _filtered_rows(db, filters, policy)
    records = [_row_payload(rule, rec, metric, policy) for rule, rec, metric in rows]
    stream = build_filtered_excel(records, {"run_id": filters.run_id, "generated_at": datetime.utcnow().isoformat()})
    name = f"firewall_rules_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    audit(db, user["username"], "rules.exported", "run", str(filters.run_id or ""), {"rows": len(records)})
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


def _rule_or_404(db: Session, rule_id: int) -> Rule:
    rule = db.get(Rule, rule_id)
    if not rule:
        raise HTTPException(404, "Rule not found")
    return rule


@router.get("/rules/{rule_id}")
def rule_detail(rule_id: int, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    rule = _rule_or_404(db, rule_id)
    rec = db.execute(select(Recommendation).where(Recommendation.rule_id == rule_id)).scalars().first()
    metric = db.execute(select(TrafficMetric).where(TrafficMetric.rule_id == rule_id)).scalars().first()
    if not rec:
        raise HTTPException(404, "No recommendation stored for this rule")
    policy = Policy.from_dict(load_policy())
    run = db.get(Run, rule.run_id)
    upload = db.get(Upload, run.rules_upload_id) if run and run.rules_upload_id else None
    links = db.execute(
        select(RuleChangeLink, ChangeRecord)
        .join(ChangeRecord, ChangeRecord.id == RuleChangeLink.change_record_id)
        .where(RuleChangeLink.rule_id == rule_id)
        .order_by(ChangeRecord.planned_end_date.desc())
    ).all()
    changes = [
        {
            "ctask_number": cr.ctask_number,
            "chg_number": cr.chg_number,
            "state": cr.state,
            "assigned_to": cr.assigned_to,
            "short_description": cr.short_description,
            "planned_end_date": cr.planned_end_date.isoformat() if cr.planned_end_date else None,
            "rule_uid": cr.rule_uid,
            "rule_number": cr.rule_number,
            "rule_name": cr.rule_name,
            "source_kind": cr.source_kind,
            "match_method": link.match_method,
            "match_confidence": link.confidence,
            "match_evidence": link.evidence,
            "source_file": cr.source_file,
            "source_sheet": cr.source_sheet,
            "source_row": cr.source_row,
        }
        for link, cr in links
    ]
    approvals = db.execute(select(Approval).where(Approval.rule_id == rule_id)).scalars().all()
    evidence = db.execute(select(DisableEvidence).where(DisableEvidence.rule_id == rule_id)).scalars().all()
    return {
        "rule": {
            "id": rule.id,
            "run_id": rule.run_id,
            "rule_number": rule.rule_number,
            "rule_name": rule.rule_name,
            "rule_uid": rule.rule_uid,
            "security_section": rule.security_section,
            "device": rule.device,
            "source": rule.source,
            "destination": rule.destination,
            "service": rule.service,
            "action": rule.action,
            "install_on": rule.install_on,
            "comments": rule.comments,
            "vpn": rule.vpn,
            "track": rule.track,
            "hit_count": rule.hit_count,
            "hits_raw": rule.hits_raw,
            "first_hit": rule.first_hit.isoformat() if rule.first_hit else None,
            "last_hit": rule.last_hit.isoformat() if rule.last_hit else None,
            "expiry_date": rule.expiry_date.isoformat() if rule.expiry_date else None,
            "owner_hint": rule.owner_hint,
            "source_file": rule.source_file,
            "source_sheet": rule.source_sheet,
            "source_row": rule.source_row,
            "raw": json.loads(rule.raw_json or "{}"),
        },
        "traffic": _metric_payload(metric),
        "changes": changes,
        "change_summary": {
            "count": len(changes),
            "documented": any(c["state"] and c["short_description"] for c in changes),
            "multiple": len(changes) > 1,
            "conflicting": len({c["assigned_to"] for c in changes if c["assigned_to"]}) > 1
            or len({c["state"] for c in changes if c["state"]}) > 1,
            "owners": sorted({c["assigned_to"] for c in changes if c["assigned_to"]}),
        },
        "recommendation": _rec_payload(rec),
        "accepted": any(a.kind == "review_accepted" for a in approvals),
        "approvals": [
            {"kind": a.kind, "approved_by": a.approved_by, "approved_at": a.approved_at.isoformat(), "note": a.note, "source": a.source}
            for a in approvals
        ],
        "disable_evidence": [
            {
                "disabled_at": e.disabled_at.isoformat(),
                "monitored_until": e.monitored_until.isoformat() if e.monitored_until else None,
                "change_reference": e.change_reference,
                "note": e.note,
            }
            for e in evidence
        ],
        "traceability": {
            "run_label": run.label if run else "",
            "run_created_at": run.created_at.isoformat() if run else "",
            "upload_filename": upload.original_filename if upload else "",
            "source_file": rule.source_file,
            "source_sheet": rule.source_sheet,
            "source_row": rule.source_row,
            "is_synthetic": run.is_synthetic if run else False,
        },
        "policy": policy.to_dict(),
    }


def _metric_payload(metric: TrafficMetric | None) -> dict:
    if not metric:
        return {"matched": False, "notes": "No traffic metrics stored"}
    return {
        "matched": metric.matched,
        "logs_supplied": metric.logs_supplied,
        "absence_is_evidence": metric.absence_is_evidence,
        "match_method": metric.match_method,
        "match_confidence": metric.match_confidence,
        "event_count": metric.event_count,
        "window_event_count": metric.window_event_count,
        "first_seen": metric.first_seen.isoformat() if metric.first_seen else None,
        "last_seen": metric.last_seen.isoformat() if metric.last_seen else None,
        "days_since_last_hit": metric.days_since_last_hit,
        "observation_days": metric.observation_days,
        "log_coverage_days": metric.log_coverage_days,
        "active_days": metric.active_days,
        "avg_per_day": metric.avg_per_day,
        "avg_per_week": metric.avg_per_week,
        "avg_per_month": metric.avg_per_month,
        "avg_per_hour": metric.avg_per_hour,
        "distinct_sources": metric.distinct_sources,
        "distinct_destinations": metric.distinct_destinations,
        "bytes_total": metric.bytes_total,
        "packets_total": metric.packets_total,
        "protocols": json.loads(metric.protocols_json or "[]"),
        "top_sources": json.loads(metric.top_sources_json or "[]"),
        "top_destinations": json.loads(metric.top_destinations_json or "[]"),
        "daily": json.loads(metric.daily_json or "[]"),
        "hourly": json.loads(metric.hourly_json or "[]"),
        "trend": metric.trend,
        "notes": metric.notes,
    }


def _rec_payload(rec: Recommendation) -> dict:
    return {
        "category": rec.category,
        "risk_level": rec.risk_level,
        "confidence": rec.confidence,
        "triggers": json.loads(rec.triggers_json or "[]"),
        "evidence": json.loads(rec.evidence_json or "{}"),
        "missing": json.loads(rec.missing_json or "[]"),
        "approval_status": rec.approval_status,
        "reason": rec.reason,
        "next_action": rec.next_action,
        "business_impact": rec.business_impact,
        "technical_impact": rec.technical_impact,
        "ai": json.loads(rec.ai_json or "{}"),
        "ai_generated": rec.ai_generated,
        "ai_validated": rec.ai_validated,
        "ai_model": rec.ai_model,
        "analyzed_at": rec.analyzed_at.isoformat(),
        "engine_version": rec.engine_version,
        "owner": rec.owner,
        "change_status": rec.change_status,
        "expiry_status": rec.expiry_status,
    }


@router.get("/rules/{rule_id}/traffic")
def rule_traffic_window(
    rule_id: int,
    days: int = 90,
    start: str | None = None,
    end: str | None = None,
    db: Session = Depends(get_db),
    user: dict = Depends(current_user),
):
    metric = db.execute(select(TrafficMetric).where(TrafficMetric.rule_id == rule_id)).scalars().first()
    if not metric:
        raise HTTPException(404, "No traffic metrics for this rule")
    daily = json.loads(metric.daily_json or "[]")
    series = []
    for item in daily:
        try:
            day = datetime.fromisoformat(item["date"]).date()
        except (KeyError, ValueError):
            continue
        series.append((day, int(item.get("count", 0))))
    if end:
        end_date = datetime.fromisoformat(end).date()
    else:
        end_date = series[-1][0] if series else datetime.utcnow().date()
    if start:
        start_date = datetime.fromisoformat(start).date()
    else:
        start_date = end_date - timedelta(days=max(1, days) - 1)
    if start_date > end_date:
        raise HTTPException(400, "start must be before end")
    window = [(d, c) for d, c in series if start_date <= d <= end_date]
    span = (end_date - start_date).days + 1
    total = sum(c for _, c in window)
    active_days = sum(1 for _, c in window if c > 0)
    return {
        "rule_id": rule_id,
        "matched": metric.matched,
        "absence_is_evidence": metric.absence_is_evidence,
        "notes": metric.notes,
        "start": start_date.isoformat(),
        "end": end_date.isoformat(),
        "days": span,
        "total_events": total,
        "active_days": active_days,
        "inactive_days": max(0, span - active_days),
        "avg_per_day": round(total / span, 4) if span else 0,
        "avg_per_week": round(total / span * 7, 4) if span else 0,
        "avg_per_month": round(total / span * 30.44, 4) if span else 0,
        "avg_per_hour": round(total / span / 24, 6) if span else 0,
        "first_seen": window[0][0].isoformat() if window else None,
        "last_seen": window[-1][0].isoformat() if window else None,
        "series": [{"date": d.isoformat(), "count": c} for d, c in window],
        "hourly": json.loads(metric.hourly_json or "[]"),
        "protocols": json.loads(metric.protocols_json or "[]"),
        "top_sources": json.loads(metric.top_sources_json or "[]"),
        "top_destinations": json.loads(metric.top_destinations_json or "[]"),
        "match_method": metric.match_method,
        "match_confidence": metric.match_confidence,
        "log_coverage_days": metric.log_coverage_days,
    }


@router.post("/rules/{rule_id}/ai")
def rule_ai(rule_id: int, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    _rule_or_404(db, rule_id)
    try:
        narrative = ai_jobs.generate_single(rule_id)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    audit(db, user["username"], "ai.narration_generated", "rule", str(rule_id), {"generated": narrative.get("generated")})
    return narrative


@router.post("/rules/{rule_id}/approvals")
def add_approval(rule_id: int, payload: ApprovalRequest, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    rule = _rule_or_404(db, rule_id)
    allowed = {"business_confirmation", "disable_approval", "delete_approval", "obsolescence_confirmation", "review_accepted"}
    if payload.kind not in allowed:
        raise HTTPException(400, f"kind must be one of {sorted(allowed)}")
    db.add(
        Approval(
            run_id=rule.run_id,
            rule_id=rule.id,
            kind=payload.kind,
            approved_by=payload.approved_by or user["username"],
            note=payload.note,
            source="manual",
        )
    )
    db.commit()
    rec = reevaluate_rule(db, rule_id)
    audit(
        db,
        user["username"],
        "approval.recorded",
        "rule",
        str(rule_id),
        {"kind": payload.kind, "approved_by": payload.approved_by, "new_category": rec.category},
    )
    return {"ok": True, "recommendation": _rec_payload(rec)}


@router.post("/rules/{rule_id}/accept")
def accept_review(rule_id: int, payload: dict | None = None, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    """Record that a reviewer accepted the stored recommendation for this rule.

    Acceptance is evidence of review only: it never changes the category. Policy
    categories change only through the approval/evidence rules in the engine.
    """
    rule = _rule_or_404(db, rule_id)
    payload = payload or {}
    existing = db.execute(
        select(Approval).where(Approval.rule_id == rule_id, Approval.kind == "review_accepted")
    ).scalars().first()
    if not existing:
        db.add(
            Approval(
                run_id=rule.run_id,
                rule_id=rule.id,
                kind="review_accepted",
                approved_by=str(payload.get("approved_by") or user["username"]),
                note=str(payload.get("note") or "Recommendation accepted during review"),
                source="review",
            )
        )
        db.commit()
    rec = db.execute(select(Recommendation).where(Recommendation.rule_id == rule_id)).scalars().first()
    audit(
        db,
        user["username"],
        "review.accepted",
        "rule",
        str(rule_id),
        {"category": rec.category if rec else "", "approved_by": payload.get("approved_by") or user["username"]},
    )
    return {"ok": True, "accepted": True, "recommendation": _rec_payload(rec) if rec else None}


@router.delete("/rules/{rule_id}/approvals/{kind}")
def remove_approval(rule_id: int, kind: str, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    rule = _rule_or_404(db, rule_id)
    approval = db.execute(select(Approval).where(Approval.rule_id == rule_id, Approval.kind == kind)).scalars().first()
    if not approval:
        raise HTTPException(404, "Approval not found")
    db.delete(approval)
    db.commit()
    rec = reevaluate_rule(db, rule_id)
    audit(db, user["username"], "approval.removed", "rule", str(rule_id), {"kind": kind})
    return {"ok": True, "recommendation": _rec_payload(rec)}


@router.post("/rules/{rule_id}/disable-evidence")
def add_disable_evidence(rule_id: int, payload: DisableEvidenceRequest, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    rule = _rule_or_404(db, rule_id)
    try:
        disabled_at = datetime.fromisoformat(payload.disabled_at)
        monitored_until = datetime.fromisoformat(payload.monitored_until) if payload.monitored_until else None
    except ValueError as exc:
        raise HTTPException(400, "Dates must be ISO-8601") from exc
    db.add(
        DisableEvidence(
            run_id=rule.run_id,
            rule_id=rule.id,
            disabled_at=disabled_at,
            monitored_until=monitored_until,
            change_reference=payload.change_reference,
            note=payload.note,
            source="manual",
        )
    )
    db.commit()
    rec = reevaluate_rule(db, rule_id)
    audit(db, user["username"], "disable_evidence.recorded", "rule", str(rule_id), payload.model_dump())
    return {"ok": True, "recommendation": _rec_payload(rec)}


@router.post("/review")
def review_rules(payload: dict, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    """Review selected rules or every rule matching the active filters."""
    policy = Policy.from_dict(load_policy())
    rule_ids = payload.get("rule_ids") or []
    filters_payload = payload.get("filters")
    if not rule_ids and filters_payload:
        f = RuleFilter(**filters_payload)
        rule_ids = [rule.id for rule, _rec, _m in _filtered_rows(db, f, policy)]
    if not rule_ids:
        raise HTTPException(400, "Select rules or provide filters for a filtered review")
    results = []
    for rule_id in rule_ids[:5000]:
        rec = reevaluate_rule(db, rule_id, policy)
        results.append({"rule_id": rule_id, "category": rec.category, "risk_level": rec.risk_level})
    job_id = None
    if payload.get("generate_ai"):
        job_id = runner.submit(
            "ai",
            ai_jobs.generate_for_run(
                db.get(Rule, rule_ids[0]).run_id, rule_ids=rule_ids[: int(payload.get("ai_limit", 200))]
            ),
        )
    audit(db, user["username"], "review.executed", "rules", "", {"count": len(results), "ai_job": job_id})
    counts: dict[str, int] = {}
    for r in results:
        counts[r["category"]] = counts.get(r["category"], 0) + 1
    return {"reviewed": len(results), "counts": counts, "ai_job_id": job_id, "items": results[:500]}


@router.get("/review-modes")
def review_modes(run_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    policy = Policy.from_dict(load_policy())
    run_id = run_id or db.execute(select(Run.id).where(Run.status == "completed").order_by(Run.created_at.desc())).scalars().first()
    if not run_id:
        return {"run_id": None, "total": 0}
    total = db.query(Rule).filter(Rule.run_id == run_id).count()
    return {
        "run_id": run_id,
        "total": total,
        "modes": [
            {"key": "complete", "label": "Complete review", "description": "Review every rule in the uploaded inventory.", "rule_count": total},
            {"key": "filtered", "label": "Filtered review", "description": "Review only rules matching the active filters.", "rule_count": None},
            {"key": "selected", "label": "Selected review", "description": "Review the rules ticked in the table.", "rule_count": None},
        ],
        "policy": policy.to_dict(),
    }
