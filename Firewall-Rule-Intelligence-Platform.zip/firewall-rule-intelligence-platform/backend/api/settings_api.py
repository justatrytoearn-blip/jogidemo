"""Policy configuration, local AI settings and system information."""
from __future__ import annotations

import json
import os
import platform
import shutil
import time
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.ai import ollama_client
from backend.api.deps import audit, current_user, require_admin
from backend.config import (
    DB_DIR,
    PROJECT_ROOT,
    Settings,
    UPLOAD_DIR,
    REPORT_DIR,
    api_key,
    effective_ai_config,
    load_policy,
    load_settings_overrides,
    save_settings,
)
from backend.database.db import get_db
from backend.database.models import AuditLog, Recommendation, Rule, Run
from backend.recommendation_engine.policy import Policy

router = APIRouter(prefix="/api/settings", tags=["settings"])


@router.get("/policy")
def get_policy(user: dict = Depends(current_user)):
    policy = Policy.from_dict(load_policy())
    return {"policy": policy.to_dict(), "fields": policy.describe()}


@router.put("/policy")
def update_policy(payload: dict, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    incoming = payload.get("policy") or {}
    policy = Policy.from_dict({**load_policy(), **incoming})
    overrides = load_settings_overrides()
    overrides["policy"] = policy.to_dict()
    save_settings(overrides)
    audit(db, admin["username"], "policy.updated", "settings", "", policy.to_dict())
    return {"policy": policy.to_dict(), "fields": policy.describe()}


@router.get("/ai")
def get_ai(user: dict = Depends(current_user)):
    cfg = effective_ai_config()
    status = ollama_client.status(cfg["url"], cfg["model"])
    return {
        "config": cfg,
        "status": {
            "available": status.available,
            "url": status.url,
            "model": status.model,
            "models": status.models,
            "message": status.message,
        },
    }


@router.put("/ai")
def update_ai(payload: dict, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    overrides = load_settings_overrides()
    for key in ("ollama_url", "ollama_model", "ai_enabled", "ai_timeout", "ai_max_rules"):
        if key in payload and payload[key] is not None:
            overrides[key] = payload[key]
    save_settings(overrides)
    audit(db, admin["username"], "ai.settings_updated", "settings", "", {k: overrides.get(k) for k in ("ollama_url", "ollama_model", "ai_enabled")})
    return get_ai(admin)


@router.get("/ai/models")
def list_models():
    cfg = effective_ai_config()
    status = ollama_client.status(cfg["url"], cfg["model"])
    return {"models": status.models, "configured": cfg["model"], "available": status.available, "message": status.message}


@router.post("/ai/test")
def test_ai(payload: dict | None = None, admin: dict = Depends(require_admin)):
    cfg = effective_ai_config()
    payload = payload or {}
    prompt = payload.get("prompt") or "Reply with the single word OK."
    # Testing an unsaved model/URL lets an administrator check a model before committing it.
    model = payload.get("model") or cfg["model"]
    url = payload.get("ollama_url") or cfg["url"]
    started = time.time()
    try:
        text = ollama_client.chat_text(
            "You are a connectivity test. Reply briefly and do not add caveats.", prompt, model=model
        )
    except ollama_client.OllamaUnavailable as exc:
        raise HTTPException(503, str(exc)) from exc
    return {
        "model": model,
        "ollama_url": url,
        "seconds": round(time.time() - started, 2),
        "response": text[:500],
    }


@router.get("/system")
def system_info(db: Session = Depends(get_db), user: dict = Depends(current_user)):
    cfg = effective_ai_config()
    status = ollama_client.status(cfg["url"], cfg["model"])
    uploads = db.query(Rule).count()
    runs = db.query(Run).count()
    recs = db.query(Recommendation).count()
    try:
        usage = shutil.disk_usage(str(PROJECT_ROOT))
        disk = {"total_gb": round(usage.total / 1e9, 1), "free_gb": round(usage.free / 1e9, 1)}
    except OSError:
        disk = {}
    return {
        "app": Settings.to_dict(),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "cpu_count": os.cpu_count(),
        "database": {
            "url": Settings.__dict__.get("DATABASE_URL") or f"sqlite:///{DB_DIR / 'fip.db'}",
            "rules": uploads,
            "runs": runs,
            "recommendations": recs,
        },
        "paths": {
            "project": str(PROJECT_ROOT),
            "uploads": str(UPLOAD_DIR),
            "reports": str(REPORT_DIR),
        },
        "disk": disk,
        "ai": {
            "enabled": cfg["enabled"],
            "url": cfg["url"],
            "model": cfg["model"],
            "available": status.available,
            "models": status.models,
            "message": status.message,
        },
        "n8n_api_key_configured": bool(api_key()),
        "auth_enabled": Settings.AUTH_ENABLED,
        "engine_version": Settings.ENGINE_VERSION,
    }


@router.get("/audit")
def audit_trail(limit: int = 200, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    entries = db.execute(select(AuditLog).order_by(AuditLog.ts.desc()).limit(min(limit, 1000))).scalars().all()
    return {
        "items": [
            {
                "id": e.id,
                "ts": e.ts.isoformat(),
                "actor": e.actor,
                "action": e.action,
                "entity": e.entity,
                "entity_id": e.entity_id,
                "details": json.loads(e.details_json or "{}"),
            }
            for e in entries
        ]
    }


@router.get("/n8n-key")
def n8n_key(admin: dict = Depends(require_admin)):
    """Reveal the n8n API key to an administrator so the workflows can be configured."""
    return {"api_key": api_key(), "header": "X-API-Key"}
