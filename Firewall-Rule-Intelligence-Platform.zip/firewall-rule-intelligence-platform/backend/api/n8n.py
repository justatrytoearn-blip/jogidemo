"""Secure endpoints consumed by the n8n orchestration workflows."""
from __future__ import annotations

import json
import os
import re
from datetime import datetime

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.api.deps import audit, require_api_key
from backend.ai import ollama_client
from backend.config import (
    PROJECT_ROOT,
    UPLOAD_DIR,
    effective_ai_config,
    load_settings_overrides,
    save_settings,
)
from backend.database.db import get_db, session_scope
from backend.database.models import Approval, Job, Recommendation, Rule, Run
from backend.jobs import runner
from backend.reports.excel_export import build_excel
from backend.reports.pdf_export import build_pdf
from backend.services import ai_jobs, demo_data, import_service
from backend.services.analysis import create_run
from backend.services.comparison import compare_runs, comparison_payload
from backend.database.models import Report
from pathlib import Path

router = APIRouter(prefix="/api/n8n", tags=["n8n"], dependencies=[Depends(require_api_key)])


def _run_summary(run: Run) -> dict:
    return {
        "run_id": run.id,
        "label": run.label,
        "status": run.status,
        "stage": run.stage,
        "progress": run.progress,
        "message": run.message,
        "stats": json.loads(run.stats_json or "{}"),
        "error": run.error,
    }


@router.get("/health")
def n8n_health():
    with session_scope() as db:
        runs = db.query(Run).count()
    return {"status": "ok", "runs": runs}


@router.post("/ingest")
async def n8n_ingest(
    file: UploadFile = File(...),
    dataset_type: str = Form(...),
    is_synthetic: bool = Form(False),
    db: Session = Depends(get_db),
):
    """Workflow 1: receive a file, identify it, validate it, map it and store metadata."""
    if dataset_type not in ("rules", "changes", "logs"):
        raise HTTPException(400, "dataset_type must be rules, changes or logs")
    try:
        upload = import_service.create_upload(db, dataset_type, file.filename or "upload", file.file, actor="n8n", is_synthetic=is_synthetic)
        stored = json.loads(upload.mapping_json or "{}")
        mapping = {k: v for k, v in stored.get("mapping", {}).items() if v}
        upload = import_service.confirm_mapping(
            db, upload.id, mapping, upload.sheet_name, actor="n8n"
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    audit(db, "n8n", "n8n.ingest", "upload", str(upload.id), {"dataset_type": dataset_type, "file": upload.original_filename})
    return {"upload": import_service.upload_summary(upload)}


@router.post("/ingest-path")
def n8n_ingest_path(payload: dict, db: Session = Depends(get_db)):
    """Workflow 1 variant for files dropped into the uploads folder by an external system.

    Only paths inside the platform uploads directory are accepted (no traversal).
    """
    from backend.config import UPLOAD_DIR

    dataset_type = str(payload.get("dataset_type") or "")
    raw_path = str(payload.get("file_path") or "")
    if dataset_type not in ("rules", "changes", "logs"):
        raise HTTPException(400, "dataset_type must be rules, changes or logs")
    if not raw_path:
        raise HTTPException(400, "file_path is required")
    candidate = (UPLOAD_DIR / raw_path.lstrip("/\\")).resolve()
    if not str(candidate).startswith(str(UPLOAD_DIR.resolve())) or not candidate.is_file():
        raise HTTPException(400, "file_path must reference an existing file inside uploads/")
    try:
        with candidate.open("rb") as fh:
            upload = import_service.create_upload(db, dataset_type, candidate.name, fh, actor="n8n", is_synthetic=bool(payload.get("is_synthetic")))
        stored = json.loads(upload.mapping_json or "{}")
        mapping = {k: v for k, v in stored.get("mapping", {}).items() if v}
        upload = import_service.confirm_mapping(db, upload.id, mapping, upload.sheet_name, actor="n8n")
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    audit(db, "n8n", "n8n.ingest_path", "upload", str(upload.id), {"dataset_type": dataset_type, "file": candidate.name})
    return {"upload": import_service.upload_summary(upload)}


@router.post("/analyze")
def n8n_analyze(payload: dict, db: Session = Depends(get_db)):
    """Workflows 2/3/4 entry point: run correlation, traffic analysis and recommendations."""
    try:
        run = create_run(
            db,
            int(payload["rules_upload_id"]),
            payload.get("changes_upload_id"),
            payload.get("logs_upload_id"),
            payload.get("label", "n8n analysis"),
            bool(payload.get("ai_explanations", True)),
            payload.get("parent_run_id"),
            actor="n8n",
        )
    except KeyError as exc:
        raise HTTPException(400, f"Missing field {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc

    def job(progress):
        from backend.services.analysis import execute_run

        progress(2, "n8n triggered analysis")
        stats = execute_run(run.id)
        if run.ai_enabled:
            runner.submit("ai", ai_jobs.generate_for_run(run.id), run_id=run.id)
        return {"message": "Analysis completed", "run_id": run.id, "stats": stats}

    job_id = runner.submit("analysis", job, run_id=run.id)
    return {"run_id": run.id, "job_id": job_id, "status": "queued"}


@router.get("/runs/{run_id}")
def n8n_run(run_id: int, db: Session = Depends(get_db)):
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    jobs = db.execute(select(Job).where(Job.run_id == run_id).order_by(Job.created_at.desc()).limit(5)).scalars().all()
    return {
        **_run_summary(run),
        "jobs": [runner.job_payload(j) for j in jobs],
        "counts": {
            "rules": db.query(Rule).filter(Rule.run_id == run_id).count(),
            "recommendations": db.query(Recommendation).filter(Recommendation.run_id == run_id).count(),
        },
    }


@router.post("/ai/{run_id}")
def n8n_ai(run_id: int, payload: dict | None = None):
    payload = payload or {}
    job_id = runner.submit("ai", ai_jobs.generate_for_run(run_id, limit=payload.get("limit")), run_id=run_id)
    return {"job_id": job_id, "status": "queued"}


@router.post("/report/{run_id}")
def n8n_report(run_id: int, payload: dict | None = None, db: Session = Depends(get_db)):
    payload = payload or {}
    kinds = payload.get("kinds") or ["full", "keep", "review", "disable", "delete", "missing_info", "no_change", "zero_traffic", "executive"]
    formats = payload.get("formats") or ["xlsx", "pdf"]
    created = []
    for kind in kinds:
        for fmt in formats:
            path, rows = build_excel(db, run_id, kind) if fmt == "xlsx" else build_pdf(db, run_id, kind)
            report = Report(run_id=run_id, kind=kind, fmt=fmt, path=path, size_bytes=Path(path).stat().st_size)
            db.add(report)
            db.commit()
            db.refresh(report)
            created.append({"id": report.id, "kind": kind, "fmt": fmt, "path": path, "rows": rows})
    return {"reports": created, "count": len(created)}


def _execute_full_review(
    run_id: int,
    *,
    demo: bool,
    generate_ai: bool,
    generate_reports: bool,
    model: str,
    ai_limit: int,
    progress=None,
) -> dict:
    """Shared by the background full-review job and the synchronous chat endpoint."""
    from backend.services.analysis import execute_run

    progress = progress or (lambda _p, _m: None)
    progress(2, "Running deterministic analysis")
    stats = execute_run(run_id)
    fixture = None
    if demo:
        with session_scope() as sdb:
            fixture = demo_data.apply_demo_fixtures(sdb, run_id)
    if generate_ai:
        try:
            ai_jobs.generate_for_run(run_id, limit=ai_limit, model=model)(
                lambda p, m: progress(80 + int(p * 0.16), m)
            )
        except Exception:  # noqa: BLE001
            progress(96, "AI narration unavailable; deterministic text retained")
    report_count = 0
    if generate_reports:
        progress(97, "Generating Excel and PDF reports")
        with session_scope() as rdb:
            for kind in ("full", "keep", "review", "disable", "delete", "missing_info", "no_change", "zero_traffic", "executive"):
                for fmt in ("xlsx", "pdf"):
                    path, rows = build_excel(rdb, run_id, kind) if fmt == "xlsx" else build_pdf(rdb, run_id, kind)
                    rdb.add(Report(run_id=run_id, kind=kind, fmt=fmt, path=path, size_bytes=Path(path).stat().st_size))
                    rdb.commit()
                    report_count += 1
    with session_scope() as sdb:
        run_row = sdb.get(Run, run_id)
        run_stats = json.loads(run_row.stats_json or "{}")
        run_stats["full_review"] = {
            "model": model,
            "demo": demo,
            "reports": report_count,
            "ai_limit": ai_limit if generate_ai else 0,
            "completed_at": datetime.utcnow().isoformat(),
        }
        run_row.stats_json = json.dumps(run_stats, default=str)
        sdb.commit()
    progress(100, "Full review complete")
    return {"stats": stats, "demo": fixture, "reports": report_count}


def _parse_prompt(prompt: str) -> dict:
    """Read ``key: value`` lines from a human prompt (or an embedded JSON object)."""
    result: dict = {}
    text = (prompt or "").strip()
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                result.update(parsed)
        except json.JSONDecodeError:
            pass
    aliases = {
        "rule": "rules_path", "rules": "rules_path", "inventory": "rules_path",
        "change": "changes_path", "changes": "changes_path",
        "log": "logs_path", "logs": "logs_path",
        "name": "label", "title": "label", "label": "label",
        "model": "model", "llm": "model",
        "ai_limit": "ai_limit", "limit": "ai_limit",
    }
    keys = "|".join(sorted(aliases, key=len, reverse=True))
    pattern = re.compile(
        rf"\b({keys})\s*[:=]\s*([^\n;]+?)(?=\s+\w+\s*[:=]|\n|;|$)",
        re.I,
    )
    for match in pattern.finditer(text):
        key = aliases.get(match.group(1).strip().lower().replace(" ", "_"))
        if not key:
            continue
        value = match.group(2).strip().strip('"').strip("'")
        if value:
            result[key] = value
    if re.search(r"\bdemo\b", text, re.I):
        result.setdefault("demo", True)
    if re.search(r"\bno\s+ai\b", text, re.I):
        result.setdefault("ai", False)
    return result


def _resolve_data_path(raw: str, dataset: str) -> Path:
    """Only files inside uploads/ or samples/demo/ may be referenced by a prompt."""
    cleaned = str(raw or "").strip().replace("\\", "/")
    if not cleaned:
        raise HTTPException(400, f"No {dataset} file was provided")
    demo_dir = (PROJECT_ROOT / "samples" / "demo").resolve()
    candidates = [
        Path(cleaned),
        UPLOAD_DIR / cleaned,
        UPLOAD_DIR / dataset / cleaned,
        PROJECT_ROOT / cleaned,
        demo_dir / cleaned,
    ]
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        if not resolved.is_file():
            continue
        if str(resolved).startswith(str(UPLOAD_DIR.resolve())) or str(resolved).startswith(str(demo_dir)):
            return resolved
    raise HTTPException(400, f"{dataset} file must exist inside uploads/ or samples/demo/: {cleaned}")


def _ingest_file(db: Session, dataset: str, path: Path, synthetic: bool):
    with path.open("rb") as fh:
        upload = import_service.create_upload(
            db, dataset, path.name, fh, actor="n8n", is_synthetic=synthetic
        )
    stored = json.loads(upload.mapping_json or "{}")
    mapping = {k: v for k, v in stored.get("mapping", {}).items() if v}
    return import_service.confirm_mapping(db, upload.id, mapping, upload.sheet_name, actor="n8n")


@router.post("/full-review")
def n8n_full_review(payload: dict | None = None, db: Session = Depends(get_db)):
    """One call that runs the entire review from a prompt or structured fields.

    Accepted fields: ``prompt`` (free text with ``rules:``, ``changes:``, ``logs:``,
    ``model:``, ``label:``, ``demo``), or the same values as JSON. Files must live in
    ``uploads/`` or ``samples/demo/``. Returns immediately with a run id; poll
    ``/api/n8n/full-review/{run_id}`` for progress, counts and portal links.
    """
    payload = payload or {}
    parsed = _parse_prompt(str(payload.get("prompt") or ""))
    data = {**parsed, **{k: v for k, v in payload.items() if k != "prompt" and v not in (None, "")}}
    prompt_text = str(payload.get("prompt") or "")
    demo = bool(data.get("demo")) or str(data.get("demo", "")).lower() in {"1", "true", "yes"}
    generate_ai = bool(data.get("ai", True))
    generate_reports = bool(data.get("reports", True))
    model = str(data.get("model") or "").strip() or effective_ai_config()["model"]
    label = str(data.get("label") or ("DEMO full review" if demo else "n8n full review"))
    try:
        ai_limit = int(data.get("ai_limit") or 20)
    except (TypeError, ValueError):
        ai_limit = 20

    if demo:
        files = demo_data.ensure_demo_files()
        rules_path = Path(files["rules"])
        changes_path = Path(files["changes"])
        logs_path = Path(files["logs"])
        synthetic = True
    else:
        rules_path = _resolve_data_path(str(data.get("rules_path") or ""), "firewall_rules")
        changes_path = _resolve_data_path(str(data["changes_path"]), "change_records") if data.get("changes_path") else None
        logs_path = _resolve_data_path(str(data["logs_path"]), "firewall_logs") if data.get("logs_path") else None
        synthetic = bool(data.get("is_synthetic"))

    try:
        rules_upload = _ingest_file(db, "rules", rules_path, synthetic)
        changes_upload = _ingest_file(db, "changes", changes_path, synthetic) if changes_path else None
        logs_upload = _ingest_file(db, "logs", logs_path, synthetic) if logs_path else None
        run = create_run(
            db,
            rules_upload.id,
            changes_upload.id if changes_upload else None,
            logs_upload.id if logs_upload else None,
            label,
            ai_enabled=generate_ai,
            actor="n8n",
        )
        run.ai_model = model
        db.commit()
        run_id = run.id
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc

    audit(
        db,
        "n8n",
        "n8n.full_review_started",
        "run",
        str(run_id),
        {"demo": demo, "model": model, "label": label, "files": [p.name for p in (rules_path, changes_path, logs_path) if p]},
    )

    def job(progress):
        result = _execute_full_review(
            run_id, demo=demo, generate_ai=generate_ai, generate_reports=generate_reports,
            model=model, ai_limit=ai_limit, progress=progress,
        )
        return {"message": "Full review complete", "run_id": run_id, **result}

    job_id = runner.submit("full_review", job, run_id=run_id)
    return {
        "run_id": run_id,
        "job_id": job_id,
        "status": "queued",
        "label": label,
        "model": model,
        "demo": demo,
        "files": {
            "rules": rules_path.name,
            "changes": changes_path.name if changes_path else None,
            "logs": logs_path.name if logs_path else None,
        },
        "portal": {
            "dashboard": f"/#/dashboard?run={run_id}",
            "rules": f"/#/rules?run={run_id}",
            "run": f"/#/runs?run={run_id}",
        },
    }


@router.get("/full-review/{run_id}")
def n8n_full_review_status(run_id: int, db: Session = Depends(get_db)):
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    job = db.execute(
        select(Job).where(Job.run_id == run_id, Job.kind == "full_review").order_by(Job.id.desc())
    ).scalars().first()
    counts = {c: 0 for c in ("KEEP", "REVIEW", "DISABLE", "DELETE")}
    for (category,) in db.execute(select(Recommendation.category).where(Recommendation.run_id == run_id)).all():
        counts[category] = counts.get(category, 0) + 1
    reports = db.query(Report).filter(Report.run_id == run_id).count()
    accepted = db.query(Approval).filter(Approval.run_id == run_id, Approval.kind == "review_accepted").count()
    job_status = job.status if job else run.status
    return {
        "run_id": run_id,
        "label": run.label,
        "status": job_status,
        "job_id": job.id if job else None,
        "job_progress": job.progress if job else run.progress,
        "message": (job.message if job else run.message),
        "error": (job.message if job and job.status == "failed" else run.error),
        "run_status": run.status,
        "stage": run.stage,
        "progress": run.progress,
        "counts": counts,
        "rules": sum(counts.values()),
        "reports": reports,
        "accepted": accepted,
        "stats": json.loads(run.stats_json or "{}"),
        "portal": {
            "dashboard": f"/#/dashboard?run={run_id}",
            "rules": f"/#/rules?run={run_id}",
            "run": f"/#/runs?run={run_id}",
            "reports": f"/#/reports?run={run_id}",
        },
    }


def _portal_url() -> str:
    return os.getenv("FIP_PORTAL_URL", "http://127.0.0.1:8080").rstrip("/")


def _ai_status() -> dict:
    cfg = effective_ai_config()
    status = ollama_client.status(cfg["url"], cfg["model"])
    return {
        "default_model": cfg["model"],
        "enabled": cfg["enabled"],
        "ollama_url": cfg["url"],
        "models": status.models,
        "available": status.available,
        "message": status.message,
    }


def _chat_review(message: str, db: Session) -> dict:
    """Run a review synchronously for the chat UI and return a chat-shaped answer."""
    parsed = _parse_prompt(message)
    demo = bool(parsed.get("demo")) or bool(re.search(r"\bdemo\b", message, re.I))
    has_paths = any(parsed.get(k) for k in ("rules_path", "changes_path", "logs_path"))
    if not demo and not has_paths:
        return {
            "output": (
                "I can run the full review from here.\n\n"
                "Try: **demo**\n\n"
                "Or provide files: `label: Weekly review  rules: uploads/firewall_rules/x.xlsx  "
                "changes: uploads/change_records/y.csv  logs: uploads/firewall_logs/z.csv`\n\n"
                "Commands: `help`, `models`, `connection`, `set model <name>`, `test model <name>`, `status <run_id>`."
            ),
            "kind": "help",
        }
    model = str(parsed.get("model") or "").strip() or effective_ai_config()["model"]
    try:
        ai_limit = max(1, min(50, int(parsed.get("ai_limit") or 4)))
    except (TypeError, ValueError):
        ai_limit = 4
    generate_ai = not bool(re.search(r"\bno\s+ai\b", message, re.I)) and parsed.get("ai") is not False
    generate_reports = not bool(re.search(r"\bno\s+reports?\b", message, re.I)) and parsed.get("reports") is not False
    label = str(parsed.get("label") or ("Chat demo" if demo else "Chat review"))

    if demo:
        files = demo_data.ensure_demo_files()
        rules_path = Path(files["rules"])
        changes_path = Path(files["changes"])
        logs_path = Path(files["logs"])
        synthetic = True
    else:
        rules_path = _resolve_data_path(str(parsed.get("rules_path") or ""), "firewall_rules")
        changes_path = _resolve_data_path(str(parsed["changes_path"]), "change_records") if parsed.get("changes_path") else None
        logs_path = _resolve_data_path(str(parsed["logs_path"]), "firewall_logs") if parsed.get("logs_path") else None
        synthetic = bool(parsed.get("is_synthetic"))

    rules_upload = _ingest_file(db, "rules", rules_path, synthetic)
    changes_upload = _ingest_file(db, "changes", changes_path, synthetic) if changes_path else None
    logs_upload = _ingest_file(db, "logs", logs_path, synthetic) if logs_path else None
    run = create_run(
        db,
        rules_upload.id,
        changes_upload.id if changes_upload else None,
        logs_upload.id if logs_upload else None,
        label,
        ai_enabled=generate_ai,
        actor="n8n-chat",
    )
    run.ai_model = model
    db.commit()
    run_id = run.id
    audit(db, "n8n-chat", "n8n.chat_review_started", "run", str(run_id), {"demo": demo, "model": model})

    result = _execute_full_review(
        run_id, demo=demo, generate_ai=generate_ai, generate_reports=generate_reports,
        model=model, ai_limit=ai_limit,
    )
    db.expire_all()
    fresh = db.get(Run, run_id)
    stats = json.loads(fresh.stats_json or "{}")
    counts = {k: stats.get(k.lower(), 0) for k in ("KEEP", "REVIEW", "DISABLE", "DELETE")}
    ai_count = stats.get("ai_generated_rules", 0)
    ai_total = stats.get("ai_reviewed_rules", 0)
    output = (
        f"**Review completed** — run #{run_id} ({label})\n\n"
        f"KEEP **{counts['KEEP']}** · REVIEW **{counts['REVIEW']}** · "
        f"DISABLE **{counts['DISABLE']}** · DELETE **{counts['DELETE']}**\n"
        f"Rules: {stats.get('total_rules', 0)} · matched log events: {stats.get('traffic', {}).get('rows_matched', 0)} · "
        f"AI: {ai_count}/{ai_total} ({model}) · reports: {result.get('reports', 0)}\n\n"
        f"Dashboard: {_portal_url()}/#/dashboard?run={run_id}\n"
        f"Rules: {_portal_url()}/#/rules?run={run_id}\n"
        f"Reports: {_portal_url()}/#/reports?run={run_id}\n\n"
        "_Every DISABLE/DELETE still needs human approval; the platform never changes a firewall._"
    )
    return {
        "output": output,
        "kind": "review",
        "run_id": run_id,
        "counts": counts,
        "reports": result.get("reports", 0),
        "model": model,
    }


@router.get("/connection")
def n8n_connection(db: Session = Depends(get_db)):
    """Connection and capability status for the n8n chat and console."""
    ai = _ai_status()
    return {
        "backend": "reachable",
        "api_base": os.getenv("FIP_BASE_URL", "http://host.docker.internal:8080"),
        "portal_url": _portal_url(),
        "runs": db.query(Run).count(),
        "ai": ai,
    }


@router.get("/models")
def n8n_models():
    return _ai_status()


@router.put("/model")
def n8n_set_model(payload: dict, db: Session = Depends(get_db)):
    model = str((payload or {}).get("model") or "").strip()
    if not model:
        raise HTTPException(400, "model is required")
    overrides = load_settings_overrides()
    overrides["ollama_model"] = model
    save_settings(overrides)
    audit(db, "n8n", "ai.model_changed", "settings", "", {"model": model})
    state = _ai_status()
    return {"ok": True, "default_model": model, **state}


@router.post("/chat")
def n8n_chat(payload: dict | None = None, db: Session = Depends(get_db)):
    """Chat entry point used by the n8n hosted chat workflow.

    Supports natural demo/review prompts plus operational commands so the model and
    connection can be checked or changed from the chat without opening the editor.
    """
    payload = payload or {}
    message = str(payload.get("message") or payload.get("chatInput") or payload.get("prompt") or "").strip()
    low = message.lower()

    if not message or low in {"help", "?", "commands"}:
        return {
            "output": (
                "**Firewall Rule Intelligence — n8n chat**\n\n"
                "Run the demo: `demo` or `demo label: Customer demo model: qwen2.5:1.5b ai_limit: 4`\n"
                "Real files: `label: Weekly review  rules: uploads/firewall_rules/x.xlsx  changes: uploads/change_records/y.csv  logs: uploads/firewall_logs/z.csv`\n\n"
                "**Commands**\n"
                "- `models` — list installed local models\n"
                "- `connection` — backend + Ollama health\n"
                "- `set model <name>` — change the default model\n"
                "- `test model <name>` — live test without changing the default\n"
                "- `status <run_id>` — progress and category counts\n"
                "- `no ai` / `no reports` — faster demo"
            ),
            "kind": "help",
        }

    if re.match(r"^(models?|model\s+list)$", low):
        ai = _ai_status()
        installed = "\n".join(f"- {m}" for m in ai["models"]) or "- none installed"
        return {
            "output": f"**Installed models**\n{installed}\n\nDefault: `{ai['default_model']}`\nOllama: {ai['message']}",
            "kind": "models",
            **ai,
        }

    if low in {"connection", "connect", "health", "status"}:
        ai = _ai_status()
        return {
            "output": (
                "**Connection status**\n"
                f"Backend: reachable · runs: {db.query(Run).count()}\n"
                f"Portal: {_portal_url()}\n"
                f"Ollama: {'available' if ai['available'] else 'unavailable'} at {ai['ollama_url']}\n"
                f"Default model: `{ai['default_model']}`\n"
                f"Installed: {', '.join(ai['models']) or 'none'}"
            ),
            "kind": "connection",
            **ai,
        }

    match = re.match(r"^(?:set|use)\s+model\s+(.+)$", message, re.I)
    if match:
        model = match.group(1).strip().strip('`')
        overrides = load_settings_overrides()
        overrides["ollama_model"] = model
        save_settings(overrides)
        audit(db, "n8n-chat", "ai.model_changed", "settings", "", {"model": model})
        ai = _ai_status()
        installed = model in ai["models"] or any(m.split(":")[0] == model.split(":")[0] for m in ai["models"])
        return {
            "output": (
                f"Default model changed to `{model}`.\n"
                f"{'Installed and ready.' if installed else 'Not installed yet — run: ollama pull ' + model}\n"
                "Use `test model <name>` to check it, or `demo` to run a review."
            ),
            "kind": "model_changed",
            "model": model,
            "installed": installed,
        }

    match = re.match(r"^test\s+model\s+(.+)$", message, re.I)
    if match:
        model = match.group(1).strip().strip('`')
        cfg = effective_ai_config()
        started = datetime.utcnow()
        try:
            text = ollama_client.chat_text(
                "You are a connectivity test. Reply briefly and do not add caveats.",
                "Reply with the single word OK.", model=model,
            )
        except ollama_client.OllamaUnavailable as exc:
            return {"output": f"Model `{model}` failed: {exc}", "kind": "model_test", "ok": False}
        seconds = round((datetime.utcnow() - started).total_seconds(), 2)
        return {
            "output": f"Model `{model}` replied in **{seconds}s**: “{text[:300]}”\nOllama: {cfg['url']}",
            "kind": "model_test", "ok": True, "model": model, "seconds": seconds,
        }

    match = re.match(r"^status\s*(?:run\s*)?#?(\d+)$", message, re.I)
    if match:
        run_id = int(match.group(1))
        run = db.get(Run, run_id)
        if not run:
            return {"output": f"Run #{run_id} was not found.", "kind": "status"}
        counts = {c: 0 for c in ("KEEP", "REVIEW", "DISABLE", "DELETE")}
        for (category,) in db.execute(select(Recommendation.category).where(Recommendation.run_id == run_id)).all():
            counts[category] = counts.get(category, 0) + 1
        return {
            "output": (
                f"**Run #{run_id}** — {run.label}\n"
                f"Status: {run.status} · stage: {run.stage} · {run.progress}%\n"
                f"KEEP {counts['KEEP']} · REVIEW {counts['REVIEW']} · DISABLE {counts['DISABLE']} · DELETE {counts['DELETE']}\n"
                f"Rules: {_portal_url()}/#/rules?run={run_id}"
            ),
            "kind": "status", "run_id": run_id, "counts": counts, "status": run.status,
        }

    try:
        return _chat_review(message, db)
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        return {"output": f"The review could not start: {exc}", "kind": "error"}


@router.post("/compare")
def n8n_compare(payload: dict, db: Session = Depends(get_db)):
    try:
        comparison = compare_runs(db, int(payload["base_run_id"]), int(payload["current_run_id"]))
    except KeyError as exc:
        raise HTTPException(400, f"Missing field {exc}") from exc
    return comparison_payload(comparison)
