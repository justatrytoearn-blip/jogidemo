"""Shared API dependencies: authentication, RBAC and audit helpers."""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from datetime import datetime, timedelta

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.config import CONFIG_DIR, Settings, api_key
from backend.database.db import get_db
from backend.database.models import AuditLog, SessionToken, User

CREDENTIALS_FILE = CONFIG_DIR / "admin_credentials.txt"


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 240_000)
    return f"pbkdf2_sha256${salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _algo, salt, digest = stored.split("$", 2)
    except ValueError:
        return False
    candidate = hash_password(password, salt).split("$", 2)[2]
    return hmac.compare_digest(candidate, digest)


def ensure_admin_user(db: Session) -> None:
    """Create the bootstrap admin with a generated password (never hardcoded)."""
    existing = db.execute(select(User).where(User.role == "admin")).scalars().first()
    if existing:
        return
    password = secrets.token_urlsafe(12)
    db.add(User(username="admin", password_hash=hash_password(password), role="admin"))
    db.add(User(username="reviewer", password_hash=hash_password(secrets.token_urlsafe(12)), role="reviewer"))
    db.commit()
    CREDENTIALS_FILE.write_text(
        "Firewall Rule Intelligence Platform - bootstrap credentials\n"
        "Change these after first login (auth is only active when FIP_AUTH_ENABLED=true).\n\n"
        f"username: admin\npassword: {password}\nrole: admin\n",
        encoding="utf-8",
    )


def current_user(request: Request, db: Session = Depends(get_db)) -> dict:
    if not Settings.AUTH_ENABLED:
        return {"username": "local", "role": "admin", "auth": "disabled"}
    token = request.cookies.get(Settings.SESSION_COOKIE)
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    session = db.execute(select(SessionToken).where(SessionToken.token == token)).scalars().first()
    if not session or session.expires_at < datetime.utcnow():
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired")
    return {"username": session.username, "role": session.role, "auth": "session"}


def require_admin(user: dict = Depends(current_user)) -> dict:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Administrator role required")
    return user


def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
    expected = api_key()
    if not expected:
        raise HTTPException(status_code=503, detail="n8n API key is not configured")
    if not x_api_key or not hmac.compare_digest(x_api_key, expected):
        raise HTTPException(status_code=401, detail="Invalid API key")


def audit(db: Session, actor: str, action: str, entity: str = "", entity_id: str = "", details: dict | None = None) -> None:
    db.add(
        AuditLog(
            actor=actor,
            action=action,
            entity=entity,
            entity_id=str(entity_id),
            details_json=json.dumps(details or {}, default=str),
        )
    )
    db.commit()
