"""Analysis run endpoints and background job status."""
from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.api.deps import audit, current_user
from backend.database.db import get_db, session_scope
from backend.database.models import Comparison, Job, Recommendation, Rule, Run, TrafficMetric
from backend.jobs import runner
from backend.schemas import AnalysisRequest
from backend.services import ai_jobs
from backend.services.analysis import create_run, execute_run
from backend.services.comparison import comparison_payload, compare_runs

router = APIRouter(prefix="/api", tags=["runs"])


def run_payload(run: Run) -> dict:
    return {
        "id": run.id,
        "label": run.label,
        "status": run.status,
        "stage": run.stage,
        "progress": run.progress,
        "message": run.message,
        "created_at": run.created_at.isoformat(),
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "is_synthetic": run.is_synthetic,
        "ai_enabled": run.ai_enabled,
        "stats": json.loads(run.stats_json or "{}"),
        "policy": json.loads(run.policy_json or "{}"),
        "error": run.error,
        "parent_run_id": run.parent_run_id,
        "uploads": {
            "rules": run.rules_upload_id,
            "changes": run.changes_upload_id,
            "logs": run.logs_upload_id,
        },
    }


@router.post("/runs")
def start_analysis(payload: AnalysisRequest, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    try:
        run = create_run(
            db,
            payload.rules_upload_id,
            payload.changes_upload_id,
            payload.logs_upload_id,
            payload.label,
            payload.ai_explanations,
            payload.parent_run_id,
            actor=user["username"],
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    audit(db, user["username"], "analysis.started", "run", run.id, {"label": run.label})
    job_id = runner.submit(
        "analysis",
        lambda progress: _analysis_job(run.id, progress),
        run_id=run.id,
    )
    return {"run": run_payload(run), "job_id": job_id}


def _analysis_job(run_id: int, progress):
    def cb(percent, message):
        progress(percent, message)

    cb(1, "Starting analysis")
    stats = execute_run(run_id)
    # Chain AI narration as its own job so the dashboard is usable immediately.
    with session_scope() as db:
        run = db.get(Run, run_id)
        ai_enabled = bool(run and run.ai_enabled)
    if ai_enabled:
        runner.submit("ai", ai_jobs.generate_for_run(run_id), run_id=run_id)
    return {
        "message": "Analysis completed",
        "run_id": run_id,
        "total_rules": stats.get("total_rules", 0),
        "keep": stats.get("keep", 0),
        "review": stats.get("review", 0),
        "disable": stats.get("disable", 0),
        "delete": stats.get("delete", 0),
        "processing_seconds": stats.get("processing_seconds"),
    }


@router.get("/runs")
def list_runs(limit: int = 50, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    runs = db.execute(select(Run).order_by(Run.created_at.desc()).limit(min(limit, 200))).scalars().all()
    return {"items": [run_payload(r) for r in runs]}


@router.get("/runs/{run_id}")
def get_run(run_id: int, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    return run_payload(run)


@router.get("/runs/{run_id}/status")
def run_status(run_id: int, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    jobs = db.execute(select(Job).where(Job.run_id == run_id).order_by(Job.created_at.desc()).limit(5)).scalars().all()
    return {
        "run": run_payload(run),
        "jobs": [runner.job_payload(j) for j in jobs],
        "counts": {
            "rules": db.query(Rule).filter(Rule.run_id == run_id).count(),
            "recommendations": db.query(Recommendation).filter(Recommendation.run_id == run_id).count(),
            "metrics": db.query(TrafficMetric).filter(TrafficMetric.run_id == run_id).count(),
        },
    }


@router.post("/runs/{run_id}/ai")
def generate_ai(run_id: int, limit: int = 200, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status != "completed":
        raise HTTPException(400, "Analysis must complete before AI narration")
    job_id = runner.submit("ai", ai_jobs.generate_for_run(run_id, limit=limit), run_id=run_id)
    audit(db, user["username"], "ai.generation_requested", "run", run_id, {"limit": limit})
    return {"job_id": job_id}


@router.get("/runs/{run_id}/comparison")
def get_comparison(run_id: int, base_run_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    if base_run_id:
        try:
            comparison = compare_runs(db, base_run_id, run_id)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, str(exc)) from exc
        return comparison_payload(comparison)
    comparison = db.execute(select(Comparison).where(Comparison.current_run_id == run_id).order_by(Comparison.created_at.desc())).scalars().first()
    if not comparison:
        raise HTTPException(404, "No comparison recorded for this run")
    return comparison_payload(comparison)


@router.get("/jobs/{job_id}")
def get_job(job_id: int, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return runner.job_payload(job)


@router.get("/jobs")
def list_jobs(limit: int = 50, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    jobs = db.execute(select(Job).order_by(Job.created_at.desc()).limit(min(limit, 200))).scalars().all()
    return {"items": [runner.job_payload(j) for j in jobs]}
