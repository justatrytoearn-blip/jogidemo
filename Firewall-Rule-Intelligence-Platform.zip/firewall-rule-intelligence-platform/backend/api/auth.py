"""Authentication endpoints and session handling."""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.api.deps import CREDENTIALS_FILE, audit, current_user, verify_password
from backend.config import Settings
from backend.database.db import get_db
from backend.database.models import SessionToken, User
from backend.schemas import LoginRequest

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.get("/status")
def auth_status(user: dict = Depends(current_user)):
    return {
        "auth_enabled": Settings.AUTH_ENABLED,
        "authenticated": True,
        "username": user["username"],
        "role": user["role"],
        "credentials_file_created": CREDENTIALS_FILE.exists(),
    }


@router.post("/login")
def login(payload: LoginRequest, response: Response, db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.username == payload.username)).scalars().first()
    if not user or not user.is_active or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = secrets.token_urlsafe(32)
    db.add(
        SessionToken(
            token=token,
            username=user.username,
            role=user.role,
            expires_at=datetime.utcnow() + timedelta(hours=Settings.SESSION_TTL_HOURS),
        )
    )
    db.commit()
    response.set_cookie(
        Settings.SESSION_COOKIE,
        token,
        httponly=True,
        samesite="lax",
        max_age=Settings.SESSION_TTL_HOURS * 3600,
        path="/",
    )
    audit(db, user.username, "auth.login", "user", user.id)
    return {"username": user.username, "role": user.role, "auth_enabled": Settings.AUTH_ENABLED}


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    token = request.cookies.get(Settings.SESSION_COOKIE)
    if token:
        session = db.execute(select(SessionToken).where(SessionToken.token == token)).scalars().first()
        if session:
            db.delete(session)
            db.commit()
    response.delete_cookie(Settings.SESSION_COOKIE, path="/")
    return {"ok": True}
