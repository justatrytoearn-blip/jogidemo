"""Executive dashboard aggregates - computed from stored analysis results only."""
from __future__ import annotations

import json
from collections import Counter

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from backend.api.deps import current_user
from backend.config import load_policy
from backend.database.db import get_db
from backend.database.models import ChangeRecord, Job, Recommendation, Rule, RuleChangeLink, Run, TrafficMetric
from backend.recommendation_engine.policy import Policy

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


def latest_completed_run(db: Session) -> Run | None:
    return db.execute(select(Run).where(Run.status == "completed").order_by(Run.created_at.desc())).scalars().first()


@router.get("")
def dashboard(run_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    run = db.get(Run, run_id) if run_id else latest_completed_run(db)
    if not run:
        return {"run": None, "empty": True, "message": "No completed analysis run yet. Upload files and start an analysis."}
    policy = Policy.from_dict(json.loads(run.policy_json or "{}"))
    stats = json.loads(run.stats_json or "{}")

    base = (
        db.query(Rule, Recommendation, TrafficMetric)
        .join(Recommendation, Recommendation.rule_id == Rule.id)
        .outerjoin(TrafficMetric, TrafficMetric.rule_id == Rule.id)
        .filter(Rule.run_id == run.id)
    )
    rows = base.all()
    total = len(rows)
    category = Counter()
    risk = Counter()
    accept = drop = 0
    recent = zero_traffic = no_evidence = no_owner = expired = no_change = 0
    lookup = policy.recent_traffic_lookback_days
    histogram = Counter()
    sections: dict[str, dict] = {}
    for rule, rec, metric in rows:
        category[rec.category] += 1
        risk[rec.risk_level] += 1
        action = (rule.action or "").lower()
        if action == "accept":
            accept += 1
        elif action == "drop":
            drop += 1
        if not rec.owner:
            no_owner += 1
        if rec.expiry_status == "expired":
            expired += 1
        if metric and (metric.matched or metric.absence_is_evidence):
            if metric.days_since_last_hit is not None and metric.days_since_last_hit <= lookup:
                recent += 1
            if metric.window_event_count == 0:
                zero_traffic += 1
            count = metric.event_count
            if count == 0:
                histogram["0"] += 1
            elif count <= 10:
                histogram["1-10"] += 1
            elif count <= 100:
                histogram["11-100"] += 1
            elif count <= 1000:
                histogram["101-1,000"] += 1
            else:
                histogram["1,001+"] += 1
        else:
            no_evidence += 1
            histogram["no evidence"] += 1
        section = rule.security_section or "Unassigned section"
        entry = sections.setdefault(section, {"section": section, "rules": 0, "active": 0, "accept": 0, "drop": 0})
        entry["rules"] += 1
        if metric and metric.matched and metric.event_count > 0:
            entry["active"] += 1
        if action == "accept":
            entry["accept"] += 1
        elif action == "drop":
            entry["drop"] += 1

    linked_rule_ids = {
        rid for (rid,) in db.execute(
            select(RuleChangeLink.rule_id).join(Rule, Rule.id == RuleChangeLink.rule_id).where(Rule.run_id == run.id).distinct()
        ).all()
    }
    no_change = total - len(linked_rule_ids)

    top_used = (
        db.query(Rule, TrafficMetric, Recommendation)
        .join(TrafficMetric, TrafficMetric.rule_id == Rule.id)
        .join(Recommendation, Recommendation.rule_id == Rule.id)
        .filter(Rule.run_id == run.id, TrafficMetric.event_count > 0)
        .order_by(TrafficMetric.event_count.desc())
        .limit(10)
        .all()
    )
    no_activity = (
        db.query(Rule, TrafficMetric, Recommendation)
        .join(TrafficMetric, TrafficMetric.rule_id == Rule.id)
        .join(Recommendation, Recommendation.rule_id == Rule.id)
        .filter(Rule.run_id == run.id, TrafficMetric.matched.is_(False) | (TrafficMetric.window_event_count == 0))
        .order_by(Recommendation.risk_level.desc(), Rule.hit_count.desc().nulls_last())
        .limit(10)
        .all()
    )

    jobs = db.execute(select(Job).where(Job.run_id == run.id).order_by(Job.created_at.desc()).limit(4)).scalars().all()

    def rule_brief(rule, metric, rec):
        return {
            "id": rule.id,
            "rule_number": rule.rule_number,
            "rule_name": rule.rule_name,
            "security_section": rule.security_section,
            "action": rule.action,
            "event_count": metric.event_count if metric else 0,
            "days_since_last_hit": metric.days_since_last_hit if metric else None,
            "recommendation": rec.category,
            "risk_level": rec.risk_level,
        }

    return {
        "empty": False,
        "run": {
            "id": run.id,
            "label": run.label,
            "created_at": run.created_at.isoformat(),
            "is_synthetic": run.is_synthetic,
            "ai_enabled": run.ai_enabled,
            "stats": stats,
        },
        "policy": policy.to_dict(),
        "metrics": {
            "total_rules": total,
            "accept_rules": accept,
            "drop_rules": drop,
            "recent_traffic": recent,
            "zero_traffic": zero_traffic,
            "no_log_evidence": no_evidence,
            "without_change_records": no_change,
            "missing_owners": no_owner,
            "expired_rules": expired,
            "requires_review": category.get("REVIEW", 0),
            "keep": category.get("KEEP", 0),
            "review": category.get("REVIEW", 0),
            "disable": category.get("DISABLE", 0),
            "delete": category.get("DELETE", 0),
        },
        "cards": [
            {"key": "total_rules", "label": "Total firewall rules", "value": total, "target": "/rules"},
            {"key": "accept_rules", "label": "Accept rules", "value": accept, "target": "/rules?action=Accept"},
            {"key": "drop_rules", "label": "Drop rules", "value": drop, "target": "/rules?action=Drop"},
            {"key": "recent_traffic", "label": "Rules with recent traffic", "value": recent, "target": "/rules?traffic=recent"},
            {"key": "zero_traffic", "label": "Rules with zero traffic", "value": zero_traffic, "target": "/rules?traffic=zero"},
            {"key": "no_log_evidence", "label": "No matching log evidence", "value": no_evidence, "target": "/rules?traffic=unknown"},
            {"key": "without_change_records", "label": "Rules without change records", "value": no_change, "target": "/rules?change_record=missing"},
            {"key": "missing_owners", "label": "Rules with missing owners", "value": no_owner, "target": "/rules?owner=unknown"},
            {"key": "expired_rules", "label": "Expired rules", "value": expired, "target": "/rules?expiry=expired"},
            {"key": "requires_review", "label": "Rules requiring review", "value": category.get("REVIEW", 0), "target": "/rules?recommendation=REVIEW"},
            {"key": "keep", "label": "Recommended KEEP", "value": category.get("KEEP", 0), "target": "/rules?recommendation=KEEP"},
            {"key": "review", "label": "Recommended REVIEW", "value": category.get("REVIEW", 0), "target": "/rules?recommendation=REVIEW"},
            {"key": "disable", "label": "Recommended DISABLE", "value": category.get("DISABLE", 0), "target": "/rules?recommendation=DISABLE"},
            {"key": "delete", "label": "Recommended DELETE", "value": category.get("DELETE", 0), "target": "/rules?recommendation=DELETE"},
        ],
        "charts": {
            "recommendations": [{"name": k, "value": category.get(k, 0)} for k in ("KEEP", "REVIEW", "DISABLE", "DELETE")],
            "risk": [{"name": k, "value": risk.get(k, 0)} for k in ("Critical", "High", "Medium", "Low")],
            "traffic_histogram": [
                {"name": k, "value": histogram.get(k, 0)}
                for k in ("0", "1-10", "11-100", "101-1,000", "1,001+", "no evidence")
            ],
            "sections": sorted(sections.values(), key=lambda s: -s["rules"]),
            "action_split": [{"name": "Accept", "value": accept}, {"name": "Drop", "value": drop}],
            "change_coverage": [
                {"name": "With change history", "value": len(linked_rule_ids)},
                {"name": "Without change history", "value": no_change},
            ],
            "traffic_over_time": stats.get("traffic_daily", []),
            "top_rules": [
                {"name": (r.rule_number or r.rule_name or "")[:28], "value": int(m.event_count or 0)}
                for r, m, rec in top_used
            ],
        },
        "top_used": [rule_brief(r, m, rec) for r, m, rec in top_used],
        "no_activity": [rule_brief(r, m, rec) for r, m, rec in no_activity],
        "traffic_summary": stats.get("traffic", {}),
        "executive_summary": stats.get("executive_summary", {}),
        "jobs": [
            {"id": j.id, "kind": j.kind, "status": j.status, "progress": j.progress, "message": j.message}
            for j in jobs
        ],
    }


@router.get("/filters")
def filter_options(run_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    run = db.get(Run, run_id) if run_id else latest_completed_run(db)
    if not run:
        return {"sections": [], "actions": [], "owners": [], "change_states": [], "risk_levels": [], "categories": [], "run_id": None}
    sections = [r[0] for r in db.execute(select(Rule.security_section).where(Rule.run_id == run.id).distinct()).all() if r[0]]
    actions = [r[0] for r in db.execute(select(Rule.action).where(Rule.run_id == run.id).distinct()).all() if r[0]]
    owners = [r[0] for r in db.execute(select(Recommendation.owner).where(Recommendation.run_id == run.id).distinct()).all() if r[0]]
    states = [r[0] for r in db.execute(select(Recommendation.change_status).where(Recommendation.run_id == run.id).distinct()).all() if r[0]]
    return {
        "run_id": run.id,
        "sections": sorted(sections),
        "actions": sorted(actions),
        "owners": sorted(owners),
        "change_states": sorted(states),
        "risk_levels": ["Critical", "High", "Medium", "Low"],
        "categories": ["KEEP", "REVIEW", "DISABLE", "DELETE"],
        "traffic_modes": ["recent", "stale", "active", "zero", "unknown"],
        "expiry_modes": ["expired", "not_expired", "unknown"],
    }
