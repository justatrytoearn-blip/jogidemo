"""Report generation and download."""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.api.deps import audit, current_user
from backend.database.db import get_db
from backend.database.models import Report, Run
from backend.reports.dataset import REPORT_TITLES
from backend.reports.excel_export import build_excel
from backend.reports.pdf_export import build_pdf

router = APIRouter(prefix="/api", tags=["reports"])

KINDS = tuple(REPORT_TITLES.keys())
FORMATS = ("xlsx", "pdf")


@router.post("/reports/generate")
def generate_reports(payload: dict, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    run_id = int(payload.get("run_id") or 0)
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status != "completed":
        raise HTTPException(400, "Analysis must complete before reports can be generated")
    kinds = payload.get("kinds") or list(KINDS)
    formats = payload.get("formats") or ["xlsx", "pdf"]
    kinds = [k for k in kinds if k in KINDS]
    formats = [f for f in formats if f in FORMATS]
    if not kinds or not formats:
        raise HTTPException(400, "At least one valid kind and format is required")
    created = []
    for kind in kinds:
        for fmt in formats:
            try:
                path, rows = (build_excel(db, run_id, kind) if fmt == "xlsx" else build_pdf(db, run_id, kind))
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(400, f"Failed to build {kind}.{fmt}: {exc}") from exc
            report = Report(run_id=run_id, kind=kind, fmt=fmt, path=path, size_bytes=Path(path).stat().st_size)
            db.add(report)
            db.commit()
            db.refresh(report)
            created.append({**report_payload(report), "rows": rows})
    audit(db, user["username"], "reports.generated", "run", str(run_id), {"reports": len(created)})
    return {"items": created}


def report_payload(report: Report) -> dict:
    return {
        "id": report.id,
        "run_id": report.run_id,
        "kind": report.kind,
        "title": REPORT_TITLES.get(report.kind, report.kind),
        "fmt": report.fmt,
        "filename": Path(report.path).name,
        "size_bytes": report.size_bytes,
        "created_at": report.created_at.isoformat(),
        "download_url": f"/api/reports/{report.id}/download",
    }


@router.get("/reports")
def list_reports(run_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    stmt = select(Report).order_by(Report.created_at.desc()).limit(200)
    if run_id:
        stmt = stmt.where(Report.run_id == run_id)
    reports = db.execute(stmt).scalars().all()
    return {"items": [report_payload(r) for r in reports], "kinds": [{"key": k, "title": v} for k, v in REPORT_TITLES.items()]}


@router.get("/reports/{report_id}/download")
def download_report(report_id: int, db: Session = Depends(get_db)):
    report = db.get(Report, report_id)
    if not report:
        raise HTTPException(404, "Report not found")
    path = Path(report.path)
    if not path.exists():
        raise HTTPException(404, "Report file is missing from disk")
    media = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if report.fmt == "xlsx"
        else "application/pdf"
    )
    return FileResponse(path, filename=path.name, media_type=media)
