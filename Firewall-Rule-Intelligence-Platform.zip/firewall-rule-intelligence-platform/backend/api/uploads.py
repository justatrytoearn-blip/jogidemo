"""Upload centre endpoints: validation, sheet selection, column mapping, templates."""
from __future__ import annotations

import json

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.api.deps import audit, current_user
from backend.config import Settings
from backend.database.db import get_db
from backend.database.models import Upload
from backend.schemas import MappingRequest
from backend.services import import_service
from backend.services.templates import ensure_templates

router = APIRouter(prefix="/api", tags=["uploads"])


@router.post("/uploads")
async def upload_file(
    file: UploadFile = File(...),
    dataset_type: str = Form(...),
    is_synthetic: bool = Form(False),
    replace_upload_id: int | None = Form(None),
    db: Session = Depends(get_db),
    user: dict = Depends(current_user),
):
    if dataset_type not in ("rules", "changes", "logs"):
        raise HTTPException(400, "dataset_type must be rules, changes or logs")
    if not file.filename:
        raise HTTPException(400, "A filename is required")
    try:
        upload = import_service.create_upload(
            db,
            dataset_type,
            file.filename,
            file.file,
            actor=user["username"],
            is_synthetic=is_synthetic,
            replace_upload_id=replace_upload_id,
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    return import_service.upload_summary(upload)


@router.get("/uploads")
def list_uploads(dataset_type: str | None = None, limit: int = 100, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    stmt = select(Upload).order_by(Upload.uploaded_at.desc()).limit(min(limit, 500))
    if dataset_type:
        stmt = stmt.where(Upload.dataset_type == dataset_type)
    uploads = db.execute(stmt).scalars().all()
    return {"items": [import_service.upload_summary(u) for u in uploads]}


@router.get("/uploads/{upload_id}")
def get_upload(upload_id: int, db: Session = Depends(get_db), user: dict = Depends(current_user)):
    upload = db.get(Upload, upload_id)
    if not upload:
        raise HTTPException(404, "Upload not found")
    return import_service.upload_summary(upload)


@router.get("/uploads/{upload_id}/preview")
def preview_upload(
    upload_id: int,
    sheet_name: str | None = None,
    header_row: int | None = None,
    db: Session = Depends(get_db),
    user: dict = Depends(current_user),
):
    try:
        return import_service.upload_preview(db, upload_id, sheet_name, header_row)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc


@router.post("/uploads/{upload_id}/mapping")
def confirm_mapping(
    upload_id: int,
    payload: MappingRequest,
    db: Session = Depends(get_db),
    user: dict = Depends(current_user),
):
    try:
        upload = import_service.confirm_mapping(db, upload_id, payload.mapping, payload.sheet_name, actor=user["username"])
        if payload.replace_upload_id:
            upload.is_replacement_of = payload.replace_upload_id
            db.commit()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    return import_service.upload_summary(upload)


@router.get("/templates/{dataset_type}")
def download_template(dataset_type: str):
    if dataset_type not in ("rules", "changes", "logs"):
        raise HTTPException(404, "Unknown template")
    templates = ensure_templates()
    path = templates[dataset_type]
    return FileResponse(
        path,
        filename=f"{dataset_type}_template.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@router.get("/uploads/limits")
def upload_limits():
    return {
        "max_upload_mb": Settings.MAX_UPLOAD_MB,
        "max_log_rows": Settings.MAX_LOG_ROWS,
        "chunk_size": Settings.CHUNK_SIZE,
        "accepted_types": ["xlsx", "xls", "csv"],
    }
