"""Small background job runner so uploads/analysis never freeze the portal."""
from __future__ import annotations

import logging
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor
from typing import Callable

from backend.database.db import session_scope
from backend.database.models import Job, utcnow

log = logging.getLogger("fip.jobs")
_executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="fip-job")
_lock = threading.Lock()


def submit(kind: str, func: Callable[[Callable[[int, str], None]], dict], run_id: int | None = None) -> int:
    with session_scope() as db:
        job = Job(kind=kind, status="queued", progress=0, message="Queued", run_id=run_id)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id

    def progress(percent: int, message: str) -> None:
        with _lock, session_scope() as db:
            job = db.get(Job, job_id)
            if job:
                job.progress = max(0, min(100, int(percent)))
                job.message = message[:500]
                if job.status == "queued":
                    job.status = "running"
            db.commit()

    def wrapper() -> None:
        with _lock, session_scope() as db:
            job = db.get(Job, job_id)
            job.status = "running"
            db.commit()
        try:
            result = func(progress) or {}
            with _lock, session_scope() as db:
                job = db.get(Job, job_id)
                job.status = "completed"
                job.progress = 100
                job.message = str(result.get("message", "Completed"))[:500]
                job.result_json = __import__("json").dumps(result, default=str)
                job.finished_at = utcnow()
                db.commit()
        except Exception as exc:  # noqa: BLE001
            log.error("Job %s failed: %s\n%s", job_id, exc, traceback.format_exc())
            with _lock, session_scope() as db:
                job = db.get(Job, job_id)
                if job:
                    job.status = "failed"
                    job.message = f"{type(exc).__name__}: {exc}"[:500]
                    job.finished_at = utcnow()
                db.commit()

    _executor.submit(wrapper)
    return job_id


def run_sync(job_id: int, func: Callable[[Callable[[int, str], None]], dict]) -> dict:
    """Run inline (used by tests and n8n synchronous calls)."""

    def progress(percent: int, message: str) -> None:
        with session_scope() as db:
            job = db.get(Job, job_id)
            if job:
                job.progress = int(percent)
                job.message = message[:500]
                job.status = "running"
            db.commit()

    result = func(progress) or {}
    with session_scope() as db:
        job = db.get(Job, job_id)
        if job:
            job.status = "completed"
            job.progress = 100
            job.message = str(result.get("message", "Completed"))[:500]
            job.result_json = __import__("json").dumps(result, default=str)
            job.finished_at = utcnow()
        db.commit()
    return result


def job_payload(job: Job) -> dict:
    return {
        "id": job.id,
        "kind": job.kind,
        "status": job.status,
        "progress": job.progress,
        "message": job.message,
        "run_id": job.run_id,
        "created_at": job.created_at.isoformat(),
        "finished_at": job.finished_at.isoformat() if job.finished_at else None,
        "result": __import__("json").loads(job.result_json or "{}"),
    }
