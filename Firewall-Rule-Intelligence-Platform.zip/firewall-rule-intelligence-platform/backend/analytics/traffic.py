"""Traffic analytics over firewall log files.

Logs are streamed in chunks and reduced to per-rule aggregates; raw log rows are
never persisted and are never sent to the LLM. Counts come from actual matching
log events - the inventory hit counter is kept separately and never mixed in.
"""
from __future__ import annotations

import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

from backend.services import file_reader
from backend.services.correlation import RuleIndex, RuleRef, norm_device, norm_name, norm_number, norm_uid
from backend.services.normalize import clean_text

MAX_SOURCES_TRACKED = 500
MAX_PROTOCOLS = 25

METHOD_MAP = {
    "uid": ("rule_uid", 1.0),
    "number_device": ("rule_number+device", 0.95),
    "number": ("rule_number", 0.85),
    "name_device": ("rule_name+device", 0.7),
    "name": ("rule_name", 0.6),
}


def empty_metric(note: str = "") -> dict:
    return {
        "matched": False,
        "logs_supplied": False,
        "absence_is_evidence": False,
        "match_method": "none",
        "match_confidence": 0.0,
        "event_count": 0,
        "window_event_count": 0,
        "first_seen": None,
        "last_seen": None,
        "days_since_last_hit": None,
        "observation_days": 0,
        "log_coverage_days": 0,
        "active_days": 0,
        "avg_per_day": 0.0,
        "avg_per_week": 0.0,
        "avg_per_month": 0.0,
        "avg_per_hour": 0.0,
        "distinct_sources": 0,
        "distinct_destinations": 0,
        "bytes_total": None,
        "packets_total": None,
        "protocols": [],
        "top_sources": [],
        "top_destinations": [],
        "daily": [],
        "hourly": [],
        "trend": "unknown",
        "notes": note,
    }


class _Resolvers:
    """Pre-computed O(1) resolvers derived from the rule inventory."""

    def __init__(self, rules: list[RuleRef]):
        self.index = RuleIndex(rules)
        self.by_uid: dict[str, int] = {}
        self.by_number: dict[str, int] = {}
        self.by_name: dict[str, int] = {}
        self.by_number_device: dict[tuple[str, str], int] = {}
        self.by_name_device: dict[tuple[str, str], int] = {}
        self.ambiguous_numbers: set[str] = set()
        self.ambiguous_names: set[str] = set()

        for rule in rules:
            uid = norm_uid(rule.rule_uid)
            if uid and uid not in self.by_uid:
                self.by_uid[uid] = rule.index
            number = norm_number(rule.rule_number)
            if number:
                if number in self.by_number and self.by_number[number] != rule.index:
                    self.ambiguous_numbers.add(number)
                self.by_number.setdefault(number, rule.index)
                dev = norm_device(rule.device)
                if dev:
                    self.by_number_device[(dev, number)] = rule.index
            name = norm_name(rule.rule_name)
            if name:
                if name in self.by_name and self.by_name[name] != rule.index:
                    self.ambiguous_names.add(name)
                self.by_name.setdefault(name, rule.index)
                dev = norm_device(rule.device)
                if dev:
                    self.by_name_device[(dev, name)] = rule.index
        for key in self.ambiguous_numbers:
            self.by_number.pop(key, None)
        for key in self.ambiguous_names:
            self.by_name.pop(key, None)


def _parse_timestamps(series: pd.Series) -> pd.Series:
    """Parse log timestamps without corrupting ISO dates.

    pandas 3 with format='mixed' + dayfirst treats '2026-11-06' as 11 June, so ISO
    strings are parsed strictly first and day-first parsing is only a fallback for
    genuinely ambiguous formats such as 06/11/2026.
    """
    text = series.astype(str)
    parsed = pd.to_datetime(text, errors="coerce", format="ISO8601")
    missing = parsed.isna() & series.notna() & (text.str.strip() != "")
    if missing.any():
        fallback = pd.to_datetime(text[missing], errors="coerce", dayfirst=True)
        parsed = parsed.copy()
        parsed.loc[missing] = fallback
    # Already-datetime columns (XLSX) bypass string parsing above.
    if parsed.isna().all() and series.map(lambda v: hasattr(v, "year")).any():
        parsed = pd.to_datetime(series, errors="coerce")
    return parsed


def analyze_logs(
    rules: list[RuleRef],
    path: str | Path,
    kind: str,
    sheet: str | None,
    header_row: int,
    columns: list[str],
    mapping: dict[str, str],
    policy: dict,
    progress_cb=None,
) -> tuple[dict[int, dict], dict]:
    """Stream the log file, resolve each event to a rule and aggregate metrics."""
    started = time.time()
    resolvers = _Resolvers(rules)
    uid_col = mapping.get("rule_uid")
    num_col = mapping.get("rule_number")
    name_col = mapping.get("rule_name")
    ts_col = mapping.get("timestamp")
    dev_col = mapping.get("device")
    proto_col = mapping.get("protocol")
    src_col = mapping.get("src_ip")
    dst_col = mapping.get("dst_ip")
    bytes_col = mapping.get("bytes")
    pkts_col = mapping.get("packets")
    if not ts_col:
        raise ValueError("Log mapping has no timestamp column; traffic analysis cannot run.")

    daily: dict[int, Counter] = defaultdict(Counter)
    proto_counts: dict[int, Counter] = defaultdict(Counter)
    src_counts: dict[int, Counter] = defaultdict(Counter)
    dst_counts: dict[int, Counter] = defaultdict(Counter)
    hour_counts: dict[int, Counter] = defaultdict(Counter)
    first_seen: dict[int, datetime] = {}
    last_seen: dict[int, datetime] = {}
    totals: Counter = Counter()
    bytes_totals: Counter = Counter()
    packet_totals: Counter = Counter()
    method_counts: dict[int, Counter] = defaultdict(Counter)
    rows_scanned = 0
    rows_matched = 0
    rows_unmatched = 0
    uid_resolved = 0
    weak_resolved = 0
    global_min: datetime | None = None
    global_max: datetime | None = None
    unmatched_identifiers: Counter = Counter()
    unmatched_examples: list[dict] = []
    unmatched_reasons: Counter = Counter()
    bad_timestamp = 0

    for chunk in file_reader.iter_chunks(path, kind, sheet, header_row, columns):
        rows_scanned += len(chunk)
        df = pd.DataFrame(chunk)
        if df.empty:
            continue
        for col in df.columns:
            if col != "__row__":
                df[col] = df[col].map(clean_text)

        ts = _parse_timestamps(df[ts_col])
        bad_timestamp += int(ts.isna().sum())

        uid = df[uid_col].str.lower() if uid_col else pd.Series([""] * len(df), index=df.index)
        number = df[num_col] if num_col else pd.Series([""] * len(df), index=df.index)
        number = number.str.replace(r"\.0$", "", regex=True)
        name = df[name_col].str.lower() if name_col else pd.Series([""] * len(df), index=df.index)
        device = df[dev_col].str.lower().str.replace(r"@.*", "", regex=True) if dev_col else pd.Series([""] * len(df), index=df.index)

        resolved = pd.Series([None] * len(df), index=df.index, dtype=object)
        method = pd.Series([""] * len(df), index=df.index, dtype=object)

        def apply(mask: pd.Series, values: pd.Series, label: str):
            take = mask & resolved.isna() & values.notna()
            if take.any():
                resolved.loc[take] = values.loc[take]
                method.loc[take] = label

        uid_supplied = uid.ne("") if uid_col else pd.Series([False] * len(df), index=df.index)
        if uid_col:
            apply(uid_supplied, uid.map(resolvers.by_uid), "uid")
        # A supplied-but-unknown rule UID is authoritative evidence that this event belongs to a
        # different rule space (for example another firewall). We deliberately do NOT fall back to
        # bare rule numbers or names in that case - that would merge unrelated rules.
        fallback_allowed = ~uid_supplied
        if num_col:
            dev_num = device + "|" + number
            if resolvers.by_number_device:
                dev_map = {f"{d}|{n}": i for (d, n), i in resolvers.by_number_device.items()}
                apply(fallback_allowed & number.ne(""), dev_num.map(dev_map), "number_device")
            apply(fallback_allowed & number.ne(""), number.map(resolvers.by_number), "number")
        if name_col:
            if resolvers.by_name_device:
                dev_name = device + "|" + name
                name_dev_map = {f"{d}|{n}": i for (d, n), i in resolvers.by_name_device.items()}
                apply(fallback_allowed & name.ne(""), dev_name.map(name_dev_map), "name_device")
            apply(fallback_allowed & name.ne(""), name.map(resolvers.by_name), "name")

        matched_mask = resolved.notna()
        unmatched_mask = ~matched_mask
        if unmatched_mask.any():
            rows_unmatched += int(unmatched_mask.sum())
            unknown_uid = unmatched_mask & uid_supplied
            if unknown_uid.any():
                unmatched_reasons["rule_uid_not_in_inventory"] += int(unknown_uid.sum())
            no_identifier = unmatched_mask & ~uid_supplied & (number.ne("") | name.ne(""))
            if no_identifier.any():
                unmatched_reasons["identifier_not_found_or_ambiguous"] += int(no_identifier.sum())
            blank = unmatched_mask & ~uid_supplied & number.eq("") & name.eq("")
            if blank.any():
                unmatched_reasons["no_rule_identifier"] += int(blank.sum())
            sub = df.loc[unmatched_mask]
            for _, row in sub.head(10).iterrows():
                key_parts = []
                if uid_col:
                    key_parts.append(f"uid={row[uid_col]}")
                if num_col:
                    key_parts.append(f"rule={row[num_col]}")
                if name_col:
                    key_parts.append(f"name={row[name_col]}")
                unmatched_identifiers[" ".join(key_parts) or "no rule identifier"] += 1
            if len(unmatched_examples) < 20:
                first = sub.iloc[0]
                unmatched_examples.append(
                    {
                        "row": int(first.get("__row__")) if str(first.get("__row__")).isdigit() else first.get("__row__"),
                        "rule_uid": first.get(uid_col, "") if uid_col else "",
                        "rule_number": first.get(num_col, "") if num_col else "",
                        "rule_name": first.get(name_col, "") if name_col else "",
                    }
                )
        if not matched_mask.any():
            continue

        uid_resolved += int((method == "uid").sum())
        weak_resolved += int(method.isin(["number", "number_device", "name", "name_device"]).sum())
        work = pd.DataFrame(
            {
                "rid": resolved[matched_mask].astype(int),
                "method": method[matched_mask],
                "ts": ts[matched_mask],
            }
        )
        good = work["ts"].notna()
        work = work[good]
        if work.empty:
            continue
        work["day"] = work["ts"].dt.floor("D")
        work["hour"] = work["ts"].dt.hour
        rows_matched += len(work)

        if global_min is None or work["ts"].min().to_pydatetime() < global_min:
            global_min = work["ts"].min().to_pydatetime()
        if global_max is None or work["ts"].max().to_pydatetime() > global_max:
            global_max = work["ts"].max().to_pydatetime()

        for rid, group in work.groupby("rid"):
            rid = int(rid)
            totals[rid] += len(group)
            daily[rid].update(group["day"].value_counts().to_dict())
            hour_counts[rid].update(group["hour"].value_counts().to_dict())
            method_counts[rid].update(group["method"].value_counts().to_dict())
            gmin = group["ts"].min().to_pydatetime()
            gmax = group["ts"].max().to_pydatetime()
            first_seen[rid] = min(first_seen[rid], gmin) if rid in first_seen else gmin
            last_seen[rid] = max(last_seen[rid], gmax) if rid in last_seen else gmax

        if proto_col:
            for (rid, proto), cnt in df.loc[matched_mask, [proto_col]].assign(rid=resolved[matched_mask]).groupby(["rid", proto_col]).size().items():
                proto_counts[int(rid)][clean_text(proto) or "unknown"] += int(cnt)
        if src_col:
            for rid, group in df.loc[matched_mask].assign(rid=resolved[matched_mask]).groupby("rid"):
                counter = src_counts[int(rid)]
                counter.update(group[src_col].dropna().value_counts().head(MAX_SOURCES_TRACKED).to_dict())
                if len(counter) > MAX_SOURCES_TRACKED * 4:
                    src_counts[int(rid)] = Counter(dict(counter.most_common(MAX_SOURCES_TRACKED)))
        if dst_col:
            for rid, group in df.loc[matched_mask].assign(rid=resolved[matched_mask]).groupby("rid"):
                counter = dst_counts[int(rid)]
                counter.update(group[dst_col].dropna().value_counts().head(MAX_SOURCES_TRACKED).to_dict())
                if len(counter) > MAX_SOURCES_TRACKED * 4:
                    dst_counts[int(rid)] = Counter(dict(counter.most_common(MAX_SOURCES_TRACKED)))
        if bytes_col:
            for rid, val in df.loc[matched_mask].assign(rid=resolved[matched_mask]).groupby("rid")[bytes_col].apply(
                lambda s: pd.to_numeric(s, errors="coerce").sum()
            ).items():
                bytes_totals[int(rid)] += int(val) if pd.notna(val) else 0
        if pkts_col:
            for rid, val in df.loc[matched_mask].assign(rid=resolved[matched_mask]).groupby("rid")[pkts_col].apply(
                lambda s: pd.to_numeric(s, errors="coerce").sum()
            ).items():
                packet_totals[int(rid)] += int(val) if pd.notna(val) else 0

        if progress_cb and rows_scanned % 500_000 < len(chunk):
            progress_cb(rows_scanned)

    now = datetime.utcnow()
    observation_days = int(policy.get("observation_days", 90))
    window_end = global_max
    coverage_days = ((global_max - global_min).days + 1) if (global_min and global_max) else 0
    effective_window = min(observation_days, max(coverage_days, 1)) if window_end else observation_days
    window_start = (window_end - timedelta(days=effective_window - 1)) if window_end else None
    prev_window_start = (window_start - timedelta(days=30)) if window_start else None
    recent_30_start = (window_end - timedelta(days=29)) if window_end else None
    prev_30_start = (window_end - timedelta(days=59)) if window_end else None

    # Whether a *zero-event* rule is meaningful evidence depends on the log file sharing the
    # inventory's rule identity space. If no log identifier maps to any rule, the file belongs to
    # a different rule space and absence proves nothing.
    identity_space_ok = uid_resolved > 0 if uid_col else weak_resolved > 0
    absence_is_evidence = bool(identity_space_ok and coverage_days >= int(policy.get("min_log_coverage_days", 30)))

    metrics: dict[int, dict] = {}
    for rule in rules:
        rid = rule.index
        metric = empty_metric()
        metric["logs_supplied"] = True
        metric["absence_is_evidence"] = absence_is_evidence
        metric["observation_days"] = effective_window
        metric["log_coverage_days"] = coverage_days
        if rid not in totals:
            metric["notes"] = (
                "No matching log events in the supplied dataset; the log file shares the inventory rule space, so this supports zero-traffic evidence."
                if absence_is_evidence
                else "No matching log events found, and the log dataset does not share this inventory's rule identity space - absence is not treated as evidence."
            )
            metrics[rid] = metric
            continue
        counts: Counter = daily[rid]
        window_count = sum(v for d, v in counts.items() if window_start and d >= window_start)
        active_days = sum(1 for d in counts if window_start and d >= window_start)
        recent30 = sum(v for d, v in counts.items() if recent_30_start and d >= recent_30_start)
        prev30 = sum(v for d, v in counts.items() if prev_30_start and recent_30_start and prev_30_start <= d < recent_30_start)
        if prev30 == 0 and recent30 == 0:
            trend = "inactive"
        elif prev30 == 0 and recent30 > 0:
            trend = "new_activity"
        elif recent30 > prev30 * 1.2:
            trend = "increasing"
        elif recent30 < prev30 * 0.8:
            trend = "decreasing"
        else:
            trend = "stable"

        dominant = method_counts[rid].most_common(1)[0][0] if method_counts[rid] else "number"
        match_method, match_conf = METHOD_MAP.get(dominant, ("rule_number", 0.85))
        metric.update(
            {
                "matched": True,
                "match_method": match_method,
                "match_confidence": match_conf,
                "event_count": int(totals[rid]),
                "window_event_count": int(window_count),
                "first_seen": first_seen.get(rid),
                "last_seen": last_seen.get(rid),
                "days_since_last_hit": (now.date() - last_seen[rid].date()).days if rid in last_seen else None,
                "active_days": int(active_days),
                "avg_per_day": round(window_count / effective_window, 4) if effective_window else 0.0,
                "avg_per_week": round(window_count / effective_window * 7, 4) if effective_window else 0.0,
                "avg_per_month": round(window_count / effective_window * 30.44, 4) if effective_window else 0.0,
                "avg_per_hour": round(window_count / effective_window / 24, 6) if effective_window else 0.0,
                "distinct_sources": len(src_counts[rid]),
                "distinct_destinations": len(dst_counts[rid]),
                "bytes_total": int(bytes_totals[rid]) if bytes_col and rid in bytes_totals else None,
                "packets_total": int(packet_totals[rid]) if pkts_col and rid in packet_totals else None,
                "protocols": [{"protocol": k, "count": v} for k, v in proto_counts[rid].most_common(MAX_PROTOCOLS)],
                "top_sources": [{"value": k, "count": v} for k, v in src_counts[rid].most_common(10)],
                "top_destinations": [{"value": k, "count": v} for k, v in dst_counts[rid].most_common(10)],
                "daily": [{"date": d.date().isoformat(), "count": int(v)} for d, v in sorted(counts.items())][-366:],
                "hourly": [{"hour": h, "count": int(hour_counts[rid].get(h, 0))} for h in range(24)],
                "trend": trend,
                "notes": "Counts are actual matching log events, not inventory hit counters.",
                "window_count_30d": int(recent30),
                "window_count_prev_30d": int(prev30),
            }
        )
        metrics[rid] = metric

    duration = time.time() - started
    summary = {
        "rows_scanned": rows_scanned,
        "rows_matched": rows_matched,
        "rows_unmatched": rows_unmatched,
        "rows_bad_timestamp": bad_timestamp,
        "match_rate": round(rows_matched / rows_scanned, 4) if rows_scanned else 0.0,
        "rules_with_log_events": len(totals),
        "rules_without_log_events": len(rules) - len(totals),
        "first_timestamp": global_min.isoformat() if global_min else None,
        "last_timestamp": global_max.isoformat() if global_max else None,
        "coverage_days": coverage_days,
        "identity_space_ok": bool(identity_space_ok),
        "absence_is_evidence": bool(absence_is_evidence),
        "uid_resolved_rows": uid_resolved,
        "weak_resolved_rows": weak_resolved,
        "observation_window": {
            "start": window_start.isoformat() if window_start else None,
            "end": window_end.isoformat() if window_end else None,
            "days": effective_window,
            "policy_observation_days": observation_days,
            "note": "Window ends at the latest log timestamp in the uploaded dataset; days-since-last-hit is measured against today.",
        },
        "unmatched_reasons": dict(unmatched_reasons),
        "unmatched_identifiers": [{"identifier": k, "count": int(v)} for k, v in unmatched_identifiers.most_common(10)],
        "unmatched_examples": unmatched_examples,
        "duration_seconds": round(duration, 2),
        "rows_per_second": round(rows_scanned / duration, 1) if duration > 0 else 0,
    }
    return metrics, summary
