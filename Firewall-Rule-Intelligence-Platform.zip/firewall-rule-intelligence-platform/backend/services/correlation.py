"""Correlation engine: rule <-> change records and rule <-> log events.

Matching is deliberately strict. Similar-looking names are never merged, and an
ambiguous key (one value matching several rules) produces no match plus an
explanation instead of a guess.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime

from backend.services.normalize import clean_text, extract_tokens

UID_METHOD = "rule_uid"
NUMBER_METHOD = "rule_number"
NUMBER_DEVICE_METHOD = "rule_number+device"
NAME_METHOD = "rule_name"
NAME_DEVICE_METHOD = "rule_name+device"
COMMENT_METHOD = "comments_change_reference"


def norm_uid(value: str | None) -> str:
    return clean_text(value).lower()


def norm_number(value: str | None) -> str:
    text = clean_text(value)
    # Logs often render 32 as "32.0"
    if re.fullmatch(r"\d+\.0", text):
        text = text[:-2]
    return text


def norm_name(value: str | None) -> str:
    return re.sub(r"\s+", " ", clean_text(value).lower())


def norm_device(value: str | None) -> str:
    text = clean_text(value).lower()
    text = re.sub(r"@.*", "", text)
    return text.strip()


@dataclass
class RuleRef:
    index: int
    rule_uid: str
    rule_number: str
    rule_name: str
    device: str
    section: str
    comments: str


class RuleIndex:
    """Resolve log/change references to rule rows using the documented hierarchy."""

    def __init__(self, rules: list[RuleRef]):
        self.rules = rules
        self._uid: dict[str, list[int]] = defaultdict(list)
        self._number: dict[str, list[int]] = defaultdict(list)
        self._name: dict[str, list[int]] = defaultdict(list)
        for rule in rules:
            if rule.rule_uid:
                self._uid[norm_uid(rule.rule_uid)].append(rule.index)
            number = norm_number(rule.rule_number)
            if number:
                self._number[number].append(rule.index)
            name = norm_name(rule.rule_name)
            if name:
                self._name[name].append(rule.index)
        self.ambiguous_numbers = {k for k, v in self._number.items() if len(v) > 1}
        self.ambiguous_names = {k for k, v in self._name.items() if len(v) > 1}

    def resolve(self, uid: str, number: str, name: str, device: str = "") -> tuple[int | None, str, float, str]:
        """Return (rule_index, method, confidence, note)."""
        uid_key = norm_uid(uid)
        if uid_key:
            hits = self._uid.get(uid_key, [])
            if len(hits) == 1:
                return hits[0], UID_METHOD, 1.0, "Exact rule UID match"
            if len(hits) > 1:
                return None, "ambiguous_uid", 0.0, "Rule UID appears on several inventory rows"

        number_key = norm_number(number)
        if number_key:
            hits = self._number.get(number_key, [])
            if len(hits) == 1:
                rule = self.rules[hits[0]]
                if rule.device and device:
                    if norm_device(rule.device) and norm_device(rule.device) not in norm_device(device) and norm_device(device) not in norm_device(rule.device):
                        return None, "device_mismatch", 0.0, "Rule number matched but firewall/device identity differs"
                    return hits[0], NUMBER_DEVICE_METHOD, 0.95, "Rule number + firewall/device match"
                if rule.device:
                    return hits[0], NUMBER_METHOD, 0.8, "Rule number match; log has no device identity"
                return hits[0], NUMBER_METHOD, 0.85, "Rule number match (inventory has no device identity)"
            if len(hits) > 1:
                device_key = norm_device(device)
                if device_key:
                    narrowed = [i for i in hits if norm_device(self.rules[i].device) and norm_device(self.rules[i].device) == device_key]
                    if len(narrowed) == 1:
                        return narrowed[0], NUMBER_DEVICE_METHOD, 0.95, "Rule number + exact device narrowed to one rule"
                return None, "ambiguous_number", 0.0, "Rule number matches several rules and device does not disambiguate"

        name_key = norm_name(name)
        if name_key:
            hits = self._name.get(name_key, [])
            if len(hits) == 1:
                rule = self.rules[hits[0]]
                if rule.device and device and norm_device(device) and norm_device(rule.device) != norm_device(device):
                    return None, "device_mismatch", 0.0, "Rule name matched but firewall/device identity differs"
                if rule.device and device:
                    return hits[0], NAME_DEVICE_METHOD, 0.7, "Rule name + firewall/device match"
                return hits[0], NAME_METHOD, 0.6, "Exact rule name match (weakest supported method)"
            if len(hits) > 1:
                return None, "ambiguous_name", 0.0, "Rule name is not unique in the inventory"
        return None, "unmatched", 0.0, "No rule UID, number or name match"


@dataclass
class ChangeLink:
    rule_index: int
    change_index: int
    method: str
    confidence: float
    evidence: str


@dataclass
class RuleChangeSummary:
    records: list[dict] = field(default_factory=list)
    methods: list[str] = field(default_factory=list)
    owner: str = ""
    change_request: str = ""
    change_task: str = ""
    change_status: str = ""
    documented: bool = False
    incomplete: bool = False
    conflicting: bool = False
    notes: list[str] = field(default_factory=list)


def link_changes(rules: list[RuleRef], changes: list[dict]) -> tuple[list[ChangeLink], dict[int, RuleChangeSummary], dict]:
    """Link change records to rules, many-to-many, and summarise per rule."""
    index = RuleIndex(rules)
    by_chg: dict[str, list[int]] = defaultdict(list)
    by_ctask: dict[str, list[int]] = defaultdict(list)
    for i, rec in enumerate(changes):
        if rec.get("chg_number"):
            by_chg[clean_text(rec["chg_number"]).upper()].append(i)
        if rec.get("ctask_number"):
            by_ctask[clean_text(rec["ctask_number"]).upper()].append(i)

    links: list[ChangeLink] = []
    seen: set[tuple[int, int]] = set()
    unresolved = Counter()
    unresolved_examples: list[dict] = []

    def add(rule_idx: int, change_idx: int, method: str, confidence: float, evidence: str) -> None:
        key = (rule_idx, change_idx)
        if key in seen:
            return
        seen.add(key)
        links.append(ChangeLink(rule_idx, change_idx, method, confidence, evidence))

    for i, rec in enumerate(changes):
        uid = rec.get("rule_uid") or ""
        number = rec.get("rule_number") or ""
        name = rec.get("rule_name") or ""
        if not any([uid, number, name]):
            continue
        rule_idx, method, conf, note = index.resolve(uid, number, name, rec.get("device") or "")
        if rule_idx is None:
            unresolved[method] += 1
            if len(unresolved_examples) < 25:
                unresolved_examples.append(
                    {
                        "change_task": rec.get("ctask_number"),
                        "change_request": rec.get("chg_number"),
                        "rule_uid": uid,
                        "rule_number": number,
                        "rule_name": name,
                        "reason": note,
                    }
                )
            continue
        evidence = f"{note}; ctask={rec.get('ctask_number') or '-'} chg={rec.get('chg_number') or '-'}"
        add(rule_idx, i, method, conf, evidence)

        # A change task row may carry only the change request; attach matching task details too.
        if rec.get("chg_number"):
            for j in by_chg.get(clean_text(rec["chg_number"]).upper(), []):
                if j != i and not (changes[j].get("rule_uid") or changes[j].get("rule_number")):
                    add(rule_idx, j, method + "+chg_join", max(0.5, conf - 0.15), f"Joined by change request {rec['chg_number']}")
        if rec.get("ctask_number"):
            for j in by_ctask.get(clean_text(rec["ctask_number"]).upper(), []):
                if j != i and not (changes[j].get("rule_uid") or changes[j].get("rule_number")):
                    add(rule_idx, j, method + "+ctask_join", max(0.5, conf - 0.1), f"Joined by change task {rec['ctask_number']}")

    # Comments on the rule often reference change records explicitly.
    for rule in rules:
        chgs, ctasks = extract_tokens(rule.comments)
        for chg in chgs:
            for j in by_chg.get(chg, []):
                add(rule.index, j, COMMENT_METHOD, 0.7, f"Change request {chg} referenced in rule comments")
        for ctask in ctasks:
            for j in by_ctask.get(ctask, []):
                add(rule.index, j, COMMENT_METHOD, 0.7, f"Change task {ctask} referenced in rule comments")

    summaries: dict[int, RuleChangeSummary] = {}
    by_rule: dict[int, list[ChangeLink]] = defaultdict(list)
    for link in links:
        by_rule[link.rule_index].append(link)

    for rule in rules:
        rule_links = by_rule.get(rule.index, [])
        summary = RuleChangeSummary(methods=sorted({l.method for l in rule_links}))
        records: list[dict] = []
        for link in sorted(rule_links, key=lambda l: -l.confidence):
            rec = dict(changes[link.change_index])
            rec["_match_method"] = link.method
            rec["_match_confidence"] = link.confidence
            rec["_match_evidence"] = link.evidence
            records.append(rec)
        summary.records = records

        owners = {clean_text(r.get("assigned_to")) for r in records if clean_text(r.get("assigned_to"))}
        states = {clean_text(r.get("state")) for r in records if clean_text(r.get("state"))}
        chgs = sorted({clean_text(r.get("chg_number")) for r in records if clean_text(r.get("chg_number"))})
        ctasks = sorted({clean_text(r.get("ctask_number")) for r in records if clean_text(r.get("ctask_number"))})
        summary.owner = sorted(owners)[0] if owners else ""
        if len(owners) > 1:
            summary.conflicting = True
            summary.notes.append(f"Multiple assigned owners across linked change records: {', '.join(sorted(owners))}")
        summary.change_request = chgs[0] if chgs else ""
        summary.change_task = ctasks[0] if ctasks else ""
        summary.change_status = states.pop() if len(states) == 1 else ("Multiple" if states else "")
        if len(states) > 1:
            summary.conflicting = True
            summary.notes.append(f"Conflicting change task states: {', '.join(sorted(states))}")
        has_detail = any(clean_text(r.get("state")) and clean_text(r.get("short_description")) for r in records)
        summary.documented = bool(records) and has_detail
        summary.incomplete = bool(records) and not has_detail
        if not records:
            summary.notes.append("No change request or change task could be linked to this rule")
        elif summary.incomplete:
            summary.notes.append("Linked change records lack state or description (documentation incomplete)")
        if len(records) > 1:
            summary.notes.append(f"{len(records)} change records linked")
        summaries[rule.index] = summary

    stats = {
        "change_records": len(changes),
        "links_created": len(links),
        "rules_with_changes": len(by_rule),
        "rules_without_changes": len(rules) - len(by_rule),
        "methods": dict(Counter(l.method for l in links)),
        "unresolved_change_references": sum(unresolved.values()),
        "unresolved_reasons": dict(unresolved),
        "unresolved_examples": unresolved_examples,
    }
    return links, summaries, stats


def change_history_payload(summary: RuleChangeSummary | None) -> list[dict]:
    if not summary:
        return []
    out = []
    for rec in summary.records:
        out.append(
            {
                "ctask_number": rec.get("ctask_number", ""),
                "chg_number": rec.get("chg_number", ""),
                "state": rec.get("state", ""),
                "assigned_to": rec.get("assigned_to", ""),
                "short_description": rec.get("short_description", ""),
                "planned_end_date": rec.get("planned_end_date").isoformat() if isinstance(rec.get("planned_end_date"), datetime) else "",
                "match_method": rec.get("_match_method", ""),
                "match_confidence": rec.get("_match_confidence", 0),
                "match_evidence": rec.get("_match_evidence", ""),
                "source_kind": rec.get("source_kind", ""),
                "source_file": rec.get("source_file", ""),
                "source_sheet": rec.get("source_sheet", ""),
                "source_row": rec.get("source_row"),
            }
        )
    return out
