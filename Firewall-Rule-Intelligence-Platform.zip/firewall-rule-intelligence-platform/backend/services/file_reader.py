"""Safe file validation and chunked readers for XLSX / XLS / CSV uploads."""
from __future__ import annotations

import csv
import hashlib
import os
import zipfile
from datetime import datetime
from collections.abc import Iterator
from pathlib import Path

import pandas as pd

from backend.config import Settings

ALLOWED_EXTENSIONS = {".xlsx": "xlsx", ".xls": "xls", ".csv": "csv", ".txt": "csv"}
OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


class FileValidationError(ValueError):
    pass


def sniff_kind(path: str | Path, original_name: str = "") -> str:
    ext = Path(original_name or str(path)).suffix.lower()
    if ext == ".xlsm":
        raise FileValidationError("Macro-enabled workbooks (.xlsm) are rejected for security reasons. Save as .xlsx first.")
    if ext not in ALLOWED_EXTENSIONS:
        raise FileValidationError(f"Unsupported file type '{ext}'. Allowed: .xlsx, .xls, .csv")
    return ALLOWED_EXTENSIONS[ext]


def validate_upload(path: str | Path, original_name: str, dataset_type: str) -> dict:
    """Validate an uploaded file before any parsing happens."""
    p = Path(path)
    if not p.exists():
        raise FileValidationError("Uploaded file not found on disk.")
    size = p.stat().st_size
    if size == 0:
        raise FileValidationError("Uploaded file is empty.")
    if size > Settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise FileValidationError(
            f"File is {size / 1048576:.1f} MB which exceeds the configured limit of {Settings.MAX_UPLOAD_MB} MB."
        )
    kind = sniff_kind(p, original_name)
    with p.open("rb") as fh:
        head = fh.read(8)
    if kind == "xlsx":
        if not head.startswith(b"PK"):
            raise FileValidationError("File does not look like a real .xlsx workbook (missing ZIP signature).")
        try:
            with zipfile.ZipFile(p) as zf:
                names = zf.namelist()
                if "[Content_Types].xml" not in names:
                    raise FileValidationError("Workbook is missing [Content_Types].xml - file is corrupt.")
                total = sum(i.file_size for i in zf.infolist())
        except zipfile.BadZipFile as exc:
            raise FileValidationError(f"Corrupt or unsafe workbook: {exc}") from exc
        if total > 0 and total / max(size, 1) > 250:
            raise FileValidationError("Workbook compression ratio is abnormally high (possible zip bomb). Rejected.")
    elif kind == "xls":
        if not head.startswith(OLE_MAGIC):
            raise FileValidationError("File does not look like a real legacy .xls workbook.")
        try:
            import xlrd  # noqa: F401
        except ImportError as exc:
            raise FileValidationError(
                "Reading .xls requires the 'xlrd' package. Install it or save the file as .xlsx."
            ) from exc
    else:
        if b"\x00" in head:
            raise FileValidationError("CSV appears to be binary; only delimited text is supported.")
    checksum = hashlib.sha256()
    with p.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            checksum.update(block)
    return {
        "kind": kind,
        "size_bytes": size,
        "checksum": checksum.hexdigest(),
        "dataset_type": dataset_type,
    }


def list_sheets(path: str | Path, kind: str) -> list[str]:
    if kind != "xlsx":
        return []
    try:
        with pd.ExcelFile(path, engine="openpyxl") as xl:
            return list(xl.sheet_names)
    except Exception as exc:  # noqa: BLE001
        raise FileValidationError(f"Could not read workbook sheets: {exc}") from exc


def _csv_rows_preview(path: str | Path, limit: int = 15) -> list[list[str]]:
    delimiters = [",", ";", "\t", "|"]
    best: list[list[str]] = []
    best_score = -1
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            with open(path, "r", encoding=encoding, newline="", errors="strict") as fh:
                for delim in delimiters:
                    fh.seek(0)
                    reader = csv.reader(fh, delimiter=delim)
                    rows = []
                    for _ in range(limit):
                        try:
                            rows.append(next(reader))
                        except StopIteration:
                            break
                    if not rows:
                        continue
                    score = max((len(r) for r in rows), default=0)
                    if score > best_score:
                        best_score = score
                        best = rows
            if best:
                return best
        except UnicodeDecodeError:
            continue
    return best


def detect_header(rows: list[list], max_scan: int = 15) -> tuple[int, list[str]]:
    """Pick the row in the first rows that looks most like a header."""
    best_idx, best_cols, best_score = 0, [], -1.0
    for idx, row in enumerate(rows[:max_scan]):
        cells = [str(c).strip() for c in row if c is not None and str(c).strip() != ""]
        if len(cells) < 2:
            continue
        textual = sum(1 for c in cells if any(ch.isalpha() for ch in c))
        score = len(cells) + textual * 0.5 - idx * 0.1
        if len(set(cells)) < len(cells):
            score -= 2  # duplicated headers are legitimate, but prefer cleaner rows
        if score > best_score:
            best_idx, best_cols, best_score = idx, list(row), score
    if not best_cols:
        raise FileValidationError("Could not detect a header row in the uploaded file.")
    deduped = _dedupe_columns([("" if c is None else str(c).strip()) for c in best_cols])
    return best_idx, deduped


def _dedupe_columns(cols: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    out: list[str] = []
    for i, col in enumerate(cols):
        name = col or f"Column {i + 1}"
        if name in seen:
            seen[name] += 1
            name = f"{name} ({seen[name]})"
        else:
            seen[name] = 0
        out.append(name)
    return out


def read_preview(path: str | Path, kind: str, sheet: str | None, header_row: int | None = None, nrows: int = 20) -> dict:
    """Return header row index, column names and up to `nrows` records for preview."""
    if kind == "csv":
        rows = _csv_rows_preview(path, limit=max(16, (header_row or 0) + nrows + 2))
        if not rows:
            raise FileValidationError("CSV file has no readable rows.")
        idx, columns = detect_header(rows) if header_row is None else (header_row, _dedupe_columns([str(c) for c in rows[header_row]]))
        data = rows[idx + 1: idx + 1 + nrows]
        records = []
        for r in data:
            padded = (list(r) + [""] * len(columns))[: len(columns)]
            records.append({c: ("" if v is None else v) for c, v in zip(columns, padded)})
        return {"header_row": idx, "columns": columns, "rows": records}

    raw = pd.read_excel(path, sheet_name=sheet, header=None, nrows=(header_row or 0) + nrows + 16, dtype=object)
    raw = raw.dropna(how="all").dropna(axis=1, how="all")
    rows = raw.values.tolist()
    if not rows:
        raise FileValidationError(f"Sheet '{sheet}' is empty.")
    idx, columns = detect_header(rows) if header_row is None else (header_row, _dedupe_columns([str(c) for c in rows[header_row]]))
    records = []
    for r in rows[idx + 1: idx + 1 + nrows]:
        values = list(r)[: len(columns)] + [""] * max(0, len(columns) - len(r))
        records.append({c: _clean_cell(v) for c, v in zip(columns, values)})
    return {"header_row": idx, "columns": columns, "rows": records}


def _clean_cell(value):
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    if isinstance(value, pd.Timestamp):
        return value.to_pydatetime()
    return value


def iter_chunks(
    path: str | Path,
    kind: str,
    sheet: str | None,
    header_row: int,
    columns: list[str],
    chunk_size: int | None = None,
) -> Iterator[list[dict]]:
    """Yield chunks of raw records (dict keyed by source column) with row numbers."""
    chunk_size = chunk_size or Settings.CHUNK_SIZE
    if kind == "csv":
        last_exc: Exception | None = None
        for encoding in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                yield from _iter_csv(path, encoding, header_row, columns, chunk_size)
                return
            except UnicodeDecodeError as exc:
                last_exc = exc
                continue
        raise FileValidationError(f"Could not decode CSV file: {last_exc}")
    yield from _iter_excel(path, sheet, header_row, columns, chunk_size)


def _iter_csv(path, encoding, header_row, columns, chunk_size):
    with open(path, "r", encoding=encoding, newline="") as fh:
        sample = fh.read(8192)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        reader = csv.reader(fh, dialect)
        for _ in range(header_row + 1):
            next(reader, None)
        batch: list[dict] = []
        row_no = header_row + 1
        for raw in reader:
            row_no += 1
            values = list(raw)[: len(columns)] + [""] * max(0, len(columns) - len(raw))
            batch.append({**{c: v for c, v in zip(columns, values)}, "__row__": row_no})
            if len(batch) >= chunk_size:
                yield batch
                batch = []
        if batch:
            yield batch


def _iter_excel(path, sheet, header_row, columns, chunk_size):
    from openpyxl import load_workbook

    wb = load_workbook(filename=str(path), read_only=True, data_only=True)
    try:
        ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb[wb.sheetnames[0]]
        batch: list[dict] = []
        for row_no, row in enumerate(ws.iter_rows(min_row=header_row + 2, values_only=True), start=header_row + 2):
            if row is None or all(v is None for v in row):
                continue
            values = list(row)[: len(columns)] + [None] * max(0, len(columns) - len(row))
            batch.append({**{c: v for c, v in zip(columns, values)}, "__row__": row_no})
            if len(batch) >= chunk_size:
                yield batch
                batch = []
        if batch:
            yield batch
    finally:
        wb.close()


def safe_export_cell(value):
    """Neutralise spreadsheet formula injection in generated reports."""
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


def store_upload_bytes(stream, dataset_dir: Path, original_name: str) -> tuple[Path, int]:
    """Persist an upload without ever overwriting the source file."""
    dataset_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(original_name).stem[:80] or "upload"
    ext = Path(original_name).suffix.lower()
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
    target = dataset_dir / f"{stem}_{stamp}{ext}"
    size = 0
    with target.open("wb") as fh:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            size += len(block)
            if size > Settings.MAX_UPLOAD_MB * 1024 * 1024:
                fh.close()
                os.remove(target)
                raise FileValidationError(f"Upload exceeds the {Settings.MAX_UPLOAD_MB} MB limit.")
            fh.write(block)
    return target, size
