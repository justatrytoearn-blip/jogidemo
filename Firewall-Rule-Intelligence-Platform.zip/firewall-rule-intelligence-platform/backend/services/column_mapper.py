"""Canonical field definitions and automatic column mapping.

The engine never requires source files to match a fixed template: it scores every
source column against a synonym list, then uses value-shape inference for anything
left unmapped. Manual overrides from the portal always win.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher

GUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
IP_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}")
DATE_RE = re.compile(r"^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}")
ACTION_TOKENS = {
    "accept", "drop", "allow", "deny", "block", "reject", "permit", "discard",
    "established", "monitor", "encrypt", "decrypt",
}
SECTION_TOKENS = {"section", "sections", "layer"}


def normalize_header(name: str) -> str:
    text = str(name or "").strip().lower()
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


@dataclass(frozen=True)
class CanonicalField:
    key: str
    label: str
    synonyms: tuple[str, ...]
    required: bool = False
    value_hint: str = ""  # guid | datetime | ip | action | int | port | text
    description: str = ""


RULES_FIELDS: tuple[CanonicalField, ...] = (
    CanonicalField("rule_number", "Rule Number", ("rule number", "rule no", "rule num", "rulenumber", "number", "no", "rule id", "rule"), True, "text"),
    CanonicalField("rule_name", "Rule Name", ("name", "rule name", "rulename", "rule label", "object name"), False),
    CanonicalField("rule_uid", "Rule UID", ("uid", "rule uid", "rule id uid", "uuid", "guid", "rule uuid"), False, "guid"),
    CanonicalField("security_section", "Security Section", ("security section", "section", "section name", "layer name", "policy package", "package", "policy"), False),
    CanonicalField("source", "Source", ("source", "src", "source address", "source object", "src addr", "from"), False),
    CanonicalField("destination", "Destination", ("destination", "dst", "dest", "destination address", "destination object", "to"), False),
    CanonicalField("service", "Service", ("services and action", "service", "services", "port", "service id", "applications"), False),
    CanonicalField("action", "Action", ("action", "rule action", "policy action"), False, "action"),
    CanonicalField("hit_count", "Hit Count", ("hits", "hit count", "number of hits", "hitcnt", "hit counter", "hit count value"), False, "int"),
    CanonicalField("first_hit", "First Hit", ("first hits", "first hit", "first used", "first match", "first hit date"), False, "datetime"),
    CanonicalField("last_hit", "Last Hit", ("last hits", "last hit", "last used", "last match", "last hit date"), False, "datetime"),
    CanonicalField("comments", "Comments", ("comments", "comment", "rule comments field", "remarks", "notes", "description"), False),
    CanonicalField("install_on", "Install On", ("install on", "installed on", "installation details", "installation", "target", "policy targets"), False),
    CanonicalField("device", "Firewall / Device", ("device", "firewall", "gateway", "firewall name", "machine name", "hostname"), False),
    CanonicalField("track", "Track", ("track", "logging", "log", "tracking"), False),
    CanonicalField("vpn", "VPN", ("vpn", "vpn column"), False),
    CanonicalField("expiry_date", "Expiry Date", ("expiry", "expiry date", "expiration", "expiration date", "valid until", "end date", "review date"), False, "datetime"),
    CanonicalField("owner", "Owner", ("owner", "rule owner", "business owner", "assigned to", "assignee"), False),
    CanonicalField("type", "Row Type", ("type", "row type", "record type"), False),
)

CHANGES_FIELDS: tuple[CanonicalField, ...] = (
    CanonicalField("ctask_number", "Change Task Number", ("number", "ctask", "ctask number", "change task", "change task number", "task number", "linked ctask number", "task"), True),
    CanonicalField("chg_number", "Change Request Number", ("change request", "change request number", "change number", "chg", "chg number", "primary change request", "change"), False),
    CanonicalField("state", "Task State", ("state", "task state", "status", "change state"), False),
    CanonicalField("assigned_to", "Assigned To", ("assigned to", "assignee", "assignee name", "assigned person", "owner", "assignee name"), False),
    CanonicalField("short_description", "Short Description", ("short description", "change task description", "description", "task description", "summary", "short desc"), False),
    CanonicalField("planned_end_date", "Planned End Date", ("planned end date", "planned end", "end date", "due date", "planned finish"), False, "datetime"),
    CanonicalField("rule_number", "Rule Number", ("rule number", "rule no", "rule"), False),
    CanonicalField("rule_uid", "Rule UID", ("rule uid", "uid", "rule uuid", "guid"), False, "guid"),
    CanonicalField("rule_name", "Rule Name", ("rule name", "name", "access rule name"), False),
)

LOGS_FIELDS: tuple[CanonicalField, ...] = (
    CanonicalField("timestamp", "Timestamp", ("time", "timestamp", "event time", "log time", "date time", "datetime", "start time", "log timestamp"), True, "datetime"),
    CanonicalField("device", "Firewall / Device", ("machine name", "device", "firewall", "firewall name", "host", "gateway", "blade", "log source", "origin"), False),
    CanonicalField("rule_number", "Rule Number", ("rule", "rule number", "rule no", "rule id", "policy rule number", "rule num"), False),
    CanonicalField("rule_uid", "Rule UID", ("policy rule uid", "rule uid", "uid", "rule guid", "rule uuid"), False, "guid"),
    CanonicalField("rule_name", "Rule Name", ("access rule name", "rule name", "policy rule name", "rule label"), False),
    CanonicalField("src_ip", "Source IP", ("source", "src", "source ip", "src ip", "source address"), False, "ip"),
    CanonicalField("dst_ip", "Destination IP", ("destination", "dst", "dest", "destination ip", "dest ip", "destination address"), False, "ip"),
    CanonicalField("src_zone", "Source Zone", ("security inzone", "security_inzone", "source zone", "src zone", "in zone", "ingress zone"), False),
    CanonicalField("dst_zone", "Destination Zone", ("destination zone", "dst zone", "dest zone", "out zone", "egress zone"), False),
    CanonicalField("src_port", "Source Port", ("source port", "src port", "sport"), False, "port"),
    CanonicalField("dst_port", "Destination Port", ("destination port", "dst port", "dest port", "dport", "port"), False, "port"),
    CanonicalField("protocol", "Protocol", ("protocol", "proto"), False),
    CanonicalField("action", "Action", ("action", "rule action", "policy action"), False, "action"),
    CanonicalField("bytes", "Bytes", ("bytes", "bytes transferred", "byte count", "total bytes", "traffic volume"), False, "int"),
    CanonicalField("packets", "Packets", ("packets", "packet count", "total packets"), False, "int"),
    CanonicalField("session", "Session", ("session", "session id", "snid", "connection id", "session information"), False),
    CanonicalField("service", "Service", ("service", "service id", "services"), False),
    CanonicalField("interface", "Interface", ("interface", "interface name"), False),
    CanonicalField("direction", "Direction", ("interface direction", "direction", "direction of connection", "connection direction"), False),
    CanonicalField("message", "Message", ("message information", "message", "description", "reason", "log message"), False),
)

FIELDS_BY_TYPE = {
    "rules": RULES_FIELDS,
    "changes": CHANGES_FIELDS,
    "logs": LOGS_FIELDS,
}

DATASET_LABELS = {
    "rules": "Firewall Rule Inventory",
    "changes": "ServiceNow Change Records",
    "logs": "Firewall Logs",
}


@dataclass
class MappingResult:
    mapping: dict[str, str | None]
    scores: dict[str, float] = field(default_factory=dict)
    unmapped_columns: list[str] = field(default_factory=list)
    missing_required: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    needs_manual_mapping: bool = False
    required_fields: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "mapping": self.mapping,
            "scores": self.scores,
            "unmapped_columns": self.unmapped_columns,
            "missing_required": self.missing_required,
            "warnings": self.warnings,
            "needs_manual_mapping": self.needs_manual_mapping,
            "required_fields": self.required_fields,
        }


def _column_samples(df, column: str, limit: int = 60) -> list[str]:
    try:
        series = df[column].dropna().astype(str).str.strip()
    except Exception:
        return []
    series = series[series != ""]
    return series.head(limit).tolist()


def _value_score(values: list[str], hint: str) -> float:
    """Return 0..1 confidence that a column's values fit a canonical hint."""
    if not values:
        return 0.0
    total = len(values)
    if hint == "guid":
        hits = sum(1 for v in values if GUID_RE.match(v))
    elif hint == "ip":
        hits = sum(1 for v in values if IP_RE.match(v) or re.match(r"^[A-Za-z0-9_.\-]+ \(\d", v))
    elif hint == "datetime":
        hits = sum(1 for v in values if DATETIME_RE.match(v) or DATE_RE.match(v) or _looks_like_excel_date(v))
    elif hint == "action":
        hits = sum(1 for v in values if v.lower() in ACTION_TOKENS)
    elif hint == "int":
        hits = sum(1 for v in values if re.fullmatch(r"-?\d[\d,]*(?:\.0+)?", v) or re.search(r"number of hits", v, re.I))
    elif hint == "port":
        hits = sum(1 for v in values if re.fullmatch(r"\d{1,5}", v))
    else:
        return 0.0
    return hits / total


def _looks_like_excel_date(value: str) -> bool:
    return bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?", value))


def detect_mapping(columns: list[str], dataset_type: str, df=None) -> MappingResult:
    """Map source columns to canonical fields using synonyms, fuzzy scores and values."""
    fields = FIELDS_BY_TYPE[dataset_type]
    normalized_cols = [(c, normalize_header(c)) for c in columns]
    candidates: list[tuple[float, str, str]] = []  # score, field_key, column

    for fld in fields:
        syn_norm = [normalize_header(s) for s in fld.synonyms]
        for raw_col, norm_col in normalized_cols:
            best = 0.0
            for syn in syn_norm:
                if norm_col == syn:
                    best = max(best, 1.0)
                elif len(syn) >= 4 and (norm_col.startswith(syn + " ") or norm_col.endswith(" " + syn)):
                    best = max(best, 0.92)
                elif len(syn) >= 6 and syn in norm_col:
                    best = max(best, 0.82)
                else:
                    ratio = SequenceMatcher(None, norm_col, syn).ratio()
                    if ratio >= 0.9:
                        best = max(best, ratio * 0.9)
            if best:
                candidates.append((best, fld.key, raw_col))

    # Value-shape inference is limited to strongly identifiable shapes (GUID, dates, IPs).
    # Numeric guessing is deliberately excluded: many unrelated columns contain digits.
    inferred_hints = {"guid", "datetime", "ip"}
    mapped_cols = {col for score, _key, col in candidates if score >= 0.8}
    if df is not None:
        for fld in fields:
            if fld.key in {key for score, key, _c in candidates if score >= 0.8} or fld.value_hint not in inferred_hints:
                continue
            for raw_col, _norm in normalized_cols:
                if raw_col in mapped_cols:
                    continue
                score = _value_score(_column_samples(df, raw_col), fld.value_hint)
                if score >= 0.85:
                    candidates.append((0.75, fld.key, raw_col))
                    mapped_cols.add(raw_col)

    candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
    mapping: dict[str, str | None] = {f.key: None for f in fields}
    scores: dict[str, float] = {}
    used_columns: set[str] = set()
    for score, key, col in candidates:
        if mapping.get(key) or col in used_columns:
            continue
        if score < 0.6:
            continue
        mapping[key] = col
        scores[key] = round(score, 3)
        used_columns.add(col)

    required = [f.key for f in fields if f.required]
    # A dataset is usable when at least one identifying field is present.
    missing_required = [k for k in required if not mapping.get(k)]
    if dataset_type == "rules" and not any(mapping.get(k) for k in ("rule_uid", "rule_number", "rule_name")):
        missing_required.append("rule identity (rule_uid / rule_number / rule_name)")
    if dataset_type == "changes" and not any(mapping.get(k) for k in ("ctask_number", "chg_number", "rule_uid", "rule_number")):
        missing_required.append("change identity (ctask / chg / rule reference)")
    if dataset_type == "logs" and mapping.get("timestamp") and not any(
        mapping.get(k) for k in ("rule_uid", "rule_number", "rule_name")
    ):
        missing_required.append("rule reference (rule_uid / rule_number / rule_name)")

    unmapped = [c for c in columns if c not in used_columns]
    warnings: list[str] = []
    if mapping.get("rule_name") and mapping.get("rule_name") == mapping.get("rule_number"):
        warnings.append("Rule number and rule name point at the same column; please confirm the mapping.")
    if dataset_type == "logs" and not mapping.get("rule_uid"):
        warnings.append(
            "No rule UID column detected - correlation will fall back to rule number/name matching with lower confidence."
        )
    if dataset_type == "logs" and not mapping.get("device") and not mapping.get("interface"):
        warnings.append("No firewall/device column detected; rule-number matches may be ambiguous across devices.")

    needs_manual = bool(missing_required)
    return MappingResult(
        mapping=mapping,
        scores=scores,
        unmapped_columns=unmapped,
        missing_required=missing_required,
        warnings=warnings,
        needs_manual_mapping=needs_manual,
        required_fields=required,
    )


def merge_manual_mapping(detected: MappingResult, manual: dict[str, str | None], dataset_type: str) -> MappingResult:
    """Apply user overrides; drop any column now used by a different field."""
    mapping = dict(detected.mapping)
    for key, column in manual.items():
        if key not in mapping:
            continue
        if column in ("", None):
            mapping[key] = None
            continue
        for other, existing in mapping.items():
            if other != key and existing == column:
                mapping[other] = None
        mapping[key] = column

    fields = {f.key for f in FIELDS_BY_TYPE[dataset_type]}
    used = {v for v in mapping.values() if v}
    required = [f.key for f in FIELDS_BY_TYPE[dataset_type] if f.required]
    missing_required = [k for k in required if not mapping.get(k)]
    if dataset_type == "rules" and not any(mapping.get(k) for k in ("rule_uid", "rule_number", "rule_name")):
        missing_required.append("rule identity (rule_uid / rule_number / rule_name)")
    if dataset_type == "changes" and not any(mapping.get(k) for k in ("ctask_number", "chg_number", "rule_uid", "rule_number")):
        missing_required.append("change identity (ctask / chg / rule reference)")
    if dataset_type == "logs" and mapping.get("timestamp") and not any(
        mapping.get(k) for k in ("rule_uid", "rule_number", "rule_name")
    ):
        missing_required.append("rule reference (rule_uid / rule_number / rule_name)")

    return MappingResult(
        mapping={k: v for k, v in mapping.items() if k in fields},
        scores=detected.scores,
        unmapped_columns=[c for c in detected.unmapped_columns if c not in used],
        missing_required=missing_required,
        warnings=list(detected.warnings),
        needs_manual_mapping=bool(missing_required),
        required_fields=list(dict.fromkeys(detected.required_fields + required)),
    )
