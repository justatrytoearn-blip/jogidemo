"""Downloadable input templates. Templates are hints only - uploads are never forced to match them."""
from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from backend.config import TEMPLATE_DIR
from backend.services.column_mapper import DATASET_LABELS, FIELDS_BY_TYPE

TEMPLATE_SPECS = {
    "rules": [
        ("Rule Number", "1"),
        ("Rule Name", "Example - Internal DNS to AD"),
        ("Rule UID", "a41a9c13-813b-5ff6-a732-b816b916692d"),
        ("Security Section", "Qualys"),
        ("Source", "G_Internal_Nets"),
        ("Destination", "G_AD_Servers"),
        ("Services & Action", "tcp_53;udp_53"),
        ("Action", "Accept"),
        ("Hits", "Low (number of hits: 128)"),
        ("First Hits", "12/05/2026 08:10:00"),
        ("Last Hits", "01/11/2026 17:42:11"),
        ("Comments", "CHG_KKB0464990 owner: network-security@example.com"),
        ("Install On", "FW-Corp-11"),
        ("Track", "Log"),
        ("VPN", "Any"),
        ("Expiry Date", "31/12/2026"),
    ],
    "changes": [
        ("Number", "CTASK1237324"),
        ("State", "Closed"),
        ("Assigned to", "Ram Kamble"),
        ("Short description", "Temporary change task - network security"),
        ("Planned end date", "08-01-2026 14:25:21"),
        ("Change request", "CHG_KKB0464990"),
        ("Rule Number", "1"),
        ("Rule UID", "a41a9c13-813b-5ff6-a732-b816b916692d"),
        ("Rule Name", "Example - Internal DNS to AD"),
    ],
    "logs": [
        ("Time", "2026-11-05 15:00:12"),
        ("Machine Name", "ulv-dh1-vsx-01"),
        ("Rule", "27.18"),
        ("Policy Rule UID", "e18e94a3-b880-4c91-8d22-aabbccddeeff"),
        ("Access Rule Name", "Example - Internal DNS to AD"),
        ("Source", "10.84.56.82"),
        ("Destination", "10.172.68.10"),
        ("security_inzone", "InternalZone"),
        ("Destination Zone", "External"),
        ("Destination Port", "53"),
        ("Protocol", "TCP (6)"),
        ("Action", "Accept"),
        ("Bytes", "1024"),
        ("Packets", "8"),
        ("Service", "dns"),
    ],
}

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
EXAMPLE_FILL = PatternFill("solid", fgColor="EEF2F8")
BORDER = Border(bottom=Side(style="thin", color="C9D3E0"))


def build_template(dataset_type: str) -> Path:
    fields = {f.key: f for f in FIELDS_BY_TYPE[dataset_type]}
    wb = Workbook()
    ws = wb.active
    ws.title = f"{DATASET_LABELS[dataset_type][:24]} Template"
    headers = [h for h, _ in TEMPLATE_SPECS[dataset_type]]
    ws.append(headers)
    ws.append([v for _, v in TEMPLATE_SPECS[dataset_type]])
    ws.append([v for _, v in TEMPLATE_SPECS[dataset_type]])

    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = Font(bold=True, color="FFFFFF", size=10)
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[cell.column_letter].width = max(16, min(34, len(header) + 5))
        for row in (2, 3):
            ws.cell(row=row, column=col_idx).fill = EXAMPLE_FILL
            ws.cell(row=row, column=col_idx).border = BORDER
    ws.row_dimensions[1].height = 30
    ws.freeze_panes = "A2"

    guide = wb.create_sheet("Column Guide")
    guide.append(["Field", "Required", "Description"])
    for key, fld in fields.items():
        guide.append([fld.label, "Yes" if fld.required else "No", fld.description or ", ".join(fld.synonyms[:4])])
    for idx, width in enumerate((30, 12, 70), start=1):
        guide.column_dimensions[guide.cell(row=1, column=idx).column_letter].width = width
    for cell in guide[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = HEADER_FILL
    guide.freeze_panes = "A2"

    note = wb.create_sheet("Read Me")
    note["A1"] = "This template is optional."
    note["A1"].font = Font(bold=True, size=13)
    note["A3"] = (
        "The import engine detects columns automatically by header synonyms and value shapes, "
        "then lets you confirm or change the mapping in the portal. You do not need to reformat "
        "your source files to match these headers."
    )
    note["A3"].alignment = Alignment(wrap_text=True)
    note.column_dimensions["A"].width = 110
    note["A5"] = "Example rows are illustrative only and are not loaded as customer data."
    note["A5"].font = Font(italic=True, color="6B7280")

    TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)
    path = TEMPLATE_DIR / f"{dataset_type}_template.xlsx"
    wb.save(path)
    return path


def ensure_templates() -> dict[str, Path]:
    out = {}
    for dataset_type in TEMPLATE_SPECS:
        path = TEMPLATE_DIR / f"{dataset_type}_template.xlsx"
        if not path.exists():
            path = build_template(dataset_type)
        out[dataset_type] = path
    return out
