"""Batch AI narration jobs (kept separate from deterministic analysis)."""
from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.ai import reviewer
from backend.config import Settings, effective_ai_config, load_policy
from backend.database.db import session_scope
from backend.database.models import Recommendation, Rule, Run, TrafficMetric, utcnow
from backend.recommendation_engine.policy import Policy
from backend.services.analysis import build_rule_context

log = logging.getLogger("fip.ai.jobs")

CATEGORY_PRIORITY = {"DELETE": 0, "DISABLE": 1, "REVIEW": 2, "KEEP": 3}
RISK_PRIORITY = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}


def _targets(db: Session, run_id: int, rule_ids: list[int] | None, limit: int) -> list[int]:
    stmt = (
        select(Recommendation.rule_id, Recommendation.category, Recommendation.risk_level)
        .where(Recommendation.run_id == run_id)
    )
    if rule_ids:
        stmt = stmt.where(Recommendation.rule_id.in_(rule_ids))
    rows = db.execute(stmt).all()
    ordered = sorted(
        rows,
        key=lambda r: (CATEGORY_PRIORITY.get(r.category, 9), RISK_PRIORITY.get(r.risk_level, 9), r.rule_id),
    )
    return [r.rule_id for r in ordered[:limit]]


def generate_for_run(run_id: int, rule_ids: list[int] | None = None, limit: int | None = None, model: str | None = None):
    """Return a job function that fills AI narratives for a run.

    ``model`` lets one run use a different installed Ollama model without changing
    the global setting. It is recorded in the run statistics.
    """

    def job(progress):
        cfg = effective_ai_config()
        if not cfg["enabled"]:
            return {"message": "AI explanations disabled", "generated": 0, "skipped": 0}
        with session_scope() as db:
            run = db.get(Run, run_id)
            if not run:
                raise ValueError("Run not found")
            policy = Policy.from_dict(json.loads(run.policy_json or "{}"))
            targets = _targets(db, run_id, rule_ids, limit or cfg["max_rules"])
            total_rules = db.execute(select(Recommendation.id).where(Recommendation.run_id == run_id)).all()
        total = len(targets)
        generated = 0
        failed = 0
        progress(1, f"Preparing {total} rule(s) for local AI narration")

        def one(rule_id: int):
            with session_scope() as db:
                rule = db.get(Rule, rule_id)
                metric = db.execute(select(TrafficMetric).where(TrafficMetric.rule_id == rule_id)).scalars().first()
                rec = db.execute(select(Recommendation).where(Recommendation.rule_id == rule_id)).scalars().first()
                if not rule or not rec:
                    return None
                ctx = build_rule_context(db, rule, metric, rec, policy)
                rec_dict = {
                    "category": rec.category,
                    "risk_level": rec.risk_level,
                    "confidence": rec.confidence,
                    "triggers": json.loads(rec.triggers_json or "[]"),
                    "missing": json.loads(rec.missing_json or "[]"),
                    "approval_status": rec.approval_status,
                    "reason": rec.reason,
                    "business_impact": rec.business_impact,
                    "technical_impact": rec.technical_impact,
                    "next_action": rec.next_action,
                }
                narrative = reviewer.explain_rule(
                    {**ctx["rule"], "rule_uid": rule.rule_uid}, ctx["metric"], ctx["change"], rec_dict,
                    model=model,
                )
            with session_scope() as db:
                rec = db.execute(select(Recommendation).where(Recommendation.rule_id == rule_id)).scalars().first()
                rec.ai_json = json.dumps(narrative, default=str)
                rec.ai_generated = bool(narrative.get("generated"))
                rec.ai_validated = bool(narrative.get("validated"))
                rec.ai_model = narrative.get("model", "")
                db.commit()
            return narrative

        done = 0
        with ThreadPoolExecutor(max_workers=max(1, min(3, Settings.AI_CONCURRENCY))) as pool:
            futures = {pool.submit(one, rid): rid for rid in targets}
            for future in as_completed(futures):
                done += 1
                try:
                    result = future.result()
                    if result and result.get("generated"):
                        generated += 1
                    elif result is not None:
                        failed += 1
                except Exception as exc:  # noqa: BLE001
                    failed += 1
                    log.warning("AI narration failed for rule %s: %s", futures[future], exc)
                progress(int(done / max(total, 1) * 90) + 5, f"AI narration {done}/{total}")

        with session_scope() as db:
            run = db.get(Run, run_id)
            stats = json.loads(run.stats_json or "{}")
            stats["ai_status"] = "completed" if generated else "unavailable"
            stats["ai_generated_rules"] = generated
            stats["ai_failed_rules"] = failed
            stats["ai_reviewed_rules"] = total
            stats["ai_model"] = model or cfg["model"]
            stats["ai_skipped_rules"] = max(0, len(total_rules) - total)
            summary = reviewer.executive_summary(stats, policy.to_dict())
            stats["executive_summary"] = summary
            run.stats_json = json.dumps(stats, default=str)
            db.commit()

        progress(100, f"AI narration complete: {generated}/{total}")
        return {
            "message": f"AI narration generated for {generated} of {total} rule(s)",
            "generated": generated,
            "failed": failed,
            "reviewed": total,
            "skipped": max(0, len(total_rules) - total),
        }

    return job


def generate_single(rule_id: int, model: str | None = None) -> dict:
    """Regenerate narration for one rule (used by the rule detail page)."""
    with session_scope() as db:
        rule = db.get(Rule, rule_id)
        if not rule:
            raise ValueError("Rule not found")
        run = db.get(Run, rule.run_id)
        policy = Policy.from_dict(json.loads(run.policy_json or "{}"))
        metric = db.execute(select(TrafficMetric).where(TrafficMetric.rule_id == rule_id)).scalars().first()
        rec = db.execute(select(Recommendation).where(Recommendation.rule_id == rule_id)).scalars().first()
        ctx = build_rule_context(db, rule, metric, rec, policy)
        rec_dict = {
            "category": rec.category,
            "risk_level": rec.risk_level,
            "confidence": rec.confidence,
            "triggers": json.loads(rec.triggers_json or "[]"),
            "missing": json.loads(rec.missing_json or "[]"),
            "approval_status": rec.approval_status,
            "reason": rec.reason,
            "business_impact": rec.business_impact,
            "technical_impact": rec.technical_impact,
            "next_action": rec.next_action,
        }
        narrative = reviewer.explain_rule({**ctx["rule"], "rule_uid": rule.rule_uid}, ctx["metric"], ctx["change"], rec_dict, model=model)
        rec.ai_json = json.dumps(narrative, default=str)
        rec.ai_generated = bool(narrative.get("generated"))
        rec.ai_validated = bool(narrative.get("validated"))
        rec.ai_model = narrative.get("model", "")
        db.commit()
    return narrative
