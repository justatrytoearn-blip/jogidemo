"""Compare two analysis runs: new/removed/changed rules, traffic and recommendation drift."""
from __future__ import annotations

import json

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.database.models import ChangeRecord, Comparison, Recommendation, Rule, RuleChangeLink, Run, TrafficMetric


def _key(rule: Rule) -> str:
    if rule.rule_uid:
        return f"uid:{rule.rule_uid.lower()}"
    return f"n:{rule.security_section.lower()}|{rule.rule_number}|{rule.rule_name.lower()}"


def _load(db: Session, run_id: int) -> dict[str, dict]:
    rules = db.execute(select(Rule).where(Rule.run_id == run_id)).scalars().all()
    recs = {r.rule_id: r for r in db.execute(select(Recommendation).where(Recommendation.run_id == run_id)).scalars()}
    metrics = {m.rule_id: m for m in db.execute(select(TrafficMetric).where(TrafficMetric.run_id == run_id)).scalars()}
    out = {}
    for rule in rules:
        rec = recs.get(rule.id)
        metric = metrics.get(rule.id)
        links = db.execute(
            select(ChangeRecord.ctask_number, ChangeRecord.chg_number)
            .join(RuleChangeLink, RuleChangeLink.change_record_id == ChangeRecord.id)
            .where(RuleChangeLink.rule_id == rule.id)
        ).all()
        out[_key(rule)] = {
            "rule": rule,
            "rec": rec,
            "metric": metric,
            "change_refs": sorted({f"{l.ctask_number}|{l.chg_number}" for l in links}),
        }
    return out


def compare_runs(db: Session, base_run_id: int, current_run_id: int) -> Comparison:
    base = _load(db, base_run_id)
    current = _load(db, current_run_id)
    new_keys = sorted(set(current) - set(base))
    removed_keys = sorted(set(base) - set(current))
    changed: list[dict] = []
    for key in sorted(set(base) & set(current)):
        b, c = base[key], current[key]
        rule_b, rule_c = b["rule"], c["rule"]
        deltas = {}
        for field in ("action", "source", "destination", "service", "rule_name", "comments", "hit_count"):
            before = getattr(rule_b, field)
            after = getattr(rule_c, field)
            if before != after:
                deltas[field] = {"before": str(before), "after": str(after)}
        traffic_delta = {}
        if b["metric"] and c["metric"]:
            if b["metric"].event_count != c["metric"].event_count:
                traffic_delta["event_count"] = {"before": b["metric"].event_count, "after": c["metric"].event_count}
            if b["metric"].window_event_count != c["metric"].window_event_count:
                traffic_delta["window_event_count"] = {
                    "before": b["metric"].window_event_count,
                    "after": c["metric"].window_event_count,
                }
        rec_before = b["rec"].category if b["rec"] else ""
        rec_after = c["rec"].category if c["rec"] else ""
        new_links = sorted(set(c["change_refs"]) - set(b["change_refs"]))
        if deltas or traffic_delta or rec_before != rec_after or new_links:
            changed.append(
                {
                    "rule_uid": rule_c.rule_uid,
                    "rule_number": rule_c.rule_number,
                    "rule_name": rule_c.rule_name,
                    "section": rule_c.security_section,
                    "field_changes": deltas,
                    "traffic_changes": traffic_delta,
                    "recommendation": {"before": rec_before, "after": rec_after},
                    "newly_linked_change_records": new_links,
                }
            )
    summary = {
        "base_run_id": base_run_id,
        "current_run_id": current_run_id,
        "base_rules": len(base),
        "current_rules": len(current),
        "new_rules": len(new_keys),
        "removed_rules": len(removed_keys),
        "changed_rules": len(changed),
        "recommendation_changes": sum(1 for c in changed if c["recommendation"]["before"] != c["recommendation"]["after"]),
        "traffic_changes": sum(1 for c in changed if c["traffic_changes"]),
        "newly_linked_changes": sum(1 for c in changed if c["newly_linked_change_records"]) + len(new_keys),
    }
    details = {
        "new": [
            {
                "rule_uid": current[k]["rule"].rule_uid,
                "rule_number": current[k]["rule"].rule_number,
                "rule_name": current[k]["rule"].rule_name,
                "section": current[k]["rule"].security_section,
            }
            for k in new_keys
        ],
        "removed": [
            {
                "rule_uid": base[k]["rule"].rule_uid,
                "rule_number": base[k]["rule"].rule_number,
                "rule_name": base[k]["rule"].rule_name,
                "section": base[k]["rule"].security_section,
            }
            for k in removed_keys
        ],
        "changed": changed,
    }
    existing = db.execute(
        select(Comparison).where(
            Comparison.base_run_id == base_run_id,
            Comparison.current_run_id == current_run_id,
        )
    ).scalars().first()
    comparison = existing or Comparison(base_run_id=base_run_id, current_run_id=current_run_id)
    comparison.summary_json = json.dumps(summary, default=str)
    comparison.details_json = json.dumps(details, default=str)
    if not existing:
        db.add(comparison)
    db.commit()
    db.refresh(comparison)
    return comparison


def comparison_payload(comparison: Comparison) -> dict:
    return {
        "id": comparison.id,
        "base_run_id": comparison.base_run_id,
        "current_run_id": comparison.current_run_id,
        "created_at": comparison.created_at.isoformat(),
        "summary": json.loads(comparison.summary_json or "{}"),
        "details": json.loads(comparison.details_json or "{}"),
    }
