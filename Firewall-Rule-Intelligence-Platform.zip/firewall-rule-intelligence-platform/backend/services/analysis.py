"""Bulk analysis orchestration and per-rule re-evaluation."""
from __future__ import annotations

import json
import logging
import re
import time
from collections import Counter
from datetime import datetime

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from backend.analytics.traffic import analyze_logs, empty_metric
from backend.config import Settings, load_policy
from backend.database.db import session_scope
from backend.database.models import (
    Approval,
    ChangeRecord,
    DisableEvidence,
    Recommendation,
    Rule,
    RuleChangeLink,
    Run,
    TrafficMetric,
    Upload,
    utcnow,
)
from backend.recommendation_engine import engine
from backend.recommendation_engine.policy import Policy
from backend.services import import_service
from backend.services.correlation import RuleRef, change_history_payload, link_changes

log = logging.getLogger("fip.analysis")
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")


def _json(value) -> str:
    return json.dumps(value, default=str, ensure_ascii=False)


def _load_run_inputs(db: Session, run: Run) -> tuple[list[dict], list[dict]]:
    if not run.rules_upload_id:
        raise ValueError("Run has no firewall rule upload")
    rules = import_service.load_processed(run.rules_upload_id, "rules")
    if not rules:
        raise ValueError("Rule inventory cache is empty - re-confirm the column mapping for the rules upload.")
    changes: list[dict] = []
    if run.changes_upload_id:
        changes.extend(import_service.load_processed(run.changes_upload_id, "changes"))
    changes.extend(import_service.load_processed(run.rules_upload_id, "change_links"))
    return rules, changes


def _owner_from_comments(comments: str) -> str:
    match = EMAIL_RE.search(comments or "")
    if match:
        return match.group(0)
    m = re.search(r"owner\s*[:=]\s*([\w .@-]{3,60})", comments or "", re.I)
    return m.group(1).strip() if m else ""


def _rule_payload(rule: dict) -> dict:
    payload = dict(rule)
    for key in ("first_hit", "last_hit"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            try:
                payload[key] = datetime.fromisoformat(value)
            except ValueError:
                payload[key] = None
    expiry = payload.get("expiry_date")
    if isinstance(expiry, str) and expiry:
        try:
            payload["expiry_date"] = datetime.fromisoformat(expiry + "T00:00:00")
        except ValueError:
            payload["expiry_date"] = None
    return payload


def create_run(
    db: Session,
    rules_upload_id: int,
    changes_upload_id: int | None,
    logs_upload_id: int | None,
    label: str,
    ai_enabled: bool,
    parent_run_id: int | None = None,
    actor: str = "local",
) -> Run:
    rules_upload = db.get(Upload, rules_upload_id)
    if not rules_upload or rules_upload.dataset_type != "rules":
        raise ValueError("A processed firewall rule inventory upload is required.")
    if rules_upload.status != "processed":
        raise ValueError("Firewall rule upload must have its column mapping confirmed before analysis.")
    synthetic_flags = [rules_upload.is_synthetic]
    for upload_id, expected in ((changes_upload_id, "changes"), (logs_upload_id, "logs")):
        if upload_id:
            upload = db.get(Upload, upload_id)
            if not upload or upload.dataset_type != expected:
                raise ValueError(f"Upload {upload_id} is not a {expected} dataset.")
            if upload.status not in {"processed", "mapped"}:
                raise ValueError(f"Upload {upload.original_filename} has not been mapped yet.")
            synthetic_flags.append(upload.is_synthetic)
    policy = Policy.from_dict(load_policy())
    run = Run(
        label=label or f"Analysis {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        status="queued",
        stage="queued",
        message="Waiting for the analysis worker",
        created_by=actor,
        is_synthetic=any(synthetic_flags),
        ai_enabled=ai_enabled,
        ai_model=Settings.OLLAMA_MODEL,
        policy_json=_json(policy.to_dict()),
        rules_upload_id=rules_upload_id,
        changes_upload_id=changes_upload_id,
        logs_upload_id=logs_upload_id,
        parent_run_id=parent_run_id,
    )
    db.add(run)
    db.commit()
    db.refresh(run)
    return run


def _set_stage(run_id: int, stage: str, progress: int, message: str) -> None:
    with session_scope() as db:
        run = db.get(Run, run_id)
        if run:
            run.stage = stage
            run.progress = progress
            run.message = message
            if run.status == "queued":
                run.status = "running"
                run.started_at = run.started_at or utcnow()
        db.commit()


def execute_run(run_id: int) -> dict:
    """Run the full deterministic pipeline. AI narration is a separate job."""
    started = time.time()
    with session_scope() as db:
        run = db.get(Run, run_id)
        if not run:
            raise ValueError("Run not found")
        if run.status == "running":
            raise ValueError("Run is already executing")
        run.status = "running"
        run.stage = "loading"
        run.progress = 2
        run.started_at = utcnow()
        run.message = "Loading normalised inputs"
        db.commit()
        policy = Policy.from_dict(json.loads(run.policy_json or "{}"))
        rules_upload_id = run.rules_upload_id
        changes_upload_id = run.changes_upload_id
        logs_upload_id = run.logs_upload_id
        is_synthetic = run.is_synthetic
        parent_run_id = run.parent_run_id
        changes_upload = db.get(Upload, changes_upload_id) if changes_upload_id else None
        logs_upload = db.get(Upload, logs_upload_id) if logs_upload_id else None
        rules_upload = db.get(Upload, rules_upload_id)
        log_mapping: dict = {}
        log_columns: list[str] = []
        log_sheet = None
        log_header_row = 0
        if logs_upload:
            stored_mapping = json.loads(logs_upload.mapping_json or "{}")
            log_mapping = {k: v for k, v in stored_mapping.get("mapping", {}).items() if v}
            detection = json.loads(logs_upload.detection_json or "{}")
            entry = next((s for s in detection.get("sheets", []) if s.get("sheet_name") == logs_upload.sheet_name), None)
            if entry:
                log_columns = entry.get("columns", [])
                log_header_row = entry.get("header_row", 0)
            log_sheet = logs_upload.sheet_name
        logs_path = logs_upload.stored_path if logs_upload else ""
        logs_kind = logs_upload.file_kind if logs_upload else "csv"

    try:
        _set_stage(run_id, "loading", 5, "Reading normalised rule and change records")
        raw_rules, raw_changes = None, None
        with session_scope() as db:
            run = db.get(Run, run_id)
            raw_rules, raw_changes = _load_run_inputs(db, run)
            # Reset any previous attempt for this run.
            for model in (Recommendation, TrafficMetric, RuleChangeLink, ChangeRecord, Rule, Approval, DisableEvidence):
                db.execute(delete(model).where(model.run_id == run_id))
            db.commit()

        _set_stage(run_id, "persisting_rules", 12, f"Storing {len(raw_rules)} firewall rules")
        rule_rows: list[dict] = []
        rule_refs: list[RuleRef] = []
        base_rule_id = 1
        with session_scope() as db:
            existing = db.execute(select(Rule.id).order_by(Rule.id.desc()).limit(1)).scalar() or 0
            base_rule_id = existing + 1
            for i, raw in enumerate(raw_rules):
                payload = _rule_payload(raw)
                source_row = payload.get("source_row")
                rule_rows.append(
                    {
                        "id": base_rule_id + i,
                        "run_id": run_id,
                        "rule_number": str(payload.get("rule_number") or ""),
                        "rule_name": str(payload.get("rule_name") or ""),
                        "rule_uid": str(payload.get("rule_uid") or ""),
                        "security_section": str(payload.get("security_section") or ""),
                        "device": str(payload.get("device") or ""),
                        "source": str(payload.get("source") or ""),
                        "destination": str(payload.get("destination") or ""),
                        "service": str(payload.get("service") or ""),
                        "action": str(payload.get("action") or ""),
                        "install_on": str(payload.get("install_on") or ""),
                        "comments": str(payload.get("comments") or ""),
                        "vpn": str(payload.get("vpn") or ""),
                        "track": str(payload.get("track") or ""),
                        "hit_count": payload.get("hit_count"),
                        "hits_raw": str(payload.get("hits_raw") or ""),
                        "first_hit": payload.get("first_hit"),
                        "last_hit": payload.get("last_hit"),
                        "expiry_date": payload.get("expiry_date").date() if payload.get("expiry_date") else None,
                        "owner_hint": str(payload.get("owner_hint") or "") or _owner_from_comments(str(payload.get("comments") or "")),
                        "raw_json": payload.get("raw_json") or "{}",
                        "source_file": str(payload.get("source_file") or ""),
                        "source_sheet": str(payload.get("source_sheet") or ""),
                        "source_row": int(source_row) if source_row is not None else None,
                    }
                )
                rule_refs.append(
                    RuleRef(
                        index=i,
                        rule_uid=str(payload.get("rule_uid") or ""),
                        rule_number=str(payload.get("rule_number") or ""),
                        rule_name=str(payload.get("rule_name") or ""),
                        device=str(payload.get("device") or ""),
                        section=str(payload.get("security_section") or ""),
                        comments=str(payload.get("comments") or ""),
                    )
                )
            for chunk in _chunks(rule_rows, 5000):
                db.bulk_insert_mappings(Rule, chunk)
            db.commit()

        _set_stage(run_id, "correlating_changes", 24, f"Correlating {len(raw_changes)} change records")
        links, change_summaries, change_stats = link_changes(rule_refs, raw_changes)
        change_rows: list[dict] = []
        base_change_id = 1
        with session_scope() as db:
            existing = db.execute(select(ChangeRecord.id).order_by(ChangeRecord.id.desc()).limit(1)).scalar() or 0
            base_change_id = existing + 1
            for i, rec in enumerate(raw_changes):
                planned = rec.get("planned_end_date")
                if isinstance(planned, str) and planned:
                    try:
                        planned = datetime.fromisoformat(planned)
                    except ValueError:
                        planned = None
                change_rows.append(
                    {
                        "id": base_change_id + i,
                        "run_id": run_id,
                        "upload_id": changes_upload_id,
                        "source_kind": rec.get("source_kind") or "change_task",
                        "ctask_number": str(rec.get("ctask_number") or ""),
                        "chg_number": str(rec.get("chg_number") or ""),
                        "state": str(rec.get("state") or ""),
                        "assigned_to": str(rec.get("assigned_to") or ""),
                        "short_description": str(rec.get("short_description") or ""),
                        "planned_end_date": planned,
                        "rule_number": str(rec.get("rule_number") or ""),
                        "rule_uid": str(rec.get("rule_uid") or ""),
                        "rule_name": str(rec.get("rule_name") or ""),
                        "raw_json": rec.get("raw_json") or "{}",
                        "source_file": str(rec.get("source_file") or ""),
                        "source_sheet": str(rec.get("source_sheet") or ""),
                        "source_row": rec.get("source_row"),
                    }
                )
            for chunk in _chunks(change_rows, 5000):
                db.bulk_insert_mappings(ChangeRecord, chunk)
            link_rows = [
                {
                    "run_id": run_id,
                    "rule_id": base_rule_id + link.rule_index,
                    "change_record_id": base_change_id + link.change_index,
                    "match_method": link.method,
                    "confidence": link.confidence,
                    "evidence": link.evidence,
                }
                for link in links
            ]
            for chunk in _chunks(link_rows, 5000):
                db.bulk_insert_mappings(RuleChangeLink, chunk)
            db.commit()

        # ---- traffic ----
        traffic_metrics: dict[int, dict] = {}
        traffic_summary: dict = {"note": "No firewall log dataset was supplied for this run."}
        if logs_upload_id and logs_path:
            _set_stage(run_id, "traffic_analysis", 40, "Streaming firewall logs and aggregating per-rule traffic")
            traffic_metrics, traffic_summary = analyze_logs(
                rule_refs,
                logs_path,
                logs_kind,
                log_sheet,
                log_header_row,
                log_columns,
                log_mapping,
                policy.to_dict(),
                progress_cb=lambda rows: _set_stage(
                    run_id, "traffic_analysis", min(70, 40 + int(rows / 100_000)), f"{rows:,} log rows processed"
                ),
            )
            traffic_summary["is_synthetic"] = is_synthetic
        else:
            traffic_metrics = {ref.index: empty_metric("No log dataset supplied") for ref in rule_refs}

        _set_stage(run_id, "traffic_metrics", 72, "Storing traffic metrics")
        metric_rows: list[dict] = []
        for i, ref in enumerate(rule_refs):
            metric = traffic_metrics.get(ref.index) or empty_metric()
            metric_rows.append(
                {
                    "run_id": run_id,
                    "rule_id": base_rule_id + i,
                    "matched": bool(metric.get("matched")),
                    "logs_supplied": bool(metric.get("logs_supplied")),
                    "absence_is_evidence": bool(metric.get("absence_is_evidence")),
                    "match_method": metric.get("match_method", "none"),
                    "match_confidence": float(metric.get("match_confidence") or 0),
                    "event_count": int(metric.get("event_count") or 0),
                    "window_event_count": int(metric.get("window_event_count") or 0),
                    "first_seen": metric.get("first_seen"),
                    "last_seen": metric.get("last_seen"),
                    "days_since_last_hit": metric.get("days_since_last_hit"),
                    "observation_days": int(metric.get("observation_days") or 0),
                    "log_coverage_days": int(metric.get("log_coverage_days") or 0),
                    "active_days": int(metric.get("active_days") or 0),
                    "avg_per_day": float(metric.get("avg_per_day") or 0),
                    "avg_per_week": float(metric.get("avg_per_week") or 0),
                    "avg_per_month": float(metric.get("avg_per_month") or 0),
                    "avg_per_hour": float(metric.get("avg_per_hour") or 0),
                    "distinct_sources": int(metric.get("distinct_sources") or 0),
                    "distinct_destinations": int(metric.get("distinct_destinations") or 0),
                    "bytes_total": metric.get("bytes_total"),
                    "packets_total": metric.get("packets_total"),
                    "protocols_json": _json(metric.get("protocols") or []),
                    "top_sources_json": _json(metric.get("top_sources") or []),
                    "top_destinations_json": _json(metric.get("top_destinations") or []),
                    "daily_json": _json(metric.get("daily") or []),
                    "hourly_json": _json(metric.get("hourly") or []),
                    "trend": metric.get("trend", "unknown"),
                    "notes": metric.get("notes", ""),
                }
            )
        with session_scope() as db:
            for chunk in _chunks(metric_rows, 5000):
                db.bulk_insert_mappings(TrafficMetric, chunk)
            db.commit()

        # ---- recommendations ----
        _set_stage(run_id, "recommendations", 84, "Applying deterministic recommendation policy")
        rec_rows: list[dict] = []
        for i, raw in enumerate(raw_rules):
            payload = _rule_payload(raw)
            metric = traffic_metrics.get(i) or empty_metric()
            summary = change_summaries.get(i)
            change_dict = {
                "records": change_history_payload(summary),
                "record_count": len(summary.records) if summary else 0,
                "documented": bool(summary.documented) if summary else False,
                "owner": (summary.owner if summary else "") or payload.get("owner_hint") or "",
                "change_status": summary.change_status if summary else "",
                "change_request": summary.change_request if summary else "",
                "change_task": summary.change_task if summary else "",
                "conflicting": bool(summary.conflicting) if summary else False,
                "notes": summary.notes if summary else [],
            }
            result = engine.evaluate(payload, metric, change_dict, policy)
            rec_rows.append(
                {
                    "run_id": run_id,
                    "rule_id": base_rule_id + i,
                    "category": result["category"],
                    "risk_level": result["risk_level"],
                    "confidence": result["confidence"],
                    "engine_version": Settings.ENGINE_VERSION,
                    "triggers_json": _json(result["triggers"]),
                    "evidence_json": _json(result["evidence"]),
                    "missing_json": _json(result["missing"]),
                    "approval_status": result["approval_status"],
                    "reason": result["reason"],
                    "next_action": result["next_action"],
                    "business_impact": result["business_impact"],
                    "technical_impact": result["technical_impact"],
                    "ai_json": "{}",
                    "ai_generated": False,
                    "ai_validated": False,
                    "ai_model": "",
                    "analyzed_at": utcnow(),
                    "owner": result["owner"],
                    "change_status": result["change_status"],
                    "change_request": result["change_request"],
                    "change_task": result["change_task"],
                    "expiry_status": result["expiry_status"],
                    "_eligible_for": result.get("eligible_for") or "",
                }
            )
        for row in rec_rows:
            row.pop("_eligible_for", None)
        with session_scope() as db:
            for chunk in _chunks(rec_rows, 5000):
                db.bulk_insert_mappings(Recommendation, chunk)
            db.commit()

        counts = {c: 0 for c in ("KEEP", "REVIEW", "DISABLE", "DELETE")}
        for row in rec_rows:
            counts[row["category"]] = counts.get(row["category"], 0) + 1

        daily_totals: Counter = Counter()
        for metric in traffic_metrics.values():
            for item in metric.get("daily") or []:
                try:
                    daily_totals[str(item["date"])] += int(item.get("count", 0))
                except (KeyError, TypeError, ValueError):
                    continue
        duration = round(time.time() - started, 2)
        stats = {
            "total_rules": len(rule_rows),
            "keep": counts["KEEP"],
            "review": counts["REVIEW"],
            "disable": counts["DISABLE"],
            "delete": counts["DELETE"],
            "rules_with_change_records": change_stats["rules_with_changes"],
            "rules_without_change_records": change_stats["rules_without_changes"],
            "without_owner": sum(1 for r in rec_rows if not r["owner"]),
            "without_traffic_evidence": sum(1 for r in rec_rows if not json.loads(r["evidence_json"])["traffic"]["matched"]),
            "with_zero_traffic": sum(
                1
                for r in rec_rows
                if json.loads(r["evidence_json"])["traffic"]["matched"]
                and int(json.loads(r["evidence_json"])["traffic"]["window_event_count"] or 0) == 0
            ),
            "matched_rules": traffic_summary.get("rules_with_log_events", 0),
            "unmatched_rules": traffic_summary.get("rules_without_log_events", len(rule_rows)),
            "change_stats": change_stats,
            "traffic": traffic_summary,
            "traffic_daily": [{"date": d, "count": c} for d, c in sorted(daily_totals.items())],
            "processing_seconds": duration,
            "analysis_completed": True,
            "ai_status": "pending" if run_ai_enabled(run_id) else "disabled",
            "is_synthetic": is_synthetic,
            "policy": policy.to_dict(),
            "generated_at": utcnow().isoformat(),
            "source_files": {
                "rules": rules_upload.original_filename if rules_upload else "",
                "changes": changes_upload.original_filename if changes_upload else None,
                "logs": logs_upload.original_filename if logs_upload else None,
            },
        }
        with session_scope() as db:
            run = db.get(Run, run_id)
            run.status = "completed"
            run.stage = "completed"
            run.progress = 100
            run.message = "Analysis complete. AI narration runs separately when enabled."
            run.stats_json = _json(stats)
            run.finished_at = utcnow()
            db.commit()

        if parent_run_id:
            from backend.services.comparison import compare_runs

            with session_scope() as db:
                compare_runs(db, parent_run_id, run_id)

        return stats
    except Exception as exc:  # noqa: BLE001
        log.exception("Analysis run %s failed", run_id)
        with session_scope() as db:
            run = db.get(Run, run_id)
            if run:
                run.status = "failed"
                run.stage = "failed"
                run.message = "Analysis failed"
                run.error = str(exc)[:4000]
                run.finished_at = utcnow()
            db.commit()
        raise


def run_ai_enabled(run_id: int) -> bool:
    with session_scope() as db:
        run = db.get(Run, run_id)
        return bool(run and run.ai_enabled)


def _chunks(seq: list, size: int):
    for i in range(0, len(seq), size):
        yield seq[i: i + size]


# ---------------------------------------------------------------------------
# On-demand re-evaluation (approvals, disable evidence, selected review)
# ---------------------------------------------------------------------------

def build_rule_context(db: Session, rule: Rule, metric: TrafficMetric | None, rec: Recommendation | None, policy: Policy) -> dict:
    rule_dict = {
        "rule_number": rule.rule_number,
        "rule_name": rule.rule_name,
        "rule_uid": rule.rule_uid,
        "security_section": rule.security_section,
        "action": rule.action,
        "source": rule.source,
        "destination": rule.destination,
        "service": rule.service,
        "comments": rule.comments,
        "hit_count": rule.hit_count,
        "hits_raw": rule.hits_raw,
        "first_hit": rule.first_hit,
        "last_hit": rule.last_hit,
        "expiry_date": rule.expiry_date,
        "owner_hint": rule.owner_hint,
    }
    if metric:
        metric_dict = {
            "matched": metric.matched,
            "logs_supplied": metric.logs_supplied,
            "absence_is_evidence": metric.absence_is_evidence,
            "match_method": metric.match_method,
            "match_confidence": metric.match_confidence,
            "event_count": metric.event_count,
            "window_event_count": metric.window_event_count,
            "first_seen": metric.first_seen,
            "last_seen": metric.last_seen,
            "days_since_last_hit": metric.days_since_last_hit,
            "observation_days": metric.observation_days,
            "log_coverage_days": metric.log_coverage_days,
            "active_days": metric.active_days,
            "avg_per_day": metric.avg_per_day,
            "avg_per_week": metric.avg_per_week,
            "avg_per_month": metric.avg_per_month,
            "avg_per_hour": metric.avg_per_hour,
            "distinct_sources": metric.distinct_sources,
            "distinct_destinations": metric.distinct_destinations,
            "bytes_total": metric.bytes_total,
            "protocols": json.loads(metric.protocols_json or "[]"),
            "trend": metric.trend,
            "notes": metric.notes,
        }
    else:
        metric_dict = empty_metric("No traffic metrics for this rule")

    change_records = db.execute(
        select(ChangeRecord)
        .join(RuleChangeLink, RuleChangeLink.change_record_id == ChangeRecord.id)
        .where(RuleChangeLink.rule_id == rule.id)
    ).scalars().all()
    records = []
    owners, states, chgs, ctasks = set(), set(), set(), set()
    documented = False
    for rec_row in change_records:
        records.append(
            {
                "ctask_number": rec_row.ctask_number,
                "chg_number": rec_row.chg_number,
                "state": rec_row.state,
                "assigned_to": rec_row.assigned_to,
                "short_description": rec_row.short_description,
                "planned_end_date": rec_row.planned_end_date.isoformat() if rec_row.planned_end_date else "",
                "source_kind": rec_row.source_kind,
                "source_file": rec_row.source_file,
                "source_sheet": rec_row.source_sheet,
                "source_row": rec_row.source_row,
            }
        )
        if rec_row.assigned_to:
            owners.add(rec_row.assigned_to)
        if rec_row.state:
            states.add(rec_row.state)
        if rec_row.chg_number:
            chgs.add(rec_row.chg_number)
        if rec_row.ctask_number:
            ctasks.add(rec_row.ctask_number)
        if rec_row.state and rec_row.short_description:
            documented = True
    notes = []
    conflicting = len(owners) > 1 or len(states) > 1
    if len(owners) > 1:
        notes.append("Multiple assigned owners across linked change records")
    if len(states) > 1:
        notes.append("Conflicting change task states")
    change_dict = {
        "records": records,
        "record_count": len(records),
        "documented": documented,
        "owner": (sorted(owners)[0] if owners else "") or rule.owner_hint or "",
        "change_status": (next(iter(states)) if len(states) == 1 else ("Multiple" if states else "")),
        "change_request": (sorted(chgs)[0] if chgs else ""),
        "change_task": (sorted(ctasks)[0] if ctasks else ""),
        "conflicting": conflicting,
        "notes": notes,
    }
    approvals = {
        a.kind
        for a in db.execute(select(Approval).where(Approval.run_id == rule.run_id, Approval.rule_id == rule.id)).scalars()
    }
    evidence = db.execute(
        select(DisableEvidence).where(DisableEvidence.run_id == rule.run_id, DisableEvidence.rule_id == rule.id)
    ).scalars().first()
    evidence_dict = (
        {
            "disabled_at": evidence.disabled_at,
            "monitored_until": evidence.monitored_until,
            "change_reference": evidence.change_reference,
            "note": evidence.note,
        }
        if evidence
        else None
    )
    return {
        "rule": rule_dict,
        "metric": metric_dict,
        "change": change_dict,
        "approvals": approvals,
        "disable_evidence": evidence_dict,
        "policy": policy,
        "records": records,
    }


def reevaluate_rule(db: Session, rule_id: int, policy: Policy | None = None) -> Recommendation:
    rule = db.get(Rule, rule_id)
    if not rule:
        raise ValueError("Rule not found")
    with session_scope() as pdb:
        run = pdb.get(Run, rule.run_id)
        policy = policy or Policy.from_dict(json.loads(run.policy_json or "{}"))
    metric = db.execute(select(TrafficMetric).where(TrafficMetric.rule_id == rule_id)).scalars().first()
    rec = db.execute(select(Recommendation).where(Recommendation.rule_id == rule_id)).scalars().first()
    ctx = build_rule_context(db, rule, metric, rec, policy)
    result = engine.evaluate(ctx["rule"], ctx["metric"], ctx["change"], policy, ctx["approvals"], ctx["disable_evidence"])
    if not rec:
        rec = Recommendation(run_id=rule.run_id, rule_id=rule.id)
        db.add(rec)
    rec.category = result["category"]
    rec.risk_level = result["risk_level"]
    rec.confidence = result["confidence"]
    rec.triggers_json = _json(result["triggers"])
    rec.evidence_json = _json(result["evidence"])
    rec.missing_json = _json(result["missing"])
    rec.approval_status = result["approval_status"]
    rec.reason = result["reason"]
    rec.next_action = result["next_action"]
    rec.business_impact = result["business_impact"]
    rec.technical_impact = result["technical_impact"]
    rec.owner = result["owner"]
    rec.change_status = result["change_status"]
    rec.change_request = result["change_request"]
    rec.change_task = result["change_task"]
    rec.expiry_status = result["expiry_status"]
    rec.analyzed_at = utcnow()
    rec.ai_json = "{}"
    rec.ai_generated = False
    rec.ai_validated = False
    db.commit()
    db.refresh(rec)
    return rec
