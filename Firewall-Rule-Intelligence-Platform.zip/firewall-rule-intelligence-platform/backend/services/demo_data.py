"""Self-contained customer demonstration dataset.

The demo keeps the same workbook / CSV headers as the POC files but every value is
fictional. It is generated on demand so an installed copy always has demo files,
and it deliberately covers every recommendation path:

* KEEP with recent traffic, a documented change and a known owner
* REVIEW because the change record is missing
* REVIEW because the owner is missing
* REVIEW because the rule has no matching log evidence
* REVIEW (eligible for DISABLE) because business confirmation is missing
* REVIEW (eligible for DELETE) because deletion approval is missing
* DISABLE after recorded business confirmation
* DELETE after disable + monitoring evidence and deletion approval

Nothing here is customer data. Runs created from these files are flagged synthetic.
"""
from __future__ import annotations

import csv
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.config import PROJECT_ROOT
from backend.database.db import session_scope
from backend.database.models import Approval, DisableEvidence, Recommendation, Rule, Run, TrafficMetric

DEMO_DIR = PROJECT_ROOT / "samples" / "demo"
RULES_FILE = DEMO_DIR / "Firewall_Rule_Inventory_DEMO.xlsx"
CHANGES_FILE = DEMO_DIR / "ServiceNow_Change_Tasks_DEMO.xlsx"
LOGS_FILE = DEMO_DIR / "Firewall_Logs_DEMO.csv"
MANIFEST_FILE = DEMO_DIR / "DEMO_MANIFEST.json"

RULE_HEADERS = [
    "Rule Number", "Type", "Hits", "First Hits", "Last Hits", "Name", "Source",
    "Destination", "VPN", "Comments", "Services & Action", "Action", "Track",
    "Install On", "Uid",
]
RELATIONSHIP_SHEET = "Rule_Change_Relationship"
RELATIONSHIP_HEADERS = [
    "Rule Number", "Security Section", "Rule Name", "Primary Change Request",
    "Linked CTASK Number", "Change Task Description", "Rule Comments Field",
    "Action", "Rule UID",
]
CHANGE_HEADERS = ["Number", "State", "Assigned to", "Short description", "Planned end date", "Change request"]
LOG_HEADERS = [
    "Time", "Blade", "Action", "Type", "Interface", "Origin", "Source", "Source User",
    "Destination", "Service", "Rule", "Access Rule Name", "Description",
]

SECTIONS = ["Demo DMZ", "Demo Internal", "Demo Cloud", "Demo Legacy"]
OWNERS = [
    "anita.rao@demo.example", "marcus.lee@demo.example", "priya.nair@demo.example",
    "tom.becker@demo.example", "sara.oconnor@demo.example",
]
SERVICES = [("tcp_443", "HTTPS"), ("tcp_80", "HTTP"), ("tcp_8080", "APP"), ("udp_53", "DNS"), ("tcp_22", "SSH")]

# scenario -> (count, activity, documented, owner, expected)
SCENARIOS = [
    ("keep_active", 16, "active", True, True, "KEEP"),
    ("review_no_change", 8, "active", False, True, "REVIEW"),
    ("review_no_owner", 6, "dormant", True, False, "REVIEW"),
    ("review_disable_pending", 4, "dormant", True, True, "REVIEW (eligible DISABLE)"),
    ("review_delete_pending", 4, "dormant", True, True, "REVIEW (eligible DELETE)"),
    ("review_no_log_evidence", 4, "silent", True, True, "REVIEW"),
    ("review_active_no_owner", 4, "active", True, False, "REVIEW"),
    ("disable_approved", 6, "dormant", True, True, "DISABLE"),
    ("delete_approved", 4, "dormant", True, True, "DELETE"),
    ("keep_name_match", 2, "name_only", True, True, "KEEP"),
    ("keep_drop_rule", 1, "active", True, True, "KEEP"),
    ("review_drop_no_owner", 1, "dormant", False, False, "REVIEW"),
]


def _rule_name(number: int) -> str:
    nouns = [
        "Payment Gateway", "Build Agent", "SIEM Collector", "ERP Batch", "Vendor SFTP",
        "Monitoring Probe", "Backup Replication", "Identity Provider", "Service Desk",
        "Data Warehouse", "Container Registry", "Mail Relay", "Proxy Egress", "Jump Host",
        "Certificate Authority", "Telemetry Ingest",
    ]
    return f"DEMO {nouns[number % len(nouns)]} {number}"


def _build_specs() -> list[dict]:
    specs: list[dict] = []
    number = 1001
    for idx, (scenario, count, activity, documented, owner, expected) in enumerate(SCENARIOS):
        for i in range(count):
            specs.append(
                {
                    "number": number,
                    "section": SECTIONS[idx % len(SECTIONS)],
                    "scenario": scenario,
                    "activity": activity,
                    "documented": documented,
                    "owner": owner,
                    "expected": expected,
                    "name": _rule_name(number),
                }
            )
            number += 1
    return specs


def _timestamp(days_ago: int, rng: random.Random) -> str:
    moment = datetime.now().replace(microsecond=0) - timedelta(
        days=days_ago, hours=rng.randint(0, 23), minutes=rng.randint(0, 59)
    )
    return moment.strftime("%Y-%m-%d %H:%M:%S")


def _write_workbooks(specs: list[dict]) -> None:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "FW-Corp 11"
    ws.append(RULE_HEADERS)
    # Section headings are part of the customer's real layout and must be skipped.
    for section in SECTIONS:
        ws.append([None, "Section", section, None, None, None, None, None, None, None, None, None, None, None, None])
    for spec in specs:
        owner_note = f"OWNER: {OWNERS[spec['number'] % len(OWNERS)]}" if spec["owner"] else "owner not recorded"
        ws.append(
            [
                spec["number"],
                "Rule",
                "Zero",
                None,
                None,
                spec["name"],
                f"DEMO_SRC_{spec['number']}",
                f"DEMO_DST_{(spec['number'] % 9) + 1}",
                "Any",
                f"DEMO-{spec['number']:04d} {owner_note}",
                "tcp_443;Accept" if spec["number"] % 2 else "tcp_80;Accept",
                "Drop" if spec["number"] % 17 == 0 else "Accept",
                "Log",
                "Demo-Policy-Targets",
                f"00000000-0000-4000-8000-{spec['number']:012d}",
            ]
        )

    rel = wb.create_sheet(RELATIONSHIP_SHEET)
    rel.append(RELATIONSHIP_HEADERS)
    for spec in specs:
        if not spec["documented"]:
            continue
        task = 7000000 + spec["number"]
        rel.append(
            [
                spec["number"],
                spec["section"],
                spec["name"],
                f"CHG_DEMO{spec['number']}",
                f"CTASK{task}",
                "Demo change task - firewall rule review",
                f"DEMO-{spec['number']:04d}",
                "Accept",
                f"00000000-0000-4000-8000-{spec['number']:012d}",
            ]
        )
    summary = wb.create_sheet("Rule_Summary_Metrics")
    summary.append(["Security Section", "Rule Count", "Accept Rules", "Drop Rules"])
    for section in SECTIONS:
        section_specs = [s for s in specs if s["section"] == section]
        summary.append(
            [
                section,
                len(section_specs),
                sum(1 for s in section_specs if s["number"] % 17 != 0),
                sum(1 for s in section_specs if s["number"] % 17 == 0),
            ]
        )
    wb.save(RULES_FILE)

    wb = Workbook()
    ws = wb.active
    ws.title = "Page 1"
    ws.append(CHANGE_HEADERS)
    for spec in specs:
        if not spec["documented"]:
            continue
        task = 7000000 + spec["number"]
        ws.append(
            [
                f"CTASK{task}",
                "Closed" if spec["number"] % 4 else "Open",
                OWNERS[spec["number"] % len(OWNERS)],
                "Demo change task - firewall rule review",
                (datetime.now() - timedelta(days=spec["number"] % 45)).strftime("%d-%m-%Y %H:%M:%S"),
                f"CHG_DEMO{spec['number']}",
            ]
        )
    dash = wb.create_sheet("Summary_Dashboard")
    dash.append(["Assignee Name", "Total Tasks", "Closed", "In Progress", "Open", "Completion Rate"])
    for owner in OWNERS:
        dash.append([owner.split("@")[0], 12, 7, 3, 2, "58%"])
    wb.save(CHANGES_FILE)


def _write_logs(specs: list[dict]) -> None:
    rng = random.Random(42)
    rows: list[dict] = []
    for spec in specs:
        if spec["activity"] == "silent":
            continue
        if spec["activity"] == "dormant":
            days = [rng.randint(200, 330) for _ in range(rng.randint(25, 70))]
        else:
            days = [rng.randint(1, 45) for _ in range(rng.randint(35, 120))]
        if spec["activity"] in {"active", "name_only"}:
            days.append(rng.randint(1, 4))
        for day in days:
            svc, label = SERVICES[rng.randrange(len(SERVICES))]
            rows.append(
                {
                    "Time": _timestamp(day, rng),
                    "Blade": "fw-demo-01",
                    "Action": "Drop" if spec["number"] % 17 == 0 else "Accept",
                    "Type": "Connection",
                    "Interface": "eth0",
                    "Origin": "demo-edge",
                    "Source": f"10.10.{rng.randint(1, 40)}.{rng.randint(1, 250)}",
                    "Source User": "demo_user",
                    "Destination": f"192.0.2.{rng.randint(1, 200)}",
                    "Service": svc,
                    "Rule": "" if spec["activity"] == "name_only" else str(spec["number"]),
                    "Access Rule Name": spec["name"],
                    "Description": f"DEMO {label} traffic",
                }
            )
    rows.sort(key=lambda r: r["Time"])
    with LOGS_FILE.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=LOG_HEADERS)
        writer.writeheader()
        writer.writerows(rows)


def ensure_demo_files(force: bool = False) -> dict[str, str]:
    """Generate the demo files if they are absent. Returns their paths."""
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    specs = _build_specs()
    if force or not RULES_FILE.exists():
        _write_workbooks(specs)
    if force or not LOGS_FILE.exists():
        _write_logs(specs)
    manifest = {
        "synthetic": True,
        "warning": "FICTIONAL DEMONSTRATION DATA - not customer traffic or customer change records.",
        "generated_at": datetime.now().isoformat(),
        "rules": len(specs),
        "scenarios": [
            {"scenario": name, "count": count, "activity": activity, "documented": documented,
             "owner": owner, "expected": expected}
            for name, count, activity, documented, owner, expected in SCENARIOS
        ],
        "files": {"rules": RULES_FILE.name, "changes": CHANGES_FILE.name, "logs": LOGS_FILE.name},
    }
    MANIFEST_FILE.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {
        "rules": str(RULES_FILE),
        "changes": str(CHANGES_FILE),
        "logs": str(LOGS_FILE),
        "manifest": str(MANIFEST_FILE),
    }


def apply_demo_fixtures(db: Session, run_id: int) -> dict:
    """Record the demonstration approvals/evidence that complete the four categories.

    They are clearly labelled as synthetic fixtures, applied only to a demo run, and
    only to rules whose evidence genuinely qualifies (dormant traffic, documented
    change, known owner). No category is forced by code.
    """
    rules = {
        r.rule_number: r
        for r in db.execute(select(Rule).where(Rule.run_id == run_id)).scalars().all()
    }
    now = datetime.now()
    disable_numbers = [f"10{n}" for n in range(47, 53)]
    delete_numbers = [f"10{n}" for n in range(53, 57)]
    applied = {"business_confirmation": 0, "delete_approval": 0, "obsolescence_confirmation": 0, "disable_evidence": 0}

    def has(rule_id: int, kind: str) -> bool:
        return bool(
            db.execute(
                select(Approval).where(Approval.rule_id == rule_id, Approval.kind == kind)
            ).scalars().first()
        )

    for number in disable_numbers:
        rule = rules.get(number)
        if not rule or has(rule.id, "business_confirmation"):
            continue
        db.add(
            Approval(
                run_id=run_id, rule_id=rule.id, kind="business_confirmation",
                approved_by="demo.owner@example.com",
                note="DEMO fixture: business owner confirms this fictional rule is no longer required.",
                source="demo_fixture",
            )
        )
        applied["business_confirmation"] += 1

    for number in delete_numbers:
        rule = rules.get(number)
        if not rule:
            continue
        if not has(rule.id, "delete_approval"):
            db.add(
                Approval(
                    run_id=run_id, rule_id=rule.id, kind="delete_approval",
                    approved_by="demo.owner@example.com",
                    note="DEMO fixture: deletion approved for this fictional rule.",
                    source="demo_fixture",
                )
            )
            applied["delete_approval"] += 1
        if not has(rule.id, "obsolescence_confirmation"):
            db.add(
                Approval(
                    run_id=run_id, rule_id=rule.id, kind="obsolescence_confirmation",
                    approved_by="demo.owner@example.com",
                    note="DEMO fixture: fictional rule confirmed obsolete.",
                    source="demo_fixture",
                )
            )
            applied["obsolescence_confirmation"] += 1
        existing = db.execute(select(DisableEvidence).where(DisableEvidence.rule_id == rule.id)).scalars().first()
        if not existing:
            db.add(
                DisableEvidence(
                    run_id=run_id, rule_id=rule.id,
                    disabled_at=now - timedelta(days=75),
                    monitored_until=now - timedelta(days=10),
                    change_reference=f"CHG_DEMO_DISABLE_{number}",
                    note="DEMO fixture: rule disabled outside the platform and monitored for 65 days.",
                    source="demo_fixture",
                )
            )
            applied["disable_evidence"] += 1
    db.commit()

    from backend.services.analysis import reevaluate_rule

    touched = [rules[n].id for n in disable_numbers + delete_numbers if n in rules]
    for rule_id in touched:
        reevaluate_rule(db, rule_id)

    counts: dict[str, int] = {}
    for (category,) in db.execute(
        select(Recommendation.category).where(Recommendation.run_id == run_id)
    ).all():
        counts[category] = counts.get(category, 0) + 1

    with session_scope() as sdb:
        run = sdb.get(Run, run_id)
        stats = json.loads(run.stats_json or "{}")
        stats.update(
            {
                "keep": counts.get("KEEP", 0),
                "review": counts.get("REVIEW", 0),
                "disable": counts.get("DISABLE", 0),
                "delete": counts.get("DELETE", 0),
                "demo_fixtures": applied,
                "demo_note": (
                    "DEMO run. Approvals and disable evidence were recorded as fictional fixtures so all four "
                    "recommendations can be demonstrated. They are not customer decisions."
                ),
            }
        )
        run.stats_json = json.dumps(stats, default=str)
        sdb.commit()
    return {"applied": applied, "counts": counts}
