"""Normalisation: turn arbitrary source columns into typed canonical records."""
from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta

import pandas as pd

ACCEPT_TOKENS = {"accept", "allow", "allowed", "permit", "permitted", "pass"}
DROP_TOKENS = {"drop", "deny", "denied", "block", "blocked", "reject", "rejected", "discard", "reset"}
HITS_NUMBER_RE = re.compile(r"number of hits\s*[:=]\s*([\d,]+)", re.IGNORECASE)
HITS_NUM_RE = re.compile(r"\bnum(?:ber)?\s*[:=]\s*([\d,]+)", re.IGNORECASE)
CHG_RE = re.compile(r"\bCHG[_-]?[A-Z0-9]{4,}\b", re.IGNORECASE)
CTASK_RE = re.compile(r"\bCTASK\d{4,}\b", re.IGNORECASE)
EMPTY_TOKENS = {"", "nan", "none", "null", "n/a", "na", "-", "--"}


def clean_text(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    text = str(value).strip()
    if text.lower() in EMPTY_TOKENS:
        return ""
    return re.sub(r"\s+", " ", text)


def parse_int(value) -> int | None:
    """Parse hit counters such as 'Zero', 'Low (number of hits: 3521)' or '1,234'."""
    if value is None:
        return None
    if isinstance(value, (int,)) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, float):
        if pd.isna(value):
            return None
        return int(value)
    text = str(value).strip()
    if not text:
        return None
    low = text.lower()
    if low in {"zero", "none", "no hits", "n/a", "na"}:
        return 0
    for rx in (HITS_NUMBER_RE, HITS_NUM_RE):
        m = rx.search(text)
        if m:
            try:
                return int(m.group(1).replace(",", ""))
            except ValueError:
                return None
    digits = re.sub(r"[^\d\-]", "", text)
    if digits and re.fullmatch(r"-?\d+", digits):
        return int(digits)
    return None


def parse_datetime(value) -> datetime | None:
    """Parse ISO, day-first and Excel-serial dates into a naive datetime."""
    if value is None:
        return None
    if isinstance(value, pd.Timestamp):
        return None if pd.isna(value) else value.to_pydatetime()
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if 20000 <= float(value) <= 80000:  # Excel serial date
            try:
                return (datetime(1899, 12, 30) + timedelta(days=float(value))).replace(microsecond=0)
            except (ValueError, OverflowError):
                return None
        return None
    text = str(value).strip()
    if not text or text.lower() in EMPTY_TOKENS:
        return None
    # ISO first (unambiguous), then day-first for dd/mm/yyyy and dd-mm-yyyy.
    try:
        ts = pd.to_datetime(text, format="ISO8601", errors="coerce")
        if pd.notna(ts):
            return ts.to_pydatetime()
    except (ValueError, TypeError):
        pass
    for dayfirst in (True, False):
        try:
            ts = pd.to_datetime(text, dayfirst=dayfirst, errors="coerce")
            if pd.notna(ts):
                return ts.to_pydatetime()
        except (ValueError, TypeError, OverflowError):
            continue
    return None


def parse_date(value) -> date | None:
    dt = parse_datetime(value)
    return dt.date() if dt else None


def normalize_action(value) -> str:
    text = clean_text(value)
    if not text:
        return ""
    tokens = re.split(r"[;,\s]+", text.lower())
    for token in tokens:
        if token in ACCEPT_TOKENS:
            return "Accept"
        if token in DROP_TOKENS:
            return "Drop"
    return text


def split_service_action(service_text: str) -> tuple[str, str]:
    """Handle sources where the service column carries 'tcp_443;Accept'."""
    text = clean_text(service_text)
    if not text:
        return "", ""
    parts = re.split(r"[;|]\s*", text)
    if len(parts) > 1:
        last = normalize_action(parts[-1])
        if last in {"Accept", "Drop"}:
            return ";".join(parts[:-1]).strip(), last
    return text, ""


def extract_tokens(text: str) -> tuple[list[str], list[str]]:
    text = clean_text(text)
    chgs = sorted({m.group(0).upper() for m in CHG_RE.finditer(text)})
    ctasks = sorted({m.group(0).upper() for m in CTASK_RE.finditer(text)})
    return chgs, ctasks


SECTIONS_HINTS = {"section", "sections", "layer"}


def _looks_like_section_row(row: dict, mapped: dict[str, str]) -> bool:
    type_val = clean_text(row.get(mapped.get("type") or "", "")).lower()
    if type_val in SECTIONS_HINTS:
        return True
    number = clean_text(row.get(mapped.get("rule_number") or "", ""))
    name = clean_text(row.get(mapped.get("rule_name") or "", ""))
    action = clean_text(row.get(mapped.get("action") or "", ""))
    uid = clean_text(row.get(mapped.get("rule_uid") or "", ""))
    # A "rule" without number, name, action or uid is a heading, not a rule.
    return not any([number, name, action, uid])


def _first_text(row: dict, mapped: dict[str, str], keys: tuple[str, ...]) -> str:
    for key in keys:
        col = mapped.get(key)
        if col:
            val = clean_text(row.get(col, ""))
            if val and val.lower() not in {"any", "policy targets"}:
                return val
    return ""


def normalize_rules(records: list[dict], mapping: dict[str, str], source_file: str, source_sheet: str) -> dict:
    """Convert raw rows into rule dicts, skipping section headings and validating rows."""
    rules: list[dict] = []
    section = ""
    skipped_sections: list[str] = []
    invalid_rows: list[dict] = []
    duplicates: list[str] = []
    seen_keys: set[str] = set()
    has_section_column = bool(mapping.get("security_section"))

    for row in records:
        row_no = row.get("__row__")
        if _looks_like_section_row(row, mapping):
            label = _first_text(
                row, mapping, ("security_section", "rule_name", "hit_count", "install_on", "source", "comments", "track")
            ) or clean_text(row.get(mapping.get("type") or "", ""))
            if label and label.lower() not in SECTIONS_HINTS:
                section = label
                skipped_sections.append(label)
            continue

        def val(key: str) -> str:
            col = mapping.get(key)
            return clean_text(row.get(col, "")) if col else ""

        number = val("rule_number")
        uid = val("rule_uid")
        name = val("rule_name")
        if not any([number, uid, name]):
            invalid_rows.append({"row": row_no, "reason": "No rule number, UID or name"})
            continue

        service, action_from_service = split_service_action(val("service"))
        action = normalize_action(val("action")) or action_from_service
        section_value = val("security_section") or section
        hit_raw = val("hit_count")
        hit_count = parse_int(row.get(mapping.get("hit_count") or "", "")) if mapping.get("hit_count") else None

        raw_clean: dict[str, str] = {}
        for col, value in row.items():
            if col == "__row__":
                continue
            text = clean_text(value)
            if text:
                raw_clean[col] = text[:2000]

        rule = {
            "rule_number": number,
            "rule_name": name,
            "rule_uid": uid,
            "security_section": section_value,
            "device": val("device"),
            "source": val("source"),
            "destination": val("destination"),
            "service": service,
            "action": action,
            "install_on": val("install_on"),
            "comments": val("comments"),
            "vpn": val("vpn"),
            "track": val("track"),
            "hit_count": hit_count,
            "hits_raw": hit_raw,
            "first_hit": parse_datetime(row.get(mapping.get("first_hit") or "", "")),
            "last_hit": parse_datetime(row.get(mapping.get("last_hit") or "", "")),
            "expiry_date": parse_date(row.get(mapping.get("expiry_date") or "", "")),
            "owner_hint": val("owner"),
            "raw_json": json.dumps(raw_clean, ensure_ascii=False),
            "source_file": source_file,
            "source_sheet": source_sheet,
            "source_row": row_no,
        }
        key = uid.lower() if uid else f"{(section_value or '').lower()}|{number}|{name.lower()}"
        if key in seen_keys:
            duplicates.append(f"{name or number or uid} (row {row_no})")
            continue
        seen_keys.add(key)
        rules.append(rule)

    return {
        "records": rules,
        "stats": {
            "parsed_rows": len(records),
            "rules": len(rules),
            "section_headings_skipped": len(skipped_sections),
            "sections_detected": sorted(set(skipped_sections)),
            "invalid_rows": len(invalid_rows),
            "invalid_examples": invalid_rows[:20],
            "duplicates": len(duplicates),
            "duplicate_examples": duplicates[:20],
            "source_column_used_for_section": "security_section" if has_section_column else "section headings",
        },
    }


def normalize_changes(records: list[dict], mapping: dict[str, str], source_file: str, source_sheet: str) -> dict:
    changes: list[dict] = []
    invalid: list[dict] = []
    seen: set[str] = set()
    duplicate_count = 0

    for row in records:
        row_no = row.get("__row__")

        def val(key: str) -> str:
            col = mapping.get(key)
            return clean_text(row.get(col, "")) if col else ""

        ctask = val("ctask_number").upper()
        chg = val("chg_number").upper()
        rule_uid = val("rule_uid")
        rule_number = val("rule_number")
        rule_name = val("rule_name")
        description = val("short_description")
        if not any([ctask, chg, rule_uid, rule_number]):
            invalid.append({"row": row_no, "reason": "No change task, change request or rule reference"})
            continue
        # Comments/description sometimes carry extra change references - keep them as evidence.
        chgs_from_text, _ = extract_tokens(description)
        if not chg and chgs_from_text:
            chg = chgs_from_text[0]

        raw_clean = {
            col: clean_text(value)[:2000]
            for col, value in row.items()
            if col != "__row__" and clean_text(value)
        }
        rec = {
            "source_kind": "rule_relationship" if (rule_uid or rule_number) and not val("state") else "change_task",
            "ctask_number": ctask,
            "chg_number": chg,
            "state": val("state"),
            "assigned_to": val("assigned_to"),
            "short_description": description,
            "planned_end_date": parse_datetime(row.get(mapping.get("planned_end_date") or "", "")),
            "rule_number": rule_number,
            "rule_uid": rule_uid,
            "rule_name": rule_name,
            "raw_json": json.dumps(raw_clean, ensure_ascii=False),
            "source_file": source_file,
            "source_sheet": source_sheet,
            "source_row": row_no,
        }
        key = f"{ctask}|{chg}|{rule_uid or ''}|{rule_number or ''}|{row_no}"
        if key in seen:
            duplicate_count += 1
            continue
        seen.add(key)
        changes.append(rec)

    return {
        "records": changes,
        "stats": {
            "parsed_rows": len(records),
            "change_records": len(changes),
            "invalid_rows": len(invalid),
            "invalid_examples": invalid[:20],
            "duplicates": duplicate_count,
            "with_rule_reference": sum(1 for c in changes if c["rule_uid"] or c["rule_number"]),
            "with_owner": sum(1 for c in changes if c["assigned_to"]),
        },
    }
