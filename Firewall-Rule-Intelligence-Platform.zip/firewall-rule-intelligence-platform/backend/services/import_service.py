"""Upload orchestration: validation, sheet detection, mapping confirmation, normalised cache."""
from __future__ import annotations

import gzip
import json
from pathlib import Path

import pandas as pd
from sqlalchemy.orm import Session

from backend.config import PROCESSED_DIR, UPLOAD_DIR
from backend.database.models import AuditLog, Upload, utcnow
from backend.services import file_reader
from backend.services.column_mapper import (
    DATASET_LABELS,
    FIELDS_BY_TYPE,
    detect_mapping,
    merge_manual_mapping,
)
from backend.services.normalize import normalize_changes, normalize_rules

DATASET_DIRS = {
    "rules": UPLOAD_DIR / "firewall_rules",
    "changes": UPLOAD_DIR / "change_records",
    "logs": UPLOAD_DIR / "firewall_logs",
}


def _processed_path(upload_id: int, kind: str) -> Path:
    return PROCESSED_DIR / f"upload_{upload_id}_{kind}.jsonl.gz"


def _sheet_analyses(path: Path, kind: str, dataset_type: str) -> list[dict]:
    """Inspect every sheet and score how well it matches the requested dataset."""
    sheets = file_reader.list_sheets(path, kind) or [None]
    analyses = []
    for sheet in sheets:
        try:
            preview = file_reader.read_preview(path, kind, sheet, nrows=15)
        except file_reader.FileValidationError:
            continue
        df = pd.DataFrame(preview["rows"])
        mapping = detect_mapping(preview["columns"], dataset_type, df)
        entry = {
            "sheet_name": sheet,
            "header_row": preview["header_row"],
            "columns": preview["columns"],
            "mapping": mapping.mapping,
            "mapping_scores": mapping.scores,
            "missing_required": mapping.missing_required,
            "unmapped_columns": mapping.unmapped_columns,
            "warnings": mapping.warnings,
            "score": _sheet_score(mapping.mapping, dataset_type),
        }
        if dataset_type == "rules":
            # A supplementary change-link sheet may be shipped inside the inventory workbook.
            alt = detect_mapping(preview["columns"], "changes", df)
            entry["changes_mapping"] = alt.mapping
            entry["changes_missing_required"] = alt.missing_required
        analyses.append(entry)
    return analyses


def _sheet_score(mapping: dict[str, str | None], dataset_type: str) -> float:
    keys = [k for k, v in mapping.items() if v]
    if dataset_type == "rules":
        core = sum(1 for k in ("rule_number", "rule_name", "rule_uid", "action", "source", "destination") if mapping.get(k))
        return core + len(keys) * 0.1
    if dataset_type == "changes":
        core = sum(1 for k in ("ctask_number", "chg_number", "state", "assigned_to", "short_description") if mapping.get(k))
        return core + len(keys) * 0.1
    core = sum(1 for k in ("timestamp", "rule_uid", "rule_number", "rule_name", "src_ip", "dst_ip") if mapping.get(k))
    return core + len(keys) * 0.1


def create_upload(
    db: Session,
    dataset_type: str,
    filename: str,
    stream,
    actor: str = "local",
    is_synthetic: bool = False,
    replace_upload_id: int | None = None,
) -> Upload:
    if dataset_type not in DATASET_DIRS:
        raise ValueError(f"Unknown dataset type '{dataset_type}'")
    target, size = file_reader.store_upload_bytes(stream, DATASET_DIRS[dataset_type], filename)
    try:
        meta = file_reader.validate_upload(target, filename, dataset_type)
    except Exception:
        target.unlink(missing_ok=True)
        raise

    analyses = _sheet_analyses(target, meta["kind"], dataset_type)
    if not analyses:
        target.unlink(missing_ok=True)
        raise file_reader.FileValidationError("No readable sheet found in the uploaded workbook.")

    # Prefer a sheet that identifies the dataset and can actually yield records.
    best = max(analyses, key=lambda a: a["score"])
    mapping_payload = {
        "mapping": best["mapping"],
        "scores": best["mapping_scores"],
        "unmapped_columns": best["unmapped_columns"],
        "missing_required": best["missing_required"],
        "warnings": best["warnings"],
        "needs_manual_mapping": bool(best["missing_required"]),
        "required_fields": [f.key for f in FIELDS_BY_TYPE[dataset_type] if f.required],
    }

    upload = Upload(
        dataset_type=dataset_type,
        original_filename=filename,
        stored_path=str(target),
        file_kind=meta["kind"],
        size_bytes=size,
        checksum=meta["checksum"],
        sheet_name=best["sheet_name"],
        status="uploaded",
        is_synthetic=is_synthetic,
        is_replacement_of=replace_upload_id,
        uploaded_at=utcnow(),
        uploaded_by=actor,
        mapping_json=json.dumps({**mapping_payload, "manual": False}),
        detection_json=json.dumps({"sheets": analyses, "selected_sheet": best["sheet_name"], "header_row": best["header_row"]}),
        sheets_json=json.dumps([a["sheet_name"] for a in analyses]),
        notes="Detected automatically; review the mapping before processing.",
    )
    db.add(upload)
    db.commit()
    db.refresh(upload)
    db.add(
        AuditLog(
            actor=actor,
            action="upload.created",
            entity="upload",
            entity_id=str(upload.id),
            details_json=json.dumps(
                {
                    "dataset_type": dataset_type,
                    "filename": filename,
                    "size": size,
                    "sheet": best["sheet_name"],
                    "synthetic": is_synthetic,
                }
            ),
        )
    )
    db.commit()
    return upload


def upload_preview(db: Session, upload_id: int, sheet_name: str | None = None, header_row: int | None = None) -> dict:
    upload = db.get(Upload, upload_id)
    if not upload:
        raise ValueError("Upload not found")
    path = Path(upload.stored_path)
    kind = upload.file_kind
    sheet = sheet_name if sheet_name is not None else upload.sheet_name
    detection = json.loads(upload.detection_json or "{}")
    analyses = detection.get("sheets", [])
    meta = next((a for a in analyses if a.get("sheet_name") == sheet), None)
    if header_row is None:
        header_row = meta.get("header_row") if meta else None
    preview = file_reader.read_preview(path, kind, sheet, header_row=header_row, nrows=20)
    df = pd.DataFrame(preview["rows"])

    manual_mapping = {}
    stored = json.loads(upload.mapping_json or "{}")
    if stored.get("manual") and stored.get("mapping") and (sheet_name is None or sheet_name == upload.sheet_name):
        manual_mapping = {k: v for k, v in stored["mapping"].items() if v}

    detected = detect_mapping(preview["columns"], upload.dataset_type, df)
    if manual_mapping:
        detected = merge_manual_mapping(detected, manual_mapping, upload.dataset_type)

    return {
        "upload_id": upload.id,
        "dataset_type": upload.dataset_type,
        "dataset_label": DATASET_LABELS[upload.dataset_type],
        "original_filename": upload.original_filename,
        "size_bytes": upload.size_bytes,
        "file_kind": kind,
        "sheet_name": preview and sheet,
        "sheets": json.loads(upload.sheets_json or "[]"),
        "header_row": preview["header_row"],
        "columns": preview["columns"],
        "rows": preview["rows"],
        "record_count": upload.row_count,
        "detection": detected.as_dict(),
        "fields": [
            {
                "key": f.key,
                "label": f.label,
                "required": f.required,
                "description": f.description,
                "value_hint": f.value_hint,
            }
            for f in FIELDS_BY_TYPE[upload.dataset_type]
        ],
        "uploaded_at": upload.uploaded_at.isoformat(),
        "status": upload.status,
        "is_synthetic": upload.is_synthetic,
        "warnings": detected.warnings + ([] if upload.sheet_name == sheet else [f"Sheet '{sheet}' differs from the auto-selected sheet."]),
    }


def confirm_mapping(db: Session, upload_id: int, mapping: dict[str, str | None], sheet_name: str | None, actor: str = "local") -> Upload:
    """Apply the (possibly manual) mapping, parse the whole file and cache it as JSONL."""
    upload = db.get(Upload, upload_id)
    if not upload:
        raise ValueError("Upload not found")
    path = Path(upload.stored_path)
    sheet = sheet_name or upload.sheet_name
    detection = json.loads(upload.detection_json or "{}")
    meta = next((a for a in detection.get("sheets", []) if a.get("sheet_name") == sheet), None)
    header_row = meta["header_row"] if meta else 0
    preview = file_reader.read_preview(path, upload.file_kind, sheet, header_row=header_row, nrows=20)
    detected = detect_mapping(preview["columns"], upload.dataset_type, pd.DataFrame(preview["rows"]))
    result = merge_manual_mapping(detected, mapping, upload.dataset_type)
    if result.needs_manual_mapping:
        raise ValueError("Mapping is incomplete: " + ", ".join(result.missing_required))

    effective = result.mapping
    upload.mapping_json = json.dumps({**result.as_dict(), "manual": True, "sheet": sheet, "header_row": header_row})
    upload.sheet_name = sheet
    upload.status = "mapped"

    raw_records: list[dict] = []
    for chunk in file_reader.iter_chunks(path, upload.file_kind, sheet, header_row, preview["columns"]):
        raw_records.extend(chunk)
        if upload.dataset_type == "logs" and len(raw_records) > 5000:
            break  # logs are streamed during analysis; only a sample is validated here

    validation: dict = {}
    if upload.dataset_type == "rules":
        normalised = normalize_rules(raw_records, effective, upload.original_filename, sheet or "")
        _write_jsonl(_processed_path(upload.id, "rules"), normalised["records"])
        upload.row_count = normalised["stats"]["rules"]
        validation = normalised["stats"]
        # Supplementary relationship sheets inside the same workbook are imported too.
        related = _import_relationship_sheets(path, upload, detection, db)
        validation["supplementary_change_records"] = related
        upload.notes = "Rule inventory processed. Section headings were skipped, not treated as rules."
    elif upload.dataset_type == "changes":
        normalised = normalize_changes(raw_records, effective, upload.original_filename, sheet or "")
        _write_jsonl(_processed_path(upload.id, "changes"), normalised["records"])
        upload.row_count = normalised["stats"]["change_records"]
        validation = normalised["stats"]
        upload.notes = "Change records processed."
    else:
        upload.row_count = len(raw_records)
        validation = {
            "sampled_rows": len(raw_records),
            "note": "Firewall logs are streamed in chunks during analysis; only a sample was validated at upload time.",
            "sample": [{k: str(v)[:120] for k, v in r.items() if k != "__row__"} for r in raw_records[:20]],
        }
        upload.notes = "Log mapping saved. Row counts are produced during analysis."

    upload.validation_json = json.dumps(validation, default=str)
    upload.status = "processed"
    db.add(
        AuditLog(
            actor=actor,
            action="upload.mapping_confirmed",
            entity="upload",
            entity_id=str(upload.id),
            details_json=json.dumps({"dataset_type": upload.dataset_type, "rows": upload.row_count, "sheet": sheet}),
        )
    )
    db.commit()
    db.refresh(upload)
    return upload


def _import_relationship_sheets(path: Path, upload: Upload, detection: dict, db: Session) -> dict:
    """Import change-link sheets shipped inside the inventory workbook (e.g. Rule_Change_Relationship)."""
    if upload.file_kind != "xlsx":
        return {"imported": 0, "sheets": []}
    imported: list[dict] = []
    for analysis in detection.get("sheets", []):
        sheet = analysis.get("sheet_name")
        if not sheet or sheet == upload.sheet_name:
            continue
        mapping = {k: v for k, v in analysis.get("changes_mapping", {}).items() if v}
        has_change_ref = mapping.get("chg_number") or mapping.get("ctask_number")
        has_rule_ref = mapping.get("rule_uid") or mapping.get("rule_number") or mapping.get("rule_name")
        if not (has_change_ref and has_rule_ref):
            continue
        records: list[dict] = []
        for chunk in file_reader.iter_chunks(path, "xlsx", sheet, analysis["header_row"], analysis["columns"], chunk_size=20000):
            records.extend(chunk)
        normalised = normalize_changes(records, mapping, upload.original_filename, sheet)
        for rec in normalised["records"]:
            rec["source_kind"] = "rule_relationship"
        _write_jsonl(_processed_path(upload.id, "change_links"), normalised["records"])
        imported.append({"sheet": sheet, "records": len(normalised["records"])})
    return {"imported": sum(i["records"] for i in imported), "sheets": imported}


def _write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8") as fh:
        for rec in records:
            fh.write(json.dumps(rec, default=str, ensure_ascii=False) + "\n")


def load_processed(upload_id: int, kind: str) -> list[dict]:
    path = _processed_path(upload_id, kind)
    if not path.exists():
        return []
    out: list[dict] = []
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def upload_summary(upload: Upload) -> dict:
    detection = json.loads(upload.detection_json or "{}")
    mapping = json.loads(upload.mapping_json or "{}")
    return {
        "id": upload.id,
        "dataset_type": upload.dataset_type,
        "dataset_label": DATASET_LABELS.get(upload.dataset_type, upload.dataset_type),
        "original_filename": upload.original_filename,
        "size_bytes": upload.size_bytes,
        "file_kind": upload.file_kind,
        "sheet_name": upload.sheet_name,
        "sheets": json.loads(upload.sheets_json or "[]"),
        "row_count": upload.row_count,
        "status": upload.status,
        "is_synthetic": upload.is_synthetic,
        "is_replacement_of": upload.is_replacement_of,
        "uploaded_at": upload.uploaded_at.isoformat(),
        "uploaded_by": upload.uploaded_by,
        "validation": json.loads(upload.validation_json or "{}"),
        "mapping": mapping.get("mapping", {}),
        "mapping_scores": mapping.get("scores", {}),
        "unmapped_columns": mapping.get("unmapped_columns", []),
        "warnings": mapping.get("warnings", []),
        "missing_required": mapping.get("missing_required", []),
        "detected_sheets": [
            {"sheet_name": s.get("sheet_name"), "score": round(s.get("score", 0), 2), "missing": s.get("missing_required", [])}
            for s in detection.get("sheets", [])
        ],
        "notes": upload.notes,
    }
