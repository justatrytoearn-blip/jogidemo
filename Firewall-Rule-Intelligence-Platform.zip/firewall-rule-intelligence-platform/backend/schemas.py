"""Shared Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class RuleFilter(BaseModel):
    run_id: int | None = None
    q: str | None = None
    rule_name: str | None = None
    rule_number: str | None = None
    rule_uid: str | None = None
    source: str | None = None
    destination: str | None = None
    service: str | None = None
    security_section: str | None = None
    action: str | None = None
    recommendation: str | None = None
    traffic: str | None = None  # active|inactive|unknown|recent|stale
    last_hit_from: str | None = None
    last_hit_to: str | None = None
    change_record: str | None = None  # present|missing
    change_state: str | None = None
    owner: str | None = None
    expiry: str | None = None  # expired|not_expired|unknown
    risk: str | None = None
    ai_generated: str | None = None
    page: int = 1
    page_size: int = 50
    sort_by: str = "rule_number"
    sort_dir: str = "asc"


class MappingRequest(BaseModel):
    mapping: dict[str, str | None] = Field(default_factory=dict)
    sheet_name: str | None = None
    is_synthetic: bool = False
    replace_upload_id: int | None = None


class AnalysisRequest(BaseModel):
    rules_upload_id: int
    changes_upload_id: int | None = None
    logs_upload_id: int | None = None
    label: str = ""
    ai_explanations: bool = True
    parent_run_id: int | None = None


class PolicyUpdate(BaseModel):
    policy: dict[str, Any] = Field(default_factory=dict)


class ApprovalRequest(BaseModel):
    kind: str
    approved_by: str
    note: str = ""


class DisableEvidenceRequest(BaseModel):
    disabled_at: str
    monitored_until: str | None = None
    change_reference: str = ""
    note: str = ""


class SettingsUpdate(BaseModel):
    ollama_url: str | None = None
    ollama_model: str | None = None
    ai_enabled: bool | None = None
    ai_timeout: int | None = None
    ai_max_rules: int | None = None
    auth_enabled: bool | None = None


class LoginRequest(BaseModel):
    username: str
    password: str


class ReviewRequest(BaseModel):
    rule_ids: list[int] = Field(default_factory=list)
    use_filters: bool = False
    filters: RuleFilter | None = None
    generate_ai: bool = True
