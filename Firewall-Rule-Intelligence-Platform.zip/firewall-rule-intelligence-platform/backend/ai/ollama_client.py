"""Minimal Ollama client. Local only - no customer data ever leaves the machine."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass

import httpx

from backend.config import effective_ai_config

log = logging.getLogger("fip.ai")


class OllamaUnavailable(RuntimeError):
    pass


@dataclass
class OllamaStatus:
    available: bool
    url: str
    model: str
    models: list[str]
    message: str


def status(url: str | None = None, model: str | None = None) -> OllamaStatus:
    cfg = effective_ai_config()
    url = (url or cfg["url"]).rstrip("/")
    model = model or cfg["model"]
    try:
        resp = httpx.get(f"{url}/api/tags", timeout=5)
        resp.raise_for_status()
        models = [m.get("name", "") for m in resp.json().get("models", [])]
        available = bool(models)
        msg = f"Ollama reachable; {len(models)} model(s) installed."
        if model and not any(m == model or m.split(":")[0] == model.split(":")[0] for m in models):
            msg += f" Configured model '{model}' is not installed yet."
            available = False
        return OllamaStatus(available, url, model, models, msg)
    except Exception as exc:  # noqa: BLE001
        return OllamaStatus(False, url, model, [], f"Ollama not reachable at {url}: {exc}")


def chat_json(system: str, user: str, *, model: str | None = None, timeout: int | None = None) -> dict:
    """Call Ollama in JSON mode and parse the response."""
    cfg = effective_ai_config()
    url = cfg["url"].rstrip("/")
    model = model or cfg["model"]
    timeout = timeout or cfg["timeout"]
    payload = {
        "model": model,
        "stream": False,
        "format": "json",
        "options": {"temperature": 0.2, "num_ctx": 4096, "num_predict": 420},
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    try:
        resp = httpx.post(f"{url}/api/chat", json=payload, timeout=timeout)
        resp.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        raise OllamaUnavailable(f"Local model call failed: {exc}") from exc
    content = (resp.json().get("message") or {}).get("content", "")
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        start, end = content.find("{"), content.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(content[start: end + 1])
            except json.JSONDecodeError:
                pass
    raise OllamaUnavailable("Local model returned non-JSON output")


def chat_text(system: str, user: str, *, model: str | None = None, timeout: int | None = None) -> str:
    cfg = effective_ai_config()
    url = cfg["url"].rstrip("/")
    payload = {
        "model": model or cfg["model"],
        "stream": False,
        "options": {"temperature": 0.2, "num_ctx": 4096, "num_predict": 500},
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    try:
        resp = httpx.post(f"{url}/api/chat", json=payload, timeout=timeout or cfg["timeout"])
        resp.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        raise OllamaUnavailable(f"Local model call failed: {exc}") from exc
    return (resp.json().get("message") or {}).get("content", "").strip()
