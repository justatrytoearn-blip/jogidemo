"""Evidence-grounded AI narration.

The deterministic engine decides; the local model only explains. Every response is
validated against the engine output and rejected if it invents identifiers or
argues for a different recommendation.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime

from backend.ai import ollama_client
from backend.config import effective_ai_config

log = logging.getLogger("fip.ai.reviewer")

IP_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
CATEGORIES = ("KEEP", "REVIEW", "DISABLE", "DELETE")

SYSTEM_RULE = (
    "You are a firewall review analyst documenting evidence for an enterprise change board. "
    "Use ONLY the supplied JSON evidence. Never invent IP addresses, rule names, dates, owners or change numbers. "
    "Do not speculate about intent, threat level, business purpose or security posture - if the evidence does not "
    "state it, do not claim it. Cite the supplied numbers (matching log events, observation window, days since last "
    "hit, linked change records) where they are relevant. A deterministic policy engine has already chosen the "
    "recommendation; explain it and never choose a different one. Never instruct anyone to change a firewall "
    "directly - all actions go through change management. Reply with JSON only, using the keys: "
    "reason, business_impact, technical_impact, next_action, caveats. Each value is one or two short sentences."
)


def _context_payload(rule: dict, metric: dict, change: dict, rec: dict) -> dict:
    # Inventory hit counters are deliberately excluded: models confuse them with log events.
    return {
        "rule": {
            "number": rule.get("rule_number"),
            "name": rule.get("rule_name"),
            "section": rule.get("security_section"),
            "action": rule.get("action"),
            "source": rule.get("source"),
            "destination": rule.get("destination"),
            "service": rule.get("service"),
        },
        "traffic_evidence_is_from_log_events_only": True,
        "traffic_evidence": {
            "matching_log_events": metric.get("event_count"),
            "events_in_window": metric.get("window_event_count"),
            "observation_days": metric.get("observation_days"),
            "log_coverage_days": metric.get("log_coverage_days"),
            "first_seen": metric.get("first_seen").isoformat() if metric.get("first_seen") else None,
            "last_seen": metric.get("last_seen").isoformat() if metric.get("last_seen") else None,
            "days_since_last_hit": metric.get("days_since_last_hit"),
            "avg_per_day": metric.get("avg_per_day"),
            "trend": metric.get("trend"),
            "match_method": metric.get("match_method"),
        },
        "change_evidence": {
            "linked_records": change.get("record_count", 0),
            "documented": change.get("documented"),
            "owner": change.get("owner"),
            "change_request": change.get("change_request"),
            "change_task": change.get("change_task"),
            "state": change.get("change_status"),
            "conflicting": change.get("conflicting"),
        },
        "recommendation": {
            "category": rec["category"],
            "risk_level": rec["risk_level"],
            "confidence": rec["confidence"],
            "policy_triggers": [t["code"] for t in rec.get("triggers", [])],
            "missing_evidence": [m["code"] for m in rec.get("missing", [])],
            "approval_status": rec.get("approval_status"),
        },
    }


def _validate(payload: dict, rec: dict, context_text: str) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(payload, dict):
        return False, ["Model response was not a JSON object"]
    text = " ".join(str(v) for v in payload.values())
    if not text.strip():
        return False, ["Model response was empty"]
    for cat in CATEGORIES:
        if cat == rec["category"]:
            continue
        if re.search(rf"\b(?:recommend|should be|change to|classif\w+ as)\s+{cat}\b", text, re.I):
            return False, [f"Model proposed {cat} while the policy engine decided {rec['category']}"]
    allowed_ips = set(IP_RE.findall(context_text))
    invented = {ip for ip in IP_RE.findall(text) if ip not in allowed_ips}
    if invented:
        return False, [f"Model invented identifiers not present in evidence: {', '.join(sorted(invented)[:3])}"]

    # Numeric-consistency guard: the model must not contradict the measured traffic.
    traffic = (json.loads(context_text).get("traffic_evidence") or {}) if context_text else {}
    window_events = int(traffic.get("events_in_window") or 0)
    total_events = int(traffic.get("matching_log_events") or 0)
    no_traffic_claim = re.search(
        r"\b(no|zero)\s+(recent\s+)?(hits?|traffic|events?|activity)\b|not triggering|never (matched|used)|unused",
        text,
        re.I,
    )
    if (window_events > 0 or total_events > 0) and no_traffic_claim:
        return False, ["Model claimed no traffic although matching log events were measured"]
    traffic_claim = re.search(r"\b(active|actively used|frequent traffic|heavily used)\b|\bhigh traffic\b", text, re.I)
    if total_events == 0 and traffic_claim and rec["category"] != "KEEP":
        return False, ["Model implied active usage although no matching log events were measured"]
    if len(text) > 6000:
        warnings.append("Model response was truncated to the configured limit")
    change = json.loads(context_text).get("change_evidence") or {}
    positive_doc_claim = r"\b(?:is|are|was|were|has been|have been)\s+documented\b|\bdocumentation (?:is )?(?:present|complete)\b"
    if not change.get("documented"):
        for clause in re.split(r"[.;\n]", text):
            if re.search(positive_doc_claim, clause, re.I) and not re.search(
                r"\b(not|no|missing|without|undocumented|absent|unknown|unavailable)\b", clause, re.I
            ):
                return False, ["Model claimed change documentation that is not recorded"]
    return True, warnings


def explain_rule(rule: dict, metric: dict, change: dict, rec: dict, model: str | None = None) -> dict:
    """Return {generated, validated, model, fields, warnings}. model overrides settings."""
    cfg = effective_ai_config()
    context = _context_payload(rule, metric, change, rec)
    context_text = json.dumps(context, default=str)
    traffic = context["traffic_evidence"]
    facts = (
        "EVIDENCE FACTS (do not change any value):\n"
        f"- Rule {rule.get('rule_number')} '{rule.get('rule_name')}', action {rule.get('action')}\n"
        f"- Matching log events in the observation window: {traffic.get('events_in_window')} "
        f"(window {traffic.get('observation_days')} days, log coverage {traffic.get('log_coverage_days')} days)\n"
        f"- Total matching log events: {traffic.get('matching_log_events')}\n"
        f"- Last matching log event: {traffic.get('days_since_last_hit')} day(s) ago\n"
        f"- Average events per day: {traffic.get('avg_per_day')}\n"
        f"- Linked change records: {context['change_evidence'].get('linked_records')}; "
        f"documented: {context['change_evidence'].get('documented')}; owner: {context['change_evidence'].get('owner') or 'unknown'}\n"
        f"- Policy decision: {rec['category']} (risk {rec['risk_level']}, confidence {rec['confidence']})\n"
        f"- Missing evidence codes: {', '.join(m['code'] for m in rec.get('missing', [])) or 'none'}\n\n"
        f"JSON CONTEXT:\n{context_text}\n\n"
        "Write the JSON now. In 'reason', cite the matching event count and the last-event days exactly as given."
    )
    if not cfg["enabled"]:
        return _fallback(rec, "AI explanations are disabled in settings.")
    try:
        payload = ollama_client.chat_json(SYSTEM_RULE, facts, model=model or cfg["model"])
        validated, warnings = _validate(payload, rec, context_text)
    except ollama_client.OllamaUnavailable as exc:
        return _fallback(rec, str(exc))
    if not validated:
        return _fallback(rec, "; ".join(warnings))
    fields = {
        "reason": _clean(payload.get("reason")) or rec["reason"],
        "business_impact": _clean(payload.get("business_impact")) or rec["business_impact"],
        "technical_impact": _clean(payload.get("technical_impact")) or rec["technical_impact"],
        "next_action": _clean(payload.get("next_action")) or rec["next_action"],
        "caveats": _clean(payload.get("caveats")),
    }
    return {
        "generated": True,
        "validated": True,
        "model": model or cfg["model"],
        "fields": fields,
        "warnings": warnings,
        "generated_at": datetime.utcnow().isoformat(),
        "grounded_on": {
            "category": rec["category"],
            "policy_triggers": [t["code"] for t in rec.get("triggers", [])],
            "missing_evidence": [m["code"] for m in rec.get("missing", [])],
        },
    }


def _clean(value) -> str:
    if value is None:
        return ""
    text = re.sub(r"\s+", " ", str(value)).strip()
    return text[:1200]


def _fallback(rec: dict, error: str) -> dict:
    return {
        "generated": False,
        "validated": False,
        "model": "",
        "fields": {
            "reason": rec["reason"],
            "business_impact": rec["business_impact"],
            "technical_impact": rec["technical_impact"],
            "next_action": rec["next_action"],
            "caveats": "Deterministic policy text shown; local AI narrative was not generated.",
        },
        "warnings": [error],
        "generated_at": datetime.utcnow().isoformat(),
        "grounded_on": {"category": rec["category"]},
    }


SYSTEM_EXEC = (
    "You are writing an executive summary for a firewall rule review. Use only the supplied aggregate numbers. "
    "Do not invent figures. Do not recommend bypassing change management. Reply in plain prose, 120 words maximum, "
    "no markdown headings, no bullet lists."
)


def executive_summary(stats: dict, policy: dict) -> dict:
    cfg = effective_ai_config()
    prompt = json.dumps({"statistics": stats, "policy": policy}, default=str)
    fallback_text = (
        f"The analysis covered {stats.get('total_rules', 0)} firewall rules. "
        f"{stats.get('keep', 0)} are recommended to KEEP, {stats.get('review', 0)} require REVIEW, "
        f"{stats.get('disable', 0)} qualify for DISABLE and {stats.get('delete', 0)} qualify for DELETE. "
        f"{stats.get('without_change_records', 0)} rules have no linked change record and "
        f"{stats.get('without_owner', 0)} have no identified owner. "
        f"{stats.get('without_traffic_evidence', 0)} rules have no matching log evidence, so they cannot be "
        "safely disabled or deleted until logs are supplied."
    )
    if not cfg["enabled"]:
        return {"generated": False, "validated": False, "text": fallback_text, "model": "", "warnings": ["AI disabled"]}
    try:
        text = ollama_client.chat_text(SYSTEM_EXEC, prompt, model=cfg["model"])
    except ollama_client.OllamaUnavailable as exc:
        return {"generated": False, "validated": False, "text": fallback_text, "model": "", "warnings": [str(exc)]}
    text = re.sub(r"\s+", " ", text).strip()
    if not text or len(text) > 2000:
        return {"generated": False, "validated": False, "text": fallback_text, "model": "", "warnings": ["Unusable model output"]}
    invented = {ip for ip in IP_RE.findall(text) if ip not in prompt}
    if invented:
        return {
            "generated": False,
            "validated": False,
            "text": fallback_text,
            "model": "",
            "warnings": [f"Invented identifiers in summary: {sorted(invented)[:3]}"],
        }
    return {"generated": True, "validated": True, "text": text, "model": cfg["model"], "warnings": []}
