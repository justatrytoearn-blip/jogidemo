"""Deterministic recommendation engine.

The engine - never the LLM - decides KEEP / REVIEW / DISABLE / DELETE. Every
decision is derived from explicit evidence, policy thresholds and recorded
approvals, and every decision exposes the triggers and gaps that produced it.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from backend.recommendation_engine.policy import Policy

KEEP, REVIEW, DISABLE, DELETE = "KEEP", "REVIEW", "DISABLE", "DELETE"
APPROVAL_DISABLE = "business_confirmation"
APPROVAL_DELETE = "delete_approval"
APPROVAL_OBSOLETE = "obsolescence_confirmation"


def _triggers(*items: tuple[str, str]) -> list[dict]:
    return [{"code": code, "description": text} for code, text in items]


def _fmt_date(value) -> str:
    if not value:
        return "unknown"
    if isinstance(value, str):
        return value[:19].replace("T", " ")
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M")
    return str(value)


def expiry_status(rule: dict, today: datetime) -> str:
    raw = rule.get("expiry_date")
    if not raw:
        return "unknown"
    try:
        expiry = raw if isinstance(raw, datetime) else datetime.fromisoformat(str(raw))
    except ValueError:
        return "unknown"
    return "expired" if expiry.date() < today.date() else "not_expired"


def evaluate(
    rule: dict,
    traffic: dict,
    change: dict,
    policy: Policy,
    approvals: set[str] | None = None,
    disable_evidence: dict | None = None,
    now: datetime | None = None,
) -> dict:
    """Evaluate one rule and return the complete recommendation record."""
    now = now or datetime.utcnow()
    approvals = approvals or set()
    change = change or {}
    traffic = traffic or {}

    expiry = expiry_status(rule, now)
    owner = (change.get("owner") or rule.get("owner_hint") or "").strip()
    documented = bool(change.get("documented"))
    has_change_records = bool(change.get("record_count") or change.get("records"))
    coverage_days = int(traffic.get("log_coverage_days") or 0)
    traffic_available = bool(traffic.get("matched"))
    absence_is_evidence = bool(traffic.get("absence_is_evidence"))
    # Zero events can be positive evidence only when the log file covers this rule's identity space.
    traffic_trustworthy = (traffic_available or absence_is_evidence) and coverage_days >= policy.min_log_coverage_days
    window_count = int(traffic.get("window_event_count") or 0)
    days_since = traffic.get("days_since_last_hit")
    stale = days_since is not None and days_since > policy.last_hit_age_threshold_days
    recent = traffic_trustworthy and window_count >= policy.min_keep_events and not stale
    conflicts = bool(change.get("conflicting"))
    missing_source = not str(rule.get("source") or "").strip()
    missing_destination = not str(rule.get("destination") or "").strip()
    missing_hit_count = rule.get("hit_count") is None
    missing_timestamps = not rule.get("last_hit")
    disable_done = bool(disable_evidence)
    monitoring_complete = False
    monitoring_note = ""
    if disable_done:
        disabled_at = disable_evidence.get("disabled_at")
        try:
            disabled_at = disabled_at if isinstance(disabled_at, datetime) else datetime.fromisoformat(str(disabled_at))
        except (TypeError, ValueError):
            disabled_at = None
        if disabled_at:
            required_until = disabled_at + timedelta(days=policy.disable_monitoring_days)
            monitored_until = disable_evidence.get("monitored_until")
            try:
                monitored_until = monitored_until if isinstance(monitored_until, datetime) else (
                    datetime.fromisoformat(str(monitored_until)) if monitored_until else None
                )
            except (TypeError, ValueError):
                monitored_until = None
            monitoring_complete = (monitored_until or now) >= required_until
            monitoring_note = (
                f"Disabled {_fmt_date(disabled_at)}; monitoring until {_fmt_date(monitored_until or required_until)} "
                f"(required {policy.disable_monitoring_days} days)"
            )
        traffic_after_disable = False
        if disabled_at and traffic.get("last_seen"):
            last = traffic["last_seen"]
            try:
                last = last if isinstance(last, datetime) else datetime.fromisoformat(str(last))
                traffic_after_disable = last > disabled_at
            except (TypeError, ValueError):
                traffic_after_disable = False
        disable_done = bool(monitoring_complete and not traffic_after_disable)

    missing: list[dict] = []

    def add_missing(code: str, text: str) -> None:
        missing.append({"code": code, "description": text})

    if not traffic_available and not absence_is_evidence:
        add_missing(
            "NO_LOG_EVIDENCE",
            "No usable firewall log evidence for this rule: no log file was supplied, or the supplied logs do not share this inventory's rule identity space.",
        )
    elif coverage_days < policy.min_log_coverage_days:
        add_missing(
            "INSUFFICIENT_OBSERVATION",
            f"Log history covers {coverage_days} day(s); policy requires at least {policy.min_log_coverage_days}.",
        )
    if not has_change_records:
        add_missing("NO_CHANGE_RECORD", "No change request or change task is linked to this rule.")
    elif not documented:
        add_missing("CHANGE_NOT_DOCUMENTED", "Linked change records are missing a task state or description.")
    if not owner:
        add_missing("UNKNOWN_OWNER", "No owner could be identified from the inventory or linked change records.")
    if missing_source:
        add_missing("MISSING_SOURCE", "Rule has no source defined.")
    if missing_destination:
        add_missing("MISSING_DESTINATION", "Rule has no destination defined.")
    if missing_hit_count:
        add_missing("MISSING_HIT_COUNT", "Inventory hit counter is unavailable or unparsable.")
    if missing_timestamps:
        add_missing("MISSING_LAST_HIT", "Inventory last-hit timestamp is unavailable.")
    if expiry == "unknown":
        add_missing("EXPIRY_UNKNOWN", "No expiry / review date is available for this rule.")
    if conflicts:
        add_missing("CONFLICTING_INFORMATION", "; ".join(change.get("notes") or ["Linked records disagree."]))

    triggers: list[dict] = []
    category = REVIEW
    eligible_for = ""
    approval_status = "not_required"

    # --- DELETE ---------------------------------------------------------
    delete_approved = APPROVAL_DELETE in approvals
    obsolete_confirmed = APPROVAL_OBSOLETE in approvals
    delete_gate = (
        traffic_trustworthy
        and window_count == 0
        and disable_done
        and (delete_approved or not policy.require_delete_approval)
        and (obsolete_confirmed or not policy.require_delete_approval)
        and (disable_done or not policy.require_disabled_evidence_for_delete)
    )
    if delete_gate:
        category = DELETE
        approval_status = "delete_approved"
        triggers = _triggers(
            ("ZERO_TRAFFIC_WINDOW", f"No matching log events in the last {policy.observation_days} days."),
            ("RULE_DISABLED_AND_MONITORED", monitoring_note or "Rule disabled and monitored."),
            ("DELETE_APPROVED", "Deletion approval recorded."),
            ("OBSOLESCENCE_CONFIRMED", "Rule confirmed obsolete by the owner."),
        )
    else:
        # --- DISABLE ----------------------------------------------------
        business_ok = APPROVAL_DISABLE in approvals or not policy.require_business_approval_for_disable
        disable_conditions = (
            traffic_trustworthy
            and window_count == 0
            and days_since is not None
            and days_since >= policy.last_hit_age_threshold_days
        )
        if disable_conditions and business_ok and not conflicts:
            category = DISABLE
            approval_status = "disable_approved"
            triggers = _triggers(
                ("ZERO_TRAFFIC_WINDOW", f"No matching log events in the last {policy.observation_days} days."),
                (
                    "LAST_HIT_EXCEEDS_THRESHOLD",
                    f"Last matching log event was {days_since} days ago (threshold {policy.last_hit_age_threshold_days}).",
                ),
                ("BUSINESS_CONFIRMATION", "Business owner confirmation recorded."),
            )
        elif recent and documented and owner and expiry != "expired" and not conflicts:
            # --- KEEP ---------------------------------------------------
            category = KEEP
            triggers = _triggers(
                ("RECENT_TRAFFIC", f"{window_count} matching log event(s) inside the {policy.observation_days}-day window."),
                ("LAST_HIT_IN_WINDOW", f"Last matching log event {days_since} day(s) ago."),
                ("CHANGE_DOCUMENTED", "Change history is linked and documented."),
                ("OWNER_KNOWN", f"Owner identified as {owner}."),
                ("NOT_EXPIRED", "No expiry has passed."),
            )
        else:
            category = REVIEW
            if disable_conditions and not business_ok:
                eligible_for = DISABLE
                approval_status = "pending_business_confirmation"
                triggers = _triggers(
                    ("ZERO_TRAFFIC_WINDOW", f"No matching log events in the last {policy.observation_days} days."),
                    (
                        "AWAITING_BUSINESS_CONFIRMATION",
                        "Rule otherwise qualifies for DISABLE but no business owner confirmation is recorded.",
                    ),
                )
            elif disable_conditions and conflicts:
                eligible_for = DISABLE
                approval_status = "blocked_by_conflict"
                triggers = _triggers(
                    ("ZERO_TRAFFIC_WINDOW", f"No matching log events in the last {policy.observation_days} days."),
                    ("CONFLICTING_INFORMATION", "Conflicting change information must be resolved before disabling."),
                )
            elif disable_done and traffic_trustworthy and window_count == 0:
                eligible_for = DELETE
                approval_status = "pending_delete_approval"
                triggers = _triggers(
                    ("RULE_DISABLED_AND_MONITORED", monitoring_note or "Rule disabled and monitored."),
                    ("AWAITING_DELETE_APPROVAL", "Deletion approval or obsolescence confirmation is missing."),
                )
            elif traffic_trustworthy and window_count == 0 and days_since is None:
                eligible_for = DISABLE
                approval_status = "pending_business_confirmation"
                triggers = _triggers(
                    ("NO_LOGGED_TRAFFIC", f"No matching log events at all in {coverage_days} day(s) of log history."),
                    (
                        "AWAITING_BUSINESS_CONFIRMATION",
                        "Zero traffic alone never justifies disabling a rule; business confirmation is required.",
                    ),
                )
            elif traffic_trustworthy and window_count == 0 and days_since < policy.last_hit_age_threshold_days:
                triggers = _triggers(
                    ("NO_RECENT_TRAFFIC", f"No matching events in the last {policy.observation_days} days."),
                    (
                        "MONITORING_NOT_MATURED",
                        f"Last hit was {days_since if days_since is not None else 'unknown'} days ago; DISABLE needs {policy.last_hit_age_threshold_days}.",
                    ),
                )
            elif traffic_available and window_count > 0:
                triggers = _triggers(
                    ("TRAFFIC_PRESENT_BUT_GAPS", f"{window_count} event(s) observed but required evidence is missing."),
                )
            else:
                triggers = _triggers(
                    ("INSUFFICIENT_EVIDENCE", "Evidence is insufficient to support any operational change."),
                )

    # --- risk -----------------------------------------------------------
    score = 0
    if str(rule.get("action", "")).lower() == "accept":
        score += 2
    else:
        score += 1
    if not documented:
        score += 2
    if not owner:
        score += 1
    if expiry == "expired":
        score += 2
    if conflicts:
        score += 2
    if not traffic_trustworthy:
        score += 1
    if any(tok in f"{rule.get('source','')} {rule.get('destination','')}".lower() for tok in ("any", "all")):
        score += 1
    if str(rule.get("action", "")).lower() == "accept" and not documented and traffic_available and window_count > 0:
        score += 1
    if traffic.get("trend") == "increasing" and not documented:
        score += 1
    risk = "Critical" if score >= 7 else "High" if score >= 5 else "Medium" if score >= 3 else "Low"

    # --- confidence -----------------------------------------------------
    conf_score = 0.0
    if traffic_trustworthy:
        conf_score += 0.4
    elif traffic_available:
        conf_score += 0.15
    if documented:
        conf_score += 0.25
    if owner:
        conf_score += 0.15
    if rule.get("last_hit") or traffic.get("last_seen"):
        conf_score += 0.1
    if expiry != "unknown":
        conf_score += 0.1
    confidence = "High" if conf_score >= 0.8 else "Medium" if conf_score >= 0.55 else "Low"

    reason = _reason(category, rule, traffic, change, policy, days_since, window_count, owner, expiry, eligible_for)
    next_action = _next_action(category, missing, policy, eligible_for, approvals, disable_evidence)
    business_impact, technical_impact = _impacts(category, rule, traffic, window_count, owner)

    return {
        "category": category,
        "eligible_for": eligible_for,
        "risk_level": risk,
        "risk_score": score,
        "confidence": confidence,
        "confidence_score": round(conf_score, 2),
        "triggers": triggers,
        "missing": missing,
        "approval_status": approval_status,
        "reason": reason,
        "next_action": next_action,
        "business_impact": business_impact,
        "technical_impact": technical_impact,
        "expiry_status": expiry,
        "owner": owner,
        "change_status": change.get("change_status", "") if change else "",
        "change_request": change.get("change_request", "") if change else "",
        "change_task": change.get("change_task", "") if change else "",
        "evidence": {
            "inventory": {
                "action": rule.get("action"),
                "source": rule.get("source"),
                "destination": rule.get("destination"),
                "service": rule.get("service"),
                "hit_count": rule.get("hit_count"),
                "hits_raw": rule.get("hits_raw"),
                "inventory_first_hit": _fmt_date(rule.get("first_hit")),
                "inventory_last_hit": _fmt_date(rule.get("last_hit")),
                "security_section": rule.get("security_section"),
                "expiry_date": _fmt_date(rule.get("expiry_date")) if rule.get("expiry_date") else "",
            },
            "traffic": {
                "matched": traffic_available,
                "match_method": traffic.get("match_method", "none"),
                "match_confidence": traffic.get("match_confidence", 0),
                "event_count": traffic.get("event_count", 0),
                "window_event_count": window_count,
                "first_seen": _fmt_date(traffic.get("first_seen")),
                "last_seen": _fmt_date(traffic.get("last_seen")),
                "days_since_last_hit": days_since,
                "avg_per_day": traffic.get("avg_per_day", 0),
                "avg_per_week": traffic.get("avg_per_week", 0),
                "avg_per_month": traffic.get("avg_per_month", 0),
                "trend": traffic.get("trend", "unknown"),
                "log_coverage_days": coverage_days,
                "observation_days": traffic.get("observation_days", policy.observation_days),
            },
            "change": {
                "records": (change.get("records") or [])[:10] if isinstance(change.get("records"), list) else [],
                "record_count": change.get("record_count", 0),
                "documented": documented,
                "owner": owner,
                "conflicting": conflicts,
                "notes": change.get("notes", []),
            },
            "approvals": {
                "business_confirmation": APPROVAL_DISABLE in approvals,
                "delete_approval": delete_approved,
                "obsolescence_confirmation": obsolete_confirmed,
            },
            "disable_evidence": disable_evidence or {},
        },
        "policy_snapshot": policy.to_dict(),
        "analysis_date": now.isoformat(),
    }


def _reason(category, rule, traffic, change, policy, days_since, window_count, owner, expiry, eligible_for) -> str:
    name = rule.get("rule_name") or f"Rule {rule.get('rule_number')}"
    action = rule.get("action") or "unknown action"
    if category == KEEP:
        return (
            f"{name} ({action}) is actively used: {window_count} matching log event(s) were observed in the "
            f"{policy.observation_days}-day window, the last event was {days_since} day(s) ago, change history is "
            f"documented and the owner is {owner}. No review action is required beyond the normal cycle."
        )
    if category == DISABLE:
        return (
            f"{name} ({action}) had no matching traffic in the {policy.observation_days}-day observation window and "
            f"its last matching event was {days_since} days ago, beyond the {policy.last_hit_age_threshold_days}-day "
            "threshold. The business owner has confirmed the rule is no longer required, so the rule qualifies for "
            "DISABLE through the normal change process."
        )
    if category == DELETE:
        return (
            f"{name} ({action}) was disabled, monitored for the required period without matching traffic, and both "
            "deletion approval and obsolescence confirmation are recorded. The rule qualifies for DELETE through the "
            "change process."
        )
    gaps = ", ".join(m["description"].rstrip(".") for m in _missing_brief(traffic, change, rule, policy, owner, expiry))
    prefix = f"{name} ({action}) cannot be classified safely."
    if eligible_for:
        prefix += f" It otherwise qualifies for {eligible_for}, but mandatory approvals/evidence are missing."
    return f"{prefix} Outstanding evidence: {gaps or 'insufficient observation period'}."


def _missing_brief(traffic, change, rule, policy, owner, expiry):
    out = []
    if not traffic.get("matched"):
        out.append({"description": "no matching firewall log evidence"})
    elif int(traffic.get("log_coverage_days") or 0) < policy.min_log_coverage_days:
        out.append({"description": "observation period shorter than policy minimum"})
    if not change.get("documented"):
        out.append({"description": "change documentation not verified"})
    if not owner:
        out.append({"description": "owner not identified"})
    if expiry == "unknown":
        out.append({"description": "expiry information unavailable"})
    if not rule.get("last_hit"):
        out.append({"description": "inventory last-hit timestamp unavailable"})
    return out


def _next_action(category, missing, policy, eligible_for, approvals, disable_evidence) -> str:
    if category == KEEP:
        return "No change. Retain the rule and include it in the next scheduled review."
    if category == DISABLE:
        return (
            "Raise a change request to disable this rule, then monitor it for at least "
            f"{policy.disable_monitoring_days} days before proposing deletion."
        )
    if category == DELETE:
        return "Raise a deletion change request. The platform never performs the change itself."
    if eligible_for == DISABLE:
        return (
            "Obtain recorded confirmation from the business owner that the rule is no longer required, then "
            "raise a disable change request."
        )
    if eligible_for == DELETE:
        return "Record the deletion approval and obsolescence confirmation, then raise the deletion change request."
    codes = {m["code"] for m in missing}
    steps = []
    if "NO_LOG_EVIDENCE" in codes:
        steps.append("upload firewall logs covering the observation period")
    if "INSUFFICIENT_OBSERVATION" in codes:
        steps.append(f"supply at least {policy.min_log_coverage_days} days of log history")
    if {"NO_CHANGE_RECORD", "CHANGE_NOT_DOCUMENTED"} & codes:
        steps.append("link or complete the ServiceNow change documentation")
    if "UNKNOWN_OWNER" in codes:
        steps.append("identify the business owner")
    if "CONFLICTING_INFORMATION" in codes:
        steps.append("resolve conflicting change records")
    if "EXPIRY_UNKNOWN" in codes and policy.expiry_unknown_forces_review:
        steps.append("record an expiry or review date")
    if not steps:
        steps.append("perform a manual review with the rule owner")
    return "Manual review required: " + "; ".join(steps) + "."


def _impacts(category, rule, traffic, window_count, owner) -> tuple[str, str]:
    action = str(rule.get("action") or "").lower()
    exposure = f"{rule.get('source') or 'unknown source'} -> {rule.get('destination') or 'unknown destination'}"
    if category == KEEP:
        return (
            f"Retaining this {action or 'configured'} rule preserves the documented connectivity for {exposure}.",
            "No configuration change. No outage risk introduced by this recommendation.",
        )
    if category in (DISABLE, DELETE):
        return (
            f"Removing this rule withdraws {exposure} for '{rule.get('rule_name') or 'the rule'}'. "
            f"Owner {owner or 'unknown'} has confirmed it is no longer required.",
            "Disabling may interrupt undocumented dependencies; monitor for at least "
            f"one business cycle and keep the change reversible.",
        )
    return (
        f"The business dependency for {exposure} is not documented well enough to change this rule safely.",
        "No configuration change is recommended until evidence and approvals are complete.",
    )


def summarize(results: list[dict]) -> dict:
    counts = {KEEP: 0, REVIEW: 0, DISABLE: 0, DELETE: 0}
    risk = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    confidence = {"High": 0, "Medium": 0, "Low": 0}
    eligible = {DISABLE: 0, DELETE: 0}
    for r in results:
        counts[r["category"]] = counts.get(r["category"], 0) + 1
        risk[r["risk_level"]] = risk.get(r["risk_level"], 0) + 1
        confidence[r["confidence"]] = confidence.get(r["confidence"], 0) + 1
        if r.get("eligible_for") in eligible:
            eligible[r["eligible_for"]] += 1
    return {"counts": counts, "risk": risk, "confidence": confidence, "eligible": eligible, "total": len(results)}
