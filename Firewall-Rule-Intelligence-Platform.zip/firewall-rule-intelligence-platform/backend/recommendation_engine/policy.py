"""Configurable review policy with conservative defaults."""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields

from backend.config import DEFAULT_POLICY

POLICY_HINTS = {
    "observation_days": "Traffic observation window (days) used to judge current usage. Default 90.",
    "last_hit_age_threshold_days": "A rule must be unused for at least this long before DISABLE is proposed. Default 180.",
    "disable_monitoring_days": "Monitoring period required after a rule is disabled before DELETE can be proposed. Default 30.",
    "min_keep_events": "Minimum matching log events inside the window to support KEEP. Default 1.",
    "min_log_coverage_days": "Minimum log history required before traffic evidence is trusted. Default 30.",
    "require_business_approval_for_disable": "DISABLE needs recorded business owner confirmation. Default true.",
    "require_delete_approval": "DELETE needs recorded deletion approval. Default true.",
    "require_disabled_evidence_for_delete": "DELETE needs evidence the rule was disabled and monitored. Default true.",
    "traffic_frequency_low_per_day": "Below this average daily frequency a rule is described as low-frequency. Default 1.",
    "traffic_frequency_high_per_day": "Above this average daily frequency a rule is described as high-frequency. Default 100.",
    "expiry_data_expected": "Whether expiry dates are expected in the inventory. Default false (settings say expiry is optional).",
    "expiry_unknown_forces_review": "Force REVIEW when expiry is unknown. Default false - unknown expiry alone is not proof of obsolescence.",
    "recent_traffic_lookback_days": "Window used by the 'traffic activity' filter to call a rule recently active. Default 30.",
    "default_owner_from_change_record": "Use the change task assignee as rule owner when no owner column exists. Default true.",
}

BOOL_FIELDS = {
    "require_business_approval_for_disable",
    "require_delete_approval",
    "require_disabled_evidence_for_delete",
    "expiry_data_expected",
    "expiry_unknown_forces_review",
    "default_owner_from_change_record",
}
INT_FIELDS = {"observation_days", "last_hit_age_threshold_days", "disable_monitoring_days", "min_keep_events", "min_log_coverage_days", "recent_traffic_lookback_days"}
FLOAT_FIELDS = {"traffic_frequency_low_per_day", "traffic_frequency_high_per_day"}


@dataclass
class Policy:
    observation_days: int = 90
    last_hit_age_threshold_days: int = 180
    disable_monitoring_days: int = 30
    min_keep_events: int = 1
    min_log_coverage_days: int = 30
    require_business_approval_for_disable: bool = True
    require_delete_approval: bool = True
    require_disabled_evidence_for_delete: bool = True
    traffic_frequency_low_per_day: float = 1.0
    traffic_frequency_high_per_day: float = 100.0
    expiry_data_expected: bool = False
    expiry_unknown_forces_review: bool = False
    recent_traffic_lookback_days: int = 30
    default_owner_from_change_record: bool = True

    @classmethod
    def from_dict(cls, data: dict | None) -> "Policy":
        merged = dict(DEFAULT_POLICY)
        if data:
            merged.update({k: v for k, v in data.items() if k in {f.name for f in fields(cls)}})
        clean: dict = {}
        for f in fields(cls):
            value = merged.get(f.name, getattr(cls(), f.name))
            if f.name in BOOL_FIELDS:
                if isinstance(value, str):
                    value = value.strip().lower() in {"1", "true", "yes", "on"}
                clean[f.name] = bool(value)
            elif f.name in INT_FIELDS:
                try:
                    clean[f.name] = int(value)
                except (TypeError, ValueError):
                    clean[f.name] = getattr(cls(), f.name)
            elif f.name in FLOAT_FIELDS:
                try:
                    clean[f.name] = float(value)
                except (TypeError, ValueError):
                    clean[f.name] = getattr(cls(), f.name)
            else:
                clean[f.name] = value
        # Guard-rails: never allow a policy that silently makes recommendations aggressive.
        clean["observation_days"] = max(7, min(730, clean["observation_days"]))
        clean["last_hit_age_threshold_days"] = max(clean["observation_days"], clean["last_hit_age_threshold_days"])
        clean["min_log_coverage_days"] = max(1, min(clean["observation_days"], clean["min_log_coverage_days"]))
        return cls(**clean)

    def to_dict(self) -> dict:
        return asdict(self)

    def describe(self) -> list[dict]:
        out = []
        for f in fields(self):
            out.append(
                {
                    "key": f.name,
                    "value": getattr(self, f.name),
                    "type": "bool" if f.name in BOOL_FIELDS else ("int" if f.name in INT_FIELDS else "float"),
                    "hint": POLICY_HINTS.get(f.name, ""),
                }
            )
        return out
