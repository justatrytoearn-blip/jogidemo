"""Firewall Rule Intelligence Platform - FastAPI application entry point."""
from __future__ import annotations

import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

from backend.ai import ollama_client
from backend.api import auth, dashboard, n8n, reports_api, rules, runs, settings_api, uploads
from backend.api.deps import ensure_admin_user
from backend.config import FRONTEND_DIST, LOG_DIR, Settings, load_policy
from backend.database.db import init_db, session_scope

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "platform.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("fip")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    with session_scope() as db:
        ensure_admin_user(db)
    log.info("Database initialised at startup")
    status = ollama_client.status()
    log.info("Ollama status: %s (%s)", status.available, status.message)
    yield
    log.info("Shutting down")


app = FastAPI(
    title="Firewall Rule Intelligence Platform",
    version=Settings.ENGINE_VERSION,
    description=(
        "Local firewall rule review and recommendation platform. Analysis and recommendation only - "
        "the platform never changes firewall configuration."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in (auth.router, uploads.router, runs.router, rules.router, dashboard.router, reports_api.router, settings_api.router, n8n.router):
    app.include_router(router)


@app.get("/api/health", tags=["health"])
def health():
    from datetime import datetime

    from backend.config import api_key, effective_ai_config

    cfg = effective_ai_config()
    status = ollama_client.status(cfg["url"], cfg["model"])
    try:
        with session_scope() as db:
            db.execute(__import__("sqlalchemy").text("SELECT 1"))
        db_ok = True
    except Exception:  # noqa: BLE001
        db_ok = False
    return {
        "status": "ok" if db_ok else "degraded",
        "time": datetime.utcnow().isoformat() + "Z",
        "database": db_ok,
        "ai": {"available": status.available, "model": cfg["model"], "message": status.message, "models": status.models},
        "n8n_key_configured": bool(api_key()),
        "auth_enabled": Settings.AUTH_ENABLED,
        "policy": load_policy(),
        "frontend_built": (FRONTEND_DIST / "index.html").exists(),
        "version": Settings.ENGINE_VERSION,
    }


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    log.exception("Unhandled error on %s", request.url.path)
    return JSONResponse(status_code=500, content={"detail": f"Internal error: {exc}"})


if (FRONTEND_DIST / "assets").exists():
    from fastapi.staticfiles import StaticFiles

    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="assets")


@app.get("/{full_path:path}", include_in_schema=False)
def spa(full_path: str):
    if full_path.startswith("api/"):
        return JSONResponse(status_code=404, content={"detail": "Not found"})
    index = FRONTEND_DIST / "index.html"
    if not index.exists():
        return JSONResponse(
            status_code=503,
            content={
                "detail": "Frontend has not been built yet. Run `npm install && npm run build` in frontend/, or use start.bat.",
                "api_docs": "/docs",
            },
        )
    candidate = (FRONTEND_DIST / full_path).resolve()
    if full_path and candidate.is_file() and str(candidate).startswith(str(FRONTEND_DIST.resolve())):
        return FileResponse(candidate)
    return FileResponse(index)
