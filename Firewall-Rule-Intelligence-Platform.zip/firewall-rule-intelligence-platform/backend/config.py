"""Central configuration and filesystem layout for the Firewall Rule Intelligence Platform."""
from __future__ import annotations

import json
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# FIP_DATA_DIR relocates all runtime data (uploads, processed caches, reports, DB).
# Tests use it to run against a throwaway directory instead of the live portal data.
DATA_DIR = Path(os.getenv("FIP_DATA_DIR", str(PROJECT_ROOT))).resolve()
UPLOAD_DIR = DATA_DIR / "uploads"
PROCESSED_DIR = DATA_DIR / "processed"
REPORT_DIR = DATA_DIR / "reports"
TEMPLATE_DIR = DATA_DIR / "templates"
LOG_DIR = DATA_DIR / "logs"
CONFIG_DIR = DATA_DIR / "config"
FRONTEND_DIST = DATA_DIR / "frontend" / "dist"
DB_DIR = DATA_DIR / "database"

for _d in (UPLOAD_DIR, PROCESSED_DIR, REPORT_DIR, TEMPLATE_DIR, LOG_DIR, CONFIG_DIR, DB_DIR):
    _d.mkdir(parents=True, exist_ok=True)

for _sub in ("firewall_rules", "change_records", "firewall_logs"):
    (UPLOAD_DIR / _sub).mkdir(parents=True, exist_ok=True)

SETTINGS_FILE = CONFIG_DIR / "settings.json"
DEFAULT_POLICY_FILE = CONFIG_DIR / "default_policy.json"


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def database_url() -> str:
    """SQLite by default; set DATABASE_URL to a PostgreSQL DSN to migrate."""
    return os.getenv("DATABASE_URL") or f"sqlite:///{(DB_DIR / 'fip.db').as_posix()}"


class Settings:
    """Runtime settings. Values can be overridden by env vars or the settings page."""

    APP_NAME = "Firewall Rule Intelligence Platform"
    ENGINE_VERSION = "1.0.0"

    # Networking / security
    HOST = os.getenv("FIP_HOST", "127.0.0.1")
    PORT = _env_int("FIP_PORT", 8080)
    AUTH_ENABLED = _env_bool("FIP_AUTH_ENABLED", False)
    SESSION_COOKIE = "fip_session"
    SESSION_TTL_HOURS = _env_int("FIP_SESSION_TTL_HOURS", 12)
    N8N_API_KEY = os.getenv("FIP_N8N_API_KEY", "")

    # Uploads
    MAX_UPLOAD_MB = _env_int("FIP_MAX_UPLOAD_MB", 512)
    MAX_LOG_ROWS = _env_int("FIP_MAX_LOG_ROWS", 20_000_000)
    CHUNK_SIZE = _env_int("FIP_CHUNK_SIZE", 200_000)

    # AI
    OLLAMA_URL = os.getenv("FIP_OLLAMA_URL", "http://127.0.0.1:11434")
    OLLAMA_MODEL = os.getenv("FIP_OLLAMA_MODEL", "qwen2.5:1.5b")
    AI_ENABLED = _env_bool("FIP_AI_ENABLED", True)
    AI_TIMEOUT = _env_int("FIP_AI_TIMEOUT", 180)
    AI_CONCURRENCY = _env_int("FIP_AI_CONCURRENCY", 2)
    AI_MAX_RULES = _env_int("FIP_AI_MAX_RULES", 400)

    LOG_FILE = LOG_DIR / "platform.log"

    @classmethod
    def to_dict(cls) -> dict:
        return {
            "app_name": cls.APP_NAME,
            "engine_version": cls.ENGINE_VERSION,
            "host": cls.HOST,
            "port": cls.PORT,
            "auth_enabled": cls.AUTH_ENABLED,
            "max_upload_mb": cls.MAX_UPLOAD_MB,
            "ollama_url": cls.OLLAMA_URL,
            "ollama_model": cls.OLLAMA_MODEL,
            "ai_enabled": cls.AI_ENABLED,
        }


DEFAULT_POLICY: dict = {
    "observation_days": 90,
    "last_hit_age_threshold_days": 180,
    "disable_monitoring_days": 30,
    "min_keep_events": 1,
    "min_log_coverage_days": 30,
    "require_business_approval_for_disable": True,
    "require_delete_approval": True,
    "require_disabled_evidence_for_delete": True,
    "traffic_frequency_low_per_day": 1.0,
    "traffic_frequency_high_per_day": 100.0,
    "expiry_data_expected": False,
    "expiry_unknown_forces_review": False,
    "recent_traffic_lookback_days": 30,
    "default_owner_from_change_record": True,
}


def load_policy() -> dict:
    """Effective policy = defaults, overridden by config/default_policy.json and config/settings.json."""
    policy = dict(DEFAULT_POLICY)
    if DEFAULT_POLICY_FILE.exists():
        try:
            policy.update(json.loads(DEFAULT_POLICY_FILE.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            pass
    if SETTINGS_FILE.exists():
        try:
            stored = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            policy.update(stored.get("policy", {}))
        except (json.JSONDecodeError, OSError):
            pass
    return policy


def load_settings_overrides() -> dict:
    if SETTINGS_FILE.exists():
        try:
            return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_settings(overrides: dict) -> None:
    SETTINGS_FILE.write_text(json.dumps(overrides, indent=2), encoding="utf-8")


def get_setting(key: str, default=None):
    return load_settings_overrides().get(key, default)


def effective_ai_config() -> dict:
    """Settings page values win over environment defaults."""
    overrides = load_settings_overrides()
    return {
        "enabled": bool(overrides.get("ai_enabled", Settings.AI_ENABLED)),
        "url": overrides.get("ollama_url", Settings.OLLAMA_URL),
        "model": overrides.get("ollama_model", Settings.OLLAMA_MODEL),
        "timeout": int(overrides.get("ai_timeout", Settings.AI_TIMEOUT)),
        "max_rules": int(overrides.get("ai_max_rules", Settings.AI_MAX_RULES)),
    }


def api_key() -> str:
    """Key n8n must present. Generated once and persisted; never hardcoded."""
    key_file = CONFIG_DIR / "n8n_api_key.txt"
    if Settings.N8N_API_KEY:
        return Settings.N8N_API_KEY
    if key_file.exists():
        return key_file.read_text(encoding="utf-8").strip()
    import secrets

    key = secrets.token_urlsafe(32)
    key_file.write_text(key, encoding="utf-8")
    return key
