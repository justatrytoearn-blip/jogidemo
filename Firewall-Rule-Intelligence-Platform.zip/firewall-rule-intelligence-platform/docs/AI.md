# Where and how AI is used

AI is a **reviewer's assistant**, not the decision maker. Every KEEP/REVIEW/DISABLE/DELETE
decision is computed from the uploaded evidence by the deterministic policy engine. The local
model only turns that evidence into readable narrative, and its output is validated before it
is stored. It cannot change a category, and no data leaves the machine.

## 1. The exact AI touch points

| Where | Trigger | Code | What the model receives | What it produces |
|---|---|---|---|---|
| Rule detail → Section D | **Generate / Regenerate narration** | `backend/services/ai_jobs.py: generate_single` → `backend/ai/reviewer.py: explain_rule` | one rule's own fields, measured traffic, linked changes, policy decision and blockers | five short fields: reason, business_impact, technical_impact, next_action, caveats |
| Full-review job / n8n AI workflow | automatically when a run is created with AI enabled | `ai_jobs.generate_for_run` | the same evidence for up to `ai_limit` rules, prioritised DELETE → DISABLE → REVIEW → KEEP | stored narration per rule, generation/validation flags, model name |
| Executive summary | after batch narration / dashboard | `reviewer.executive_summary` | aggregate run statistics and policy only | 120-word plain-text summary |
| AI review workflow (WF-04) | manual/webhook | `POST /api/n8n/ai/{run_id}` | same as batch | queues the same narration job |

AI is **not** used for: file parsing, column mapping, rule matching, traffic aggregation,
change linking, recommendation category, risk scoring, approval status, report tables or any
firewall action. Those are deterministic Python/SQL calculations.

## 2. What the prompt contains

For each rule the prompt is built from:

- rule number, name, section, action, source, destination, service;
- matching log events in the observation window, total matching events, observation days, log
  coverage days, first/last seen, days since last hit, average per day, trend, match method;
- linked change count, documented yes/no, owner, change request/task, state, conflict flag;
- policy decision, risk, confidence, trigger codes and missing-evidence codes.

Deliberately excluded:

- **inventory `hit_count`** — it is a count of inventory references, not log events, and small
  models confuse the two;
- raw log rows and unrelated rules;
- credentials, hostnames outside the evidence, customer file paths.

The prompt is wrapped in an `EVIDENCE FACTS` block that repeats every number the model may
cite, followed by a JSON context. The system prompt forbids inventing identifiers and states
that a deterministic engine already chose the recommendation.

## 3. Validation guardrails

Before storing a response, `backend/ai/reviewer.py: _validate` rejects it when:

1. it proposes a different category (e.g. REVIEW when the engine said KEEP);
2. it contains an IP address not present in the evidence;
3. it claims "no hits/traffic/activity" when matching events were measured;
4. it calls a rule active when zero events matched;
5. it claims documentation when no documented change record exists.

A rejected response keeps the deterministic explanation; the rule is still displayed in the
correct category with `ai_generated: false` and the rejection reason. There is one retry with
a shorter budget. Tests cover these guards in `tests/test_ai_validation.py`.

The executive summary has its own guard: it rejects invented IPs and unusable output and
falls back to a deterministic summary.

## 4. Model selection

The model is **not hardcoded**:

- **Portal:** Policy & Settings → Local AI → Model field. It lists installed Ollama models and
  accepts a typed name. **Refresh** re-reads the list; **Test this model (before saving)** sends
  a live prompt using the unsaved model/URL; **Save AI settings** makes it the default.
- **Per run:** the single n8n prompt accepts `model: <name>`, recorded in the run statistics.
  A production run can use a larger model without changing the portal default.
- **Configuration:** `FIP_OLLAMA_MODEL`, `FIP_OLLAMA_URL`, `FIP_AI_ENABLED`, `FIP_AI_TIMEOUT`.
- **Install a model:** `ollama pull qwen2.5:3b`.

Tested models on the CPU-only demo machine: `qwen2.5:0.5b` (fastest), `qwen2.5:1.5b`
(default, ~10 s/rule), `qwen2.5:3b` (slower; installed but not used by default). The demo can
use `ai_limit` to cap narration to a few rules.

## 5. Why this is safe and honest

- The model cannot select or alter the recommendation; the policy engine writes it first.
- The model cannot see raw log rows or other rules, limiting accidental disclosure.
- Every claim is checked against the supplied facts.
- Narration is marked with `generated`, `validated`, `model` and `grounded_on` fields so a
  reviewer can see exactly what was model-written.
- If Ollama is unavailable, the platform still works: deterministic explanations remain.
- No paid API is used and no external network call is made by the AI layer.

## 6. Cost and performance

AI cost is local compute only. A batch is bounded by `ai_limit`/`ai_max_rules`, prioritised by
risk, and runs in the background with configurable concurrency. On CPU expect roughly 5–15
seconds per rule with 1.5B; the demo uses 4–8 narrations for a meeting. Reports and analysis do
not wait for AI; the full-review job runs AI before reports so its completion means everything
is ready.
