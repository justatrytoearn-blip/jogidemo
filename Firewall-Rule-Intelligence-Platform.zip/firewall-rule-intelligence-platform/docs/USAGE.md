# Usage guide

## 1. Load the three inputs

Open **File Upload Centre** at http://127.0.0.1:8080.

1. **Firewall inventory** — `.xlsx`, `.csv`, `.json` or `.jsonl`. The importer detects the
   header row, skips Section rows and maps columns automatically. Check the 20-row preview,
   correct any mapping, then confirm.
2. **ServiceNow change records** — CSV with `Number`, `State`, `Assigned to`,
   `Short description`, `Planned end date`, `Change request`. Change links can also come from
   the `Rule_Change_Relationship` sheet in the inventory workbook.
3. **Firewall logs** — CSV, JSONL, JSON or raw text. The file is streamed, never loaded whole,
   and cached as gzip JSONL. Existing uploads with the same name are replaced, originals are
   kept.

Every upload is validated and recorded in the audit trail.

## 2. Run the analysis

Click **Upload & Analyse**. A run moves through five stages visible on the **Runs** page:

1. ingest and normalise
2. correlate rules ↔ change records ↔ logs
3. calculate per-rule traffic over the observation window
4. local AI narration (if enabled)
5. Excel/PDF report generation

The recommendation itself is computed deterministically at stage 3. AI at stage 4 only writes
the explanation and is validated against the engine result.

## 3. Read the dashboard

The executive dashboard shows 14 clickable metrics and 8 charts. Every card links to the
matching filtered rule list. The charts cover recommendation mix, risk, traffic frequency,
sections, Accept/Drop composition, change coverage, daily traffic and the top rules by real
log events.

Inventory hit counters are displayed separately and are never used as log event counts.

## 4. Review and accept rules

Open **Firewall Rule Review**:

- filter by recommendation, traffic state, risk, owner, expiry, change record/state, last hit
  or AI status;
- sort any column; paginate server-side;
- tick rules to export or re-review as a batch;
- click a rule name for sections A–D.

**Accept a rule:** each row has an **Accept** button. The rule detail page has
**Accept recommendation**. Acceptance stores a `review_accepted` record with reviewer, time
and note in the audit trail. It does not change the KEEP/REVIEW/DISABLE/DELETE category.

**Move a rule to DISABLE or DELETE:** use the approval buttons on the rule detail page:

- business confirmation → a REVIEW rule that qualifies for DISABLE can become DISABLE;
- deletion approval + obsolescence confirmation + disable/monitoring evidence → DELETE.

The platform never performs a firewall change. These are decision records only.

## 5. Reports

Open **Reports** after a run completes. Generate the complete review, one workbook per
recommendation, missing-information, no-change-history, zero-traffic and executive reports in
Excel and PDF. The complete workbook contains 28+ traceability columns including source file,
sheet, row, matching method, confidence and policy trigger codes.

## 6. Single-prompt n8n review

Open http://127.0.0.1:5679/form/fip/review-form and enter a prompt, for example:

```
demo label: Customer weekly review model: qwen2.5:1.5b ai_limit: 20
```

The workflow starts the review, polls until the analysis, AI and reports finish, and returns
counts plus links to the dashboard, rule list and reports. To review real files already in
`uploads/`:

```
label: Production review
rules: uploads/firewall_rules/inventory.xlsx
changes: uploads/change_records/changes.csv
logs: uploads/firewall_logs/logs.csv
model: qwen2.5:3b
```

Or call the webhook:

```bash
curl -X POST http://127.0.0.1:5679/webhook/fip/review \
  -H "Content-Type: application/json" \
  -d '{"prompt":"demo label: API demo model: qwen2.5:1.5b ai_limit: 8"}'
```

Direct backend equivalent (requires the n8n API key):

```bash
curl -X POST http://127.0.0.1:8080/api/n8n/full-review \
  -H "X-API-Key: <key>" -H "Content-Type: application/json" \
  -d '{"prompt":"demo label: Direct demo"}'

curl -H "X-API-Key: <key>" http://127.0.0.1:8080/api/n8n/full-review/6
```

## 7. Chat demo from n8n (no editor)

Open **http://127.0.0.1:5679/webhook/fip-chat/chat**.

Type `demo` to run the whole fictional review from the chat. The answer includes the run id,
KEEP/REVIEW/DISABLE/DELETE counts, matched log events, AI/model, report count and portal
links. Operational commands:

| Command | Purpose |
|---|---|
| `help` | list commands and examples |
| `models` | show installed Ollama models and current default |
| `connection` | backend, portal, Ollama and model status |
| `set model <name>` | change the default model for future runs |
| `test model <name>` | live test without changing the default |
| `status <run_id>` | status and counts for an existing run |
| `no ai`, `no reports` | faster demo |

You can combine a review prompt with model control, for example:
`demo label: Customer demo model: qwen2.5:0.5b ai_limit: 2`.

## 8. Change the AI model

**Policy & Settings → Local AI:**

1. The Model field lists installed models and accepts a typed name.
2. **Refresh** re-reads Ollama.
3. **Test this model (before saving)** checks the unsaved model and URL.
4. **Save AI settings** makes it the default for new narrations.

For a one-off model in n8n, add `model: <name>` to the prompt. It is recorded in the run
statistics and does not alter the portal default.

## 9. Run history and comparison

**Runs** lists every analysis with status, stage, counts and source files. Select two completed
runs to compare new/removed/changed rules, recommendation changes, traffic deltas and newly
linked change records. Each run keeps the policy that was active when it ran, so historical
reports remain reproducible.

## 10. What "REVIEW" means

REVIEW is the safe default. It covers missing change records, missing owners, expired rules,
zero traffic without approval, and logs that do not share the inventory's identity space.
Zero traffic alone never triggers DISABLE or DELETE.
