# Installation guide

This platform runs entirely on one Windows machine. The API, database and portal are one
Python process; n8n is an optional Docker service; Ollama is an optional local model server.
No customer data leaves the machine.

## 1. What must be installed first

| Software | Needed for | Notes |
|---|---|---|
| Python 3.10+ | API, analysis, reports | Tested on 3.14.7 |
| Ollama | AI narration only | The platform works fully without it |
| Docker Desktop | n8n orchestration only | Not needed for uploads, analysis or reports |
| Node.js 18+ | rebuilding the portal | Not needed to run: the built `frontend/dist` is included |

These are **not** installed automatically. Confirm them with:

```bat
python --version
ollama --version
docker --version
node --version
```

## 2. Install the platform

From the project folder:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Create the database once (it is created automatically on first start as well):

```bat
python -c "from backend.database.db import init_db; init_db()"
```

If you received the ZIP, the portal build is already in `frontend/dist`; you do not need Node
unless you change frontend source. To rebuild it:

```bat
cd frontend
npm install
npm run build
cd ..
```

## 3. Start and stop

```bat
start.bat
```

`start.bat` starts the API at http://127.0.0.1:8080, waits for it, starts n8n at
http://127.0.0.1:5679 if Docker is available, and opens the portal.

```bat
health_check.bat   :: API, portal, n8n, Ollama, database
stop.bat           :: stop API and n8n
```

## 4. Local AI (optional)

Install a small model once:

```bat
ollama pull qwen2.5:1.5b
ollama serve
```

The default is `qwen2.5:1.5b`. In the portal go to **Policy & Settings → Local AI** to choose
any installed model, type another model name, refresh the list, or test a model before saving.
A single n8n run can also use a different model without changing the default.

## 5. n8n workflows (optional)

n8n runs in its own container named `fip-n8n` on port 5679. It does not touch any other n8n
instance on port 5678.

```bat
cd n8n
docker compose up -d
cd ..
```

The backend API key is generated in `config/n8n_api_key.txt` and is also set in `n8n/.env`
for the container. To import or refresh the eight workflows:

```bat
docker exec fip-n8n n8n import:workflow --separate --input=/workflows
docker exec fip-n8n n8n update:workflow --id=fip-wf-00 --active=true
docker restart fip-n8n
```

`FIP - 00 Full Review (one prompt)` is the single workflow that runs the whole review.
`FIP - Chat Demo & Model Control` serves the hosted chat at
http://127.0.0.1:5679/webhook/fip-chat/chat and can run the demo plus model/connection
commands. Activate it with:

```bat
docker exec fip-n8n n8n update:workflow --id=fip-wf-chat --active=true
docker restart fip-n8n
```

The other six workflows expose each stage separately for automation. `setup.bat` activates
all of them, including the chat workflow.

## 6. First verification

1. Open http://127.0.0.1:8080.
2. Open http://127.0.0.1:8080/docs and confirm `/api/health` returns `"status": "ok"`.
3. Run `health_check.bat`: API, portal, n8n and Ollama should be reported.
4. Open the n8n form at http://127.0.0.1:5679/form/fip/review-form and submit
   `demo label: First demo` to run the complete demo.

## 7. Configuration

| Variable | Default | Purpose |
|---|---|---|
| `FIP_PORT` | `8080` | API/portal port |
| `FIP_HOST` | `127.0.0.1` | Bind address, localhost only by default |
| `FIP_AUTH_ENABLED` | `false` | Optional session login |
| `FIP_OLLAMA_URL` | `http://127.0.0.1:11434` | Local Ollama endpoint |
| `FIP_OLLAMA_MODEL` | `qwen2.5:1.5b` | Default narration model |
| `FIP_AI_ENABLED` | `true` | Disable narration entirely |
| `FIP_MAX_UPLOAD_MB` | `512` | Upload limit |
| `DATABASE_URL` | SQLite in `database/fip.db` | PostgreSQL-ready DSN |
| `FIP_N8N_API_KEY` | generated file | Protects `/api/n8n/*` |

Settings saved in the portal override these defaults for AI and policy.

## 8. Security notes

- The API binds to `127.0.0.1`; n8n binds to `127.0.0.1:5679`.
- No paid API is called. AI is local Ollama only.
- Uploads are stored untouched under `uploads/`; runtime data is excluded from git.
- `config/n8n_api_key.txt`, `config/admin_credentials.txt` and `n8n/.env` are secrets and are
  git-ignored.
- This platform never changes a firewall. All actions remain recommendations for change
  management.

## 9. Troubleshooting

| Symptom | Check | Fix |
|---|---|---|
| Port 8080 busy | `netstat -ano \| findstr 8080` | `stop.bat`, close the other process |
| API exits | `logs/uvicorn-live.log`, `logs/platform.log` | Activate `.venv`, reinstall requirements |
| Portal shows a blank page | `frontend/dist/index.html` exists | Rebuild the frontend or restore `dist` |
| n8n 404 on webhook | `docker ps`, `n8n list:workflow` | Start container, activate `fip-wf-00` |
| n8n cannot reach API | `docker exec fip-n8n wget -qO- http://host.docker.internal:8080/api/health` | Start the API; keep it on port 8080 |
| AI disabled | `/api/health` → `ai.available` | Start Ollama and pull the model |
| Model not installed | Settings → Refresh | `ollama pull <model>` |
| All REVIEW on real files | Run stats → identity space | Supply logs from the same firewall estate |
| Report missing | Reports page / `reports/` | Generate after the run completes |

## 10. Uninstall / reset

Stop the services, then delete `database/fip.db`, `uploads/`, `processed/`, `reports/` and
`logs/` to return to a clean install. Keep `config/` if you want to retain the API key and
policy. The demo files are regenerated on demand.
