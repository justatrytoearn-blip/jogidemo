"""AI guardrails: model text may explain, never contradict, the deterministic decision."""
from __future__ import annotations

import json

from backend.ai.reviewer import _validate


def context(events: int = 25, documented: bool = True) -> str:
    return json.dumps(
        {
            "traffic_evidence": {"events_in_window": events, "matching_log_events": events, "observation_days": 90},
            "change_evidence": {"documented": documented, "linked_records": 1},
        }
    )


REC = {"category": "KEEP", "risk_level": "Low", "confidence": "High"}


def fields(**overrides) -> dict:
    base = {
        "reason": "25 matching log events were observed in the 90-day window and the change is documented.",
        "business_impact": "None identified from the evidence.",
        "technical_impact": "Traffic continues to match this rule.",
        "next_action": "Keep the rule and review at the next cycle.",
        "caveats": "None.",
    }
    base.update(overrides)
    return base


def test_grounded_narration_is_accepted():
    valid, warnings = _validate(fields(), REC, context())
    assert valid, warnings


def test_category_change_is_rejected():
    valid, _ = _validate(fields(next_action="You should change to DISABLE this rule."), REC, context())
    assert not valid


def test_invented_ip_is_rejected():
    valid, _ = _validate(fields(reason="Traffic from 203.0.113.99 was observed."), REC, context())
    assert not valid


def test_no_traffic_claim_when_events_exist_is_rejected():
    valid, _ = _validate(fields(reason="The rule has no hits and is not triggering."), REC, context())
    assert not valid


def test_claiming_activity_with_zero_events_is_rejected():
    rec = dict(REC, category="REVIEW")
    valid, _ = _validate(fields(reason="The rule is actively used."), rec, context(events=0))
    assert not valid


def test_false_documentation_claim_is_rejected():
    valid, _ = _validate(fields(reason="The change is documented."), REC, context(documented=False))
    assert not valid


def test_stating_that_evidence_is_missing_is_allowed():
    valid, warnings = _validate(
        fields(reason="No change record is documented, so the policy keeps this rule in REVIEW."),
        dict(REC, category="REVIEW"),
        context(documented=False),
    )
    assert valid, warnings
