"""Rule matching hierarchy and change-link behaviour."""
from __future__ import annotations

from backend.services.correlation import RuleIndex, RuleRef, link_changes


def ref(index, uid="", number="", name="", device="") -> RuleRef:
    return RuleRef(index=index, rule_uid=uid, rule_number=number, rule_name=name, device=device, section="", comments="")


def test_uid_match_wins():
    index = RuleIndex([ref(0, uid="abc-1", number="10", name="alpha"), ref(1, uid="abc-2", number="11", name="beta")])
    resolved, method, confidence, _ = index.resolve("abc-2", "10", "alpha", "")
    assert resolved == 1
    assert method == "rule_uid"
    assert confidence == 1.0


def test_number_and_device_match():
    index = RuleIndex([ref(0, uid="a", number="5", name="one", device="fw-01"), ref(1, uid="b", number="5", name="two", device="fw-02")])
    resolved, method, _, note = index.resolve("", "5", "", "fw-02")
    assert resolved == 1
    assert method == "rule_number+device"
    assert "device" in note.lower()


def test_device_mismatch_is_not_forced():
    index = RuleIndex([ref(0, uid="a", number="5", name="one", device="fw-01")])
    resolved, method, _, _ = index.resolve("", "5", "", "fw-09")
    assert resolved is None
    assert method == "device_mismatch"


def test_similar_names_are_never_merged():
    index = RuleIndex(
        [
            ref(0, uid="a", number="1", name="Allow Web"),
            ref(1, uid="b", number="2", name="Allow Web 2"),
        ]
    )
    assert index.resolve("", "", "Allow Web", "")[0] == 0
    assert index.resolve("", "", "Allow Web 2", "")[0] == 1
    assert index.resolve("", "", "Allow Web*", "")[0] is None


def test_duplicate_name_is_ambiguous():
    index = RuleIndex([ref(0, uid="a", number="1", name="same"), ref(1, uid="b", number="2", name="same")])
    resolved, method, _, _ = index.resolve("", "", "same", "fw-01")
    assert resolved is None
    assert method == "ambiguous_name"


def test_changes_link_by_uid_and_number():
    rules = [ref(0, uid="u-1", number="10", name="alpha", device="fw-01"), ref(1, uid="u-2", number="11", name="beta", device="fw-01")]
    changes = [
        {"chg_number": "CHG1", "ctask_number": "CT1", "rule_uid": "u-1", "rule_number": "", "rule_name": "", "device": "", "state": "Closed", "short_description": "x", "assigned_to": "a@b", "planned_start": None, "planned_end": None},
        {"chg_number": "CHG2", "ctask_number": "CT2", "rule_uid": "", "rule_number": "11", "rule_name": "beta", "device": "fw-01", "state": "Closed", "short_description": "y", "assigned_to": "c@d", "planned_start": None, "planned_end": None},
    ]
    links, summaries, stats = link_changes(rules, changes)
    assert {link.rule_index for link in links} == {0, 1}
    assert stats["rules_with_changes"] == 2
    assert summaries[0].documented is True
    assert summaries[0].owner == "a@b"
