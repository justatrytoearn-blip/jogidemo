"""Test bootstrap: run everything against a throwaway data directory.

The live portal data (uploads/, processed/, reports/, database/fip.db) is never touched.
FIP_DATA_DIR and DATABASE_URL must be set before any backend module is imported, hence
this module-level block rather than a fixture.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TEST_DATA_DIR = Path(tempfile.mkdtemp(prefix="fip-tests-"))

os.environ["FIP_DATA_DIR"] = str(TEST_DATA_DIR)
os.environ["DATABASE_URL"] = f"sqlite:///{(TEST_DATA_DIR / 'test.db').as_posix()}"
os.environ["FIP_AI_ENABLED"] = "false"
os.environ["FIP_AUTH_ENABLED"] = "false"

SAMPLES = PROJECT_ROOT / "samples"
RULES_XLSX = SAMPLES / "firewall_rule_list_POC_200_Rules.xlsx"
CHANGES_XLSX = SAMPLES / "change_task_POC_200_Entries.xlsx"
LOGS_XLSX = SAMPLES / "Logs_Nov_5_2026_Firewall_POC_2000_Entries.xlsx"
SYNTHETIC_LOGS = SAMPLES / "synthetic" / "synthetic_firewall_logs.csv"


def pytest_sessionfinish(session, exitstatus):  # noqa: ARG001
    shutil.rmtree(TEST_DATA_DIR, ignore_errors=True)


def upload(db, dataset_type: str, path: Path, synthetic: bool):
    from backend.services import import_service

    with open(path, "rb") as fh:
        record = import_service.create_upload(db, dataset_type, path.name, fh, is_synthetic=synthetic)
    stored = json.loads(record.mapping_json or "{}")
    mapping = {k: v for k, v in stored.get("mapping", {}).items() if v}
    return import_service.confirm_mapping(db, record.id, mapping, record.sheet_name)


@pytest.fixture(scope="session")
def db():
    from backend.database import db as db_module

    db_module.init_db()
    with db_module.session_scope() as session:
        yield session


@pytest.fixture(scope="session")
def runs(db):
    """One run on the real samples and one on the labelled synthetic log file."""
    from backend.services.analysis import create_run, execute_run

    real_rules = upload(db, "rules", RULES_XLSX, False)
    real_changes = upload(db, "changes", CHANGES_XLSX, False)
    real_logs = upload(db, "logs", LOGS_XLSX, False)
    real_run = create_run(db, real_rules.id, real_changes.id, real_logs.id, "TEST real samples", ai_enabled=False)
    real_stats = execute_run(real_run.id)

    syn_rules = upload(db, "rules", RULES_XLSX, False)
    syn_changes = upload(db, "changes", CHANGES_XLSX, False)
    syn_logs = upload(db, "logs", SYNTHETIC_LOGS, True)
    syn_run = create_run(db, syn_rules.id, syn_changes.id, syn_logs.id, "TEST synthetic logs", ai_enabled=False)
    syn_stats = execute_run(syn_run.id)
    return {"real": (real_run.id, real_stats), "synthetic": (syn_run.id, syn_stats)}


@pytest.fixture(scope="session")
def app_client():
    from fastapi.testclient import TestClient

    from backend.main import app

    with TestClient(app) as client:
        yield client
