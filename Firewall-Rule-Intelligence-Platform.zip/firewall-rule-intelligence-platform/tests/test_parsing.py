"""Parsing and normalisation of the supplied workbook formats."""
from __future__ import annotations

from datetime import date, datetime

import pandas as pd
import pytest

from backend.analytics.traffic import _parse_timestamps
from backend.services.normalize import normalize_action, parse_datetime, parse_int


def test_inventory_hit_text_is_parsed():
    assert parse_int("Medium (number of hits: 45)") == 45
    assert parse_int("High (number of hits: 0)") == 0
    assert parse_int("") is None
    assert parse_int("not a number") is None


def test_day_first_and_iso_dates_both_parse():
    # The inventory uses day-first dates; logs use ISO. Pandas' mixed parser must not
    # reinterpret ISO values as day-first (2026-11-06 must stay 6 November).
    assert parse_datetime("06/11/2026") == datetime(2026, 11, 6)
    assert parse_datetime("2026-11-06") == datetime(2026, 11, 6)
    assert parse_datetime("2026-11-06 07:31:59") == datetime(2026, 11, 6, 7, 31, 59)
    assert parse_datetime("") is None


def test_timestamp_series_keeps_iso_day_and_month():
    series = pd.Series(["2026-11-06", "2026-01-02 10:00:00", "06/11/2026", ""])
    parsed = _parse_timestamps(series)
    assert parsed.iloc[0].date() == date(2026, 11, 6)
    assert parsed.iloc[1].date() == date(2026, 1, 2)
    assert parsed.iloc[2].date() == date(2026, 11, 6)
    assert pd.isna(parsed.iloc[3])


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("Accept", "Accept"),
        ("accept", "Accept"),
        ("ALLOW", "Accept"),
        ("Deny", "Drop"),
        ("drop", "Drop"),
        ("Reject", "Drop"),
        ("", ""),
    ],
)
def test_action_normalisation(raw, expected):
    assert normalize_action(raw) == expected


def test_supplied_workbooks_parse_with_expected_sections():
    """The POC inventory contains section headings that must not become rules."""
    from pathlib import Path

    from backend.services.import_service import _sheet_analyses

    path = Path(__file__).resolve().parent.parent / "samples" / "firewall_rule_list_POC_200_Rules.xlsx"
    analyses = _sheet_analyses(path, "xlsx", "rules")
    assert analyses
    best = max(analyses, key=lambda a: a["score"])
    assert best["mapping"].get("rule_name")
    assert best["mapping"].get("rule_uid")
