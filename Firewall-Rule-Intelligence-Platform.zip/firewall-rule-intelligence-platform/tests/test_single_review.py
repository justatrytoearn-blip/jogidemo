"""Tests for the single-prompt review entry point and the demo dataset contract."""
from __future__ import annotations

from backend.api.n8n import _parse_prompt
from backend.services import demo_data


def test_prompt_parses_all_supported_keys():
    parsed = _parse_prompt(
        "demo  label: Customer demo\n"
        "model: qwen2.5:3b\n"
        "ai_limit: 5\n"
        "no ai"
    )
    assert parsed["demo"] is True
    assert parsed["label"] == "Customer demo"
    assert parsed["model"] == "qwen2.5:3b"
    assert parsed["ai_limit"] == "5"
    assert parsed["ai"] is False


def test_prompt_accepts_structured_json():
    parsed = _parse_prompt('{"rules_path": "rules.xlsx", "logs_path": "logs.csv", "label": "Weekly"}')
    assert parsed["rules_path"] == "rules.xlsx"
    assert parsed["logs_path"] == "logs.csv"
    assert parsed["label"] == "Weekly"


def test_demo_files_keep_customer_headers(tmp_path, monkeypatch):
    monkeypatch.setattr(demo_data, "DEMO_DIR", tmp_path)
    monkeypatch.setattr(demo_data, "RULES_FILE", tmp_path / "rules.xlsx")
    monkeypatch.setattr(demo_data, "CHANGES_FILE", tmp_path / "changes.xlsx")
    monkeypatch.setattr(demo_data, "LOGS_FILE", tmp_path / "logs.csv")
    monkeypatch.setattr(demo_data, "MANIFEST_FILE", tmp_path / "manifest.json")

    import pandas as pd

    files = demo_data.ensure_demo_files(force=True)
    rules = pd.read_excel(files["rules"], sheet_name="FW-Corp 11")
    changes = pd.read_excel(files["changes"], sheet_name="Page 1")
    logs = pd.read_csv(files["logs"])

    assert list(rules.columns) == demo_data.RULE_HEADERS
    assert list(changes.columns) == demo_data.CHANGE_HEADERS
    assert list(logs.columns) == demo_data.LOG_HEADERS
    assert len(rules[rules["Type"] == "Rule"]) == sum(s[1] for s in demo_data.SCENARIOS)
    assert (rules["Type"] == "Section").sum() >= 4
    assert not logs.empty
