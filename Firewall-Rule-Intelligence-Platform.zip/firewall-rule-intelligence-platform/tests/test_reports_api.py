"""Report generation and HTTP API smoke tests."""
from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook


def test_excel_and_pdf_reports_are_generated(runs, db):
    from backend.reports.excel_export import build_excel
    from backend.reports.pdf_export import build_pdf

    run_id, _ = runs["synthetic"]
    excel_path, excel_rows = build_excel(db, run_id, "full")
    assert excel_rows == 200
    assert Path(excel_path).exists() and Path(excel_path).stat().st_size > 5000

    workbook = load_workbook(excel_path, read_only=True)
    headers: list = []
    for sheet_name in workbook.sheetnames:
        for row in workbook[sheet_name].iter_rows(min_row=1, max_row=15, values_only=True):
            if row and any("Rule UID" in str(cell or "") for cell in row):
                headers = list(row)
                break
        if headers:
            break
    assert len([h for h in headers if h]) >= 28, headers

    pdf_path, pdf_rows = build_pdf(db, run_id, "executive")
    assert pdf_rows == 200
    assert Path(pdf_path).exists() and Path(pdf_path).stat().st_size > 1000


def test_all_report_kinds_generate(runs, db):
    from backend.reports.excel_export import build_excel

    run_id, _ = runs["synthetic"]
    for kind in ("keep", "review", "disable", "delete", "missing_info", "no_change", "zero_traffic", "executive"):
        path, rows = build_excel(db, run_id, kind)
        assert Path(path).exists(), kind
        assert rows >= 0


def test_api_smoke(runs, app_client):
    run_id, _ = runs["synthetic"]

    health = app_client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"

    runs_response = app_client.get("/api/runs")
    assert runs_response.status_code == 200
    assert any(item["id"] == run_id for item in runs_response.json()["items"])

    dashboard = app_client.get(f"/api/dashboard?run_id={run_id}")
    assert dashboard.status_code == 200
    assert len(dashboard.json()["cards"]) == 14

    rules = app_client.get(f"/api/rules?run_id={run_id}&page=1&page_size=10")
    assert rules.status_code == 200
    payload = rules.json()
    assert payload["total"] == 200
    assert len(payload["items"]) == 10
    rule_id = payload["items"][0]["id"]

    detail = app_client.get(f"/api/rules/{rule_id}")
    assert detail.status_code == 200
    assert detail.json()["rule"]["id"] == rule_id

    traffic = app_client.get(f"/api/rules/{rule_id}/traffic")
    assert traffic.status_code == 200

    reports = app_client.get(f"/api/reports?run_id={run_id}")
    assert reports.status_code == 200

    policy = app_client.get("/api/settings/policy")
    assert policy.status_code == 200
    assert policy.json()["policy"]["observation_days"] >= 7

    comparison = app_client.get(f"/api/runs/{run_id}/comparison?base_run_id={runs['real'][0]}")
    assert comparison.status_code == 200
