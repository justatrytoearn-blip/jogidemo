"""Recommendation gates: all four categories and the conservative defaults."""
from __future__ import annotations

from datetime import datetime, timedelta

from backend.recommendation_engine.engine import evaluate
from backend.recommendation_engine.policy import Policy

POLICY = Policy()
NOW = datetime(2026, 11, 13, 12, 0, 0)


def rule(**overrides) -> dict:
    base = {
        "rule_uid": "uid-1",
        "rule_number": "10",
        "rule_name": "Allow payment gateway",
        "device": "fw-01",
        "source": "10.0.0.1",
        "destination": "10.0.0.2",
        "service": "tcp_443",
        "action": "Accept",
        "hit_count": 42,
        "last_hit": NOW - timedelta(days=2),
        "owner_hint": "",
        "expiry_date": None,
    }
    base.update(overrides)
    return base


def traffic(**overrides) -> dict:
    base = {
        "matched": True,
        "logs_supplied": True,
        "absence_is_evidence": True,
        "log_coverage_days": 330,
        "observation_days": 90,
        "window_event_count": 25,
        "days_since_last_hit": 2,
        "last_seen": NOW - timedelta(days=2),
    }
    base.update(overrides)
    return base


def change(**overrides) -> dict:
    base = {
        "record_count": 1,
        "records": [{"number": "CHG001"}],
        "documented": True,
        "owner": "owner@example.com",
        "conflicting": False,
        "notes": [],
    }
    base.update(overrides)
    return base


def test_keep_needs_traffic_change_owner_and_validity():
    result = evaluate(rule(), traffic(), change(), POLICY, now=NOW)
    assert result["category"] == "KEEP"
    codes = {t["code"] for t in result["triggers"]}
    assert {"RECENT_TRAFFIC", "CHANGE_DOCUMENTED", "OWNER_KNOWN"} <= codes


def test_missing_log_evidence_is_review_not_disable():
    result = evaluate(
        rule(),
        traffic(matched=False, logs_supplied=False, absence_is_evidence=False, window_event_count=0, days_since_last_hit=None, last_seen=None),
        change(),
        POLICY,
        now=NOW,
    )
    assert result["category"] == "REVIEW"
    assert "NO_LOG_EVIDENCE" in {m["code"] for m in result["missing"]}


def test_zero_traffic_alone_never_disables():
    # Zero events in the window, but the last hit is recent -> stale rule evidence is absent.
    result = evaluate(
        rule(),
        traffic(window_event_count=0, days_since_last_hit=10, last_seen=NOW - timedelta(days=10)),
        change(),
        POLICY,
        now=NOW,
    )
    assert result["category"] == "REVIEW"


def test_disable_requires_business_confirmation():
    stale_rule = rule(hit_count=5)
    stale_traffic = traffic(
        window_event_count=0,
        days_since_last_hit=220,
        last_seen=NOW - timedelta(days=220),
    )
    without = evaluate(stale_rule, stale_traffic, change(), POLICY, now=NOW)
    assert without["category"] == "REVIEW"
    assert without["eligible_for"] == "DISABLE"
    assert without["approval_status"] == "pending_business_confirmation"

    with_approval = evaluate(stale_rule, stale_traffic, change(), POLICY, approvals={"business_confirmation"}, now=NOW)
    assert with_approval["category"] == "DISABLE"


def test_delete_requires_approval_monitoring_and_no_traffic():
    stale_rule = rule(hit_count=0)
    stale_traffic = traffic(
        window_event_count=0,
        days_since_last_hit=220,
        last_seen=NOW - timedelta(days=220),
    )
    evidence = {
        "disabled_at": NOW - timedelta(days=75),
        "monitored_until": NOW - timedelta(days=10),
        "change_reference": "CHG0099",
    }
    result = evaluate(
        stale_rule,
        stale_traffic,
        change(),
        POLICY,
        approvals={"delete_approval", "obsolescence_confirmation"},
        disable_evidence=evidence,
        now=NOW,
    )
    assert result["category"] == "DELETE"

    # Monitoring period not finished -> cannot be DELETE.
    short = dict(evidence, monitored_until=NOW - timedelta(days=1), disabled_at=NOW - timedelta(days=10))
    not_ready = evaluate(
        stale_rule,
        stale_traffic,
        change(),
        POLICY,
        approvals={"delete_approval", "obsolescence_confirmation"},
        disable_evidence=short,
        now=NOW,
    )
    assert not_ready["category"] != "DELETE"


def test_traffic_after_disable_blocks_delete():
    stale_rule = rule(hit_count=0)
    stale_traffic = traffic(
        window_event_count=0,
        days_since_last_hit=220,
        last_seen=NOW - timedelta(days=5),
    )
    result = evaluate(
        stale_rule,
        stale_traffic,
        change(),
        POLICY,
        approvals={"delete_approval", "obsolescence_confirmation"},
        disable_evidence={"disabled_at": NOW - timedelta(days=75), "monitored_until": NOW - timedelta(days=10)},
        now=NOW,
    )
    assert result["category"] != "DELETE"


def test_expired_rule_is_not_kept():
    result = evaluate(
        rule(expiry_date="2025-01-01"),
        traffic(window_event_count=60),
        change(),
        POLICY,
        now=NOW,
    )
    assert result["category"] == "REVIEW"
