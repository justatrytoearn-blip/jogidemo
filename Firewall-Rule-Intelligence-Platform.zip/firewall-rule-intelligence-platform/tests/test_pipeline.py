"""End-to-end pipeline tests against a throwaway database.

The real sample log workbook references a different rule identity space than the
inventory, so the honest outcome is 200 REVIEW. The synthetic log file is keyed to the
real inventory UIDs and is used to prove the traffic maths and all four categories.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import select

from tests.conftest import SYNTHETIC_LOGS


def load_run(run_id: int):
    from backend.database.db import session_scope
    from backend.database.models import Run

    with session_scope() as session:
        return session.get(Run, run_id)


def test_real_inventory_imports_without_section_rows(runs, db):
    from backend.database.models import Rule

    for run_id, _stats in runs.values():
        rules = db.execute(select(Rule).where(Rule.run_id == run_id)).scalars().all()
        assert len(rules) == 200
        assert all(rule.rule_name and rule.rule_uid for rule in rules)


def test_real_logs_do_not_match_inventory_and_stay_review(runs, db):
    from backend.database.models import TrafficMetric

    run_id, stats = runs["real"]
    assert stats["matched_rules"] == 0
    assert stats["review"] == 200
    assert stats["keep"] == stats["disable"] == stats["delete"] == 0

    run = load_run(run_id)
    traffic = __import__("json").loads(run.stats_json)["traffic"]
    assert traffic["identity_space_ok"] is False
    assert traffic["rows_unmatched"] == 2000

    metrics = db.execute(select(TrafficMetric).where(TrafficMetric.run_id == run_id)).scalars().all()
    assert len(metrics) == 200
    assert all(metric.logs_supplied is True for metric in metrics)
    assert all(metric.absence_is_evidence is False for metric in metrics)


def test_synthetic_run_produces_all_four_categories(runs, db):
    from backend.database.models import Approval, DisableEvidence, Recommendation, Rule, TrafficMetric
    from backend.services.analysis import reevaluate_rule

    run_id, _ = runs["synthetic"]
    now = datetime.utcnow()
    rows = db.execute(
        select(Rule, Recommendation, TrafficMetric)
        .join(Recommendation, Recommendation.rule_id == Rule.id)
        .join(TrafficMetric, TrafficMetric.rule_id == Rule.id)
        .where(Rule.run_id == run_id)
        .order_by(Rule.id)
    ).all()
    dormant = [
        rule
        for rule, _rec, metric in rows
        if metric.matched and metric.window_event_count == 0 and metric.days_since_last_hit and metric.days_since_last_hit >= 180
    ]
    silent = [rule for rule, _rec, metric in rows if not metric.matched and metric.absence_is_evidence]
    assert len(dormant) >= 15
    assert len(silent) >= 6

    for rule in dormant[:15]:
        db.add(Approval(run_id=run_id, rule_id=rule.id, kind="business_confirmation", approved_by="test@example.com", note="test", source="test"))
    for rule in silent[:6]:
        db.add(
            DisableEvidence(
                run_id=run_id,
                rule_id=rule.id,
                disabled_at=now - timedelta(days=75),
                monitored_until=now - timedelta(days=10),
                change_reference="CHG_TEST",
                note="test",
                source="test",
            )
        )
        db.add(Approval(run_id=run_id, rule_id=rule.id, kind="delete_approval", approved_by="test@example.com", note="test", source="test"))
        db.add(Approval(run_id=run_id, rule_id=rule.id, kind="obsolescence_confirmation", approved_by="test@example.com", note="test", source="test"))
    db.commit()
    for rule in dormant[:15] + silent[:6]:
        reevaluate_rule(db, rule.id)

    categories = Counter(cat for (cat,) in db.execute(select(Recommendation.category).where(Recommendation.run_id == run_id)).all())
    assert set(categories) == {"KEEP", "REVIEW", "DISABLE", "DELETE"}
    assert sum(categories.values()) == 200
    assert categories["KEEP"] >= 100


def test_traffic_counts_match_independent_recomputation(runs, db):
    from backend.database.models import Rule, TrafficMetric

    run_id, stats = runs["synthetic"]
    assert stats["traffic"]["rows_scanned"] == 76925
    assert stats["traffic"]["rows_matched"] == 76925

    logs = pd.read_csv(SYNTHETIC_LOGS)
    logs["Time"] = pd.to_datetime(logs["Time"], format="ISO8601")
    logs["uid"] = logs["Policy Rule UID"].fillna("").str.lower()
    per_uid = Counter(logs["uid"])

    rules = db.execute(select(Rule).where(Rule.run_id == run_id)).scalars().all()
    metrics = {m.rule_id: m for m in db.execute(select(TrafficMetric).where(TrafficMetric.run_id == run_id)).scalars().all()}
    assert len(rules) == 200
    for rule in rules:
        metric = metrics[rule.id]
        uid = (rule.rule_uid or "").lower()
        assert metric.event_count == per_uid.get(uid, 0), rule.rule_name

        window_days = metric.observation_days or 90
        window_start = datetime.utcnow() - timedelta(days=window_days - 1)
        expected_window = int(((logs["uid"] == uid) & (logs["Time"] >= window_start)).sum())
        assert metric.window_event_count == expected_window, rule.rule_name
