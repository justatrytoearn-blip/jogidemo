@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Firewall Rule Intelligence Platform - stopping

echo Stopping the API on port 8080 ...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:"127.0.0.1:8080 .*LISTENING"') do (
  taskkill /PID %%P /F >nul 2>&1
  echo   Stopped process %%P
)

where docker >nul 2>&1
if not errorlevel 1 (
  docker info >nul 2>&1
  if not errorlevel 1 (
    docker compose -f "n8n\docker-compose.yml" stop >nul 2>&1
    echo n8n container stopped.
  )
)

echo Done. Uploaded files, the database and reports were not modified.
ping -n 2 127.0.0.1 >nul
