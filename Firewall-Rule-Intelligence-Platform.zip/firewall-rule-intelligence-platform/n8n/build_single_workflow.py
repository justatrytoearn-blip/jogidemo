"""Generate the single all-in-one n8n workflow.

One trigger accepts a prompt (or a structured JSON body), starts the backend
full-review endpoint, waits for the analysis/AI/reports to finish and returns the
portal links and category counts. All heavy lifting stays in the FastAPI backend.

Run: python n8n/build_single_workflow.py
"""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent / "workflows"
BASE = "={{$env.FIP_BASE_URL}}"
PORTAL = "={{ $env.FIP_PORTAL_URL || 'http://127.0.0.1:8080' }}"
HEADERS = {
    "parameters": [
        {"name": "X-API-Key", "value": "={{$env.FIP_API_KEY}}"},
        {"name": "Content-Type", "value": "application/json"},
    ]
}


def node(name: str, kind: str, version, position, params: dict, **extra) -> dict:
    return {
        "parameters": params,
        "id": name.lower().replace(" ", "-").replace("?", ""),
        "name": name,
        "type": kind,
        "typeVersion": version,
        "position": list(position),
        **extra,
    }


def http(name: str, method: str, url: str, body: str | None = None, position=(440, 0), timeout=120000) -> dict:
    params = {
        "method": method,
        "url": url,
        "sendHeaders": True,
        "headerParameters": HEADERS,
        "options": {"timeout": timeout, "response": {"response": {"neverError": False}}},
    }
    if body:
        params.update({"sendBody": True, "specifyBody": "json", "jsonBody": body})
    return node(
        name, "n8n-nodes-base.httpRequest", 4.2, position, params,
        onError="continueErrorOutput", retryOnFail=False,
    )


def set_node(name: str, assignments: dict, position) -> dict:
    return node(
        name, "n8n-nodes-base.set", 3.4, position,
        {
            "assignments": {
                "assignments": [
                    {"id": key, "name": key, "value": value, "type": "string"}
                    for key, value in assignments.items()
                ]
            },
            "options": {},
        },
    )


def respond(name: str, body: str, position, code: int = 200) -> dict:
    return node(
        name, "n8n-nodes-base.respondToWebhook", 1.1, position,
        {"respondWith": "json", "responseBody": body, "options": {"responseCode": code}},
    )


def main() -> None:
    nodes = [
        node(
            "Review request form", "n8n-nodes-base.formTrigger", 2.2, (0, -220),
            {
                "path": "fip/review-form",
                "formTitle": "Firewall Rule Review",
                "formDescription": "Enter what to review. Example: demo  label: Weekly demo  model: qwen2.5:1.5b",
                "formFields": {
                    "values": [
                        {"fieldLabel": "prompt", "fieldType": "textarea", "requiredField": True,
                         "placeholder": "demo  label: Customer demo  model: qwen2.5:1.5b"},
                        {"fieldLabel": "model", "fieldType": "text", "requiredField": False,
                         "placeholder": "leave empty to use the portal setting"},
                        {"fieldLabel": "demo", "fieldType": "dropdown", "requiredField": False,
                         "fieldOptions": {"values": [{"option": "yes"}, {"option": "no"}]}},
                    ]
                },
                "responseMode": "responseNode",
                "options": {},
            },
            webhookId="fip-single-form",
        ),
        node(
            "Review request webhook", "n8n-nodes-base.webhook", 2, (0, 0),
            {
                "httpMethod": "POST",
                "path": "fip/review",
                "responseMode": "responseNode",
                "options": {"rawBody": False},
            },
            webhookId="fip-single-webhook",
        ),
        node(
            "Build request from prompt", "n8n-nodes-base.code", 2, (220, -110),
            {
                "jsCode": (
                    "const body = ($json.body && typeof $json.body === 'object') ? $json.body : $json;\n"
                    "const prompt = String(body.prompt || '').trim();\n"
                    "if (!prompt && !body.demo) {\n"
                    "  throw new Error('Provide a prompt. Example: demo label: Customer demo model: qwen2.5:1.5b');\n"
                    "}\n"
                    "const request = { prompt };\n"
                    "for (const key of ['model','demo','label','ai_limit','ai','reports']) {\n"
                    "  if (body[key] !== undefined && body[key] !== null && String(body[key]).trim() !== '') {\n"
                    "    request[key] = body[key];\n"
                    "  }\n"
                    "}\n"
                    "if (request.demo === 'no' || request.demo === 'false') request.demo = false;\n"
                    "if (request.demo === 'yes' || request.demo === 'true') request.demo = true;\n"
                    "return [{ json: { request } }];"
                )
            },
        ),
        http(
            "Start full review", "POST", f"{BASE}/api/n8n/full-review",
            "={{ JSON.stringify($json.request) }}", (440, -110), 120000,
        ),
        node("Wait before polling", "n8n-nodes-base.wait", 1.1, (660, -110),
             {"amount": 8, "unit": "seconds"}, webhookId="wait-fip-review"),
        http(
            "Read review status", "GET",
            f"{BASE}/api/n8n/full-review/{{{{ $('Start full review').item.json.run_id }}}}",
            None, (880, -110), 60000,
        ),
        node(
            "Track attempts", "n8n-nodes-base.code", 2, (1100, -110),
            {
                "jsCode": (
                    "const g = $getWorkflowStaticData('global');\n"
                    "g.reviewAttempts = (g.reviewAttempts || 0) + 1;\n"
                    "if ($json.status === 'completed' || $json.status === 'failed') g.reviewAttempts = 0;\n"
                    "return [{ json: { ...$json, attempts: g.reviewAttempts } }];"
                )
            },
        ),
        node(
            "Finished?", "n8n-nodes-base.if", 2.2, (1320, -110),
            {
                "conditions": {
                    "options": {"caseSensitive": True, "leftValue": "", "typeValidation": "loose", "version": 2},
                    "conditions": [
                        {"id": "done", "leftValue": "={{$json.status}}", "rightValue": "completed",
                         "operator": {"type": "string", "operation": "equals"}},
                        {"id": "failed", "leftValue": "={{$json.status}}", "rightValue": "failed",
                         "operator": {"type": "string", "operation": "equals"}},
                    ],
                    "combinator": "or",
                },
                "options": {},
            },
        ),
        set_node(
            "Build review result",
            {
                "status": "={{$json.status}}",
                "run_id": "={{$json.run_id}}",
                "label": "={{$json.label}}",
                "rules": "={{$json.rules}}",
                "keep": "={{$json.counts?.KEEP ?? 0}}",
                "review": "={{$json.counts?.REVIEW ?? 0}}",
                "disable": "={{$json.counts?.DISABLE ?? 0}}",
                "delete": "={{$json.counts?.DELETE ?? 0}}",
                "matched_log_events": "={{$json.stats?.traffic?.rows_matched ?? 0}}",
                "log_coverage_days": "={{$json.stats?.traffic?.coverage_days ?? 0}}",
                "ai_generated": "={{$json.stats?.ai_generated_rules ?? 0}}",
                "ai_model": "={{$json.stats?.ai_model ?? ''}}",
                "reports": "={{$json.reports}}",
                "accepted": "={{$json.accepted}}",
                "demo": "={{$json.stats?.full_review?.demo ?? false}}",
                "dashboard_url": "={{ $env.FIP_PORTAL_URL || 'http://127.0.0.1:8080' }}/#/dashboard?run={{$json.run_id}}",
                "rules_url": "={{ $env.FIP_PORTAL_URL || 'http://127.0.0.1:8080' }}/#/rules?run={{$json.run_id}}",
                "reports_url": "={{ $env.FIP_PORTAL_URL || 'http://127.0.0.1:8080' }}/#/reports?run={{$json.run_id}}",
                "message": "={{$json.message}}",
            },
            (1540, -220),
        ),
        respond("Respond review", "={{$json}}", (1760, -220)),
        node(
            "Attempts left?", "n8n-nodes-base.if", 2.2, (1540, 40),
            {
                "conditions": {
                    "options": {"caseSensitive": True, "leftValue": "", "typeValidation": "number", "version": 2},
                    "conditions": [
                        {"id": "left", "leftValue": "={{$json.attempts}}", "rightValue": 120,
                         "operator": {"type": "number", "operation": "lt"}}
                    ],
                    "combinator": "and",
                },
                "options": {},
            },
        ),
        set_node(
            "Build timeout result",
            {
                "status": "timeout",
                "run_id": "={{$json.run_id}}",
                "message": "The review is still running. Open the Runs page to follow it.",
                "rules_url": "={{ $env.FIP_PORTAL_URL || 'http://127.0.0.1:8080' }}/#/runs?run={{$json.run_id}}",
                "progress": "={{$json.progress}}",
                "stage": "={{$json.stage}}",
            },
            (1760, 40),
        ),
        respond("Respond timeout", "={{$json}}", (1980, 40), 202),
        set_node(
            "Build error response",
            {
                "status": "failed",
                "message": "={{$json.error?.message || $json.message || 'backend call failed'}}",
                "workflow": "={{$workflow.name}}",
            },
            (660, 180),
        ),
        respond("Respond with error", "={{$json}}", (880, 180), 502),
    ]

    connections = {
        "Review request form": {"main": [[{"node": "Build request from prompt", "type": "main", "index": 0}]]},
        "Review request webhook": {"main": [[{"node": "Build request from prompt", "type": "main", "index": 0}]]},
        "Build request from prompt": {"main": [[{"node": "Start full review", "type": "main", "index": 0}]]},
        "Start full review": {
            "main": [
                [{"node": "Wait before polling", "type": "main", "index": 0}],
                [{"node": "Build error response", "type": "main", "index": 0}],
            ]
        },
        "Wait before polling": {"main": [[{"node": "Read review status", "type": "main", "index": 0}]]},
        "Read review status": {
            "main": [
                [{"node": "Track attempts", "type": "main", "index": 0}],
                [{"node": "Build error response", "type": "main", "index": 0}],
            ]
        },
        "Track attempts": {"main": [[{"node": "Finished?", "type": "main", "index": 0}]]},
        "Finished?": {"main": [
            [{"node": "Build review result", "type": "main", "index": 0}],
            [{"node": "Attempts left?", "type": "main", "index": 0}],
        ]},
        "Build review result": {"main": [[{"node": "Respond review", "type": "main", "index": 0}]]},
        "Attempts left?": {"main": [
            [{"node": "Wait before polling", "type": "main", "index": 0}],
            [{"node": "Build timeout result", "type": "main", "index": 0}],
        ]},
        "Build timeout result": {"main": [[{"node": "Respond timeout", "type": "main", "index": 0}]]},
        "Build error response": {"main": [[{"node": "Respond with error", "type": "main", "index": 0}]]},
    }

    workflow = {
        "id": "fip-wf-00",
        "name": "FIP - 00 Full Review (one prompt)",
        "nodes": nodes,
        "connections": connections,
        "active": False,
        "settings": {"executionOrder": "v1", "saveManualExecutions": True, "callerPolicy": "workflowsFromSameOwner"},
        "staticData": None,
        "pinData": {},
        "versionId": "1",
        "meta": {
            "templateCredsSetupCompleted": True,
            "description": (
                "Single entry point: accept a prompt, run ingestion, correlation, traffic, AI narration and "
                "the full report set, then return category counts and portal links."
            ),
        },
        "notes": (
            "Enter a prompt such as: demo  label: Customer demo  model: qwen2.5:1.5b. "
            "Other keys: rules:, changes:, logs:, ai_limit:. Omit demo to use files in uploads/. "
            "The backend never changes a firewall; every DISABLE/DELETE still needs human approval."
        ),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "fip-wf-00.json"
    path.write_text(json.dumps(workflow, indent=2), encoding="utf-8")
    print("wrote", path)


if __name__ == "__main__":
    main()
