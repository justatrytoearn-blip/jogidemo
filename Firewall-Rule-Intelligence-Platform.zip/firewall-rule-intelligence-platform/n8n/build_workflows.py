"""Generate the six n8n workflow definitions used by the platform.

Workflows orchestrate the backend's deterministic APIs. They never compute
recommendations themselves and never touch a firewall.

Run: python n8n/build_workflows.py
"""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent / "workflows"
BASE = "={{$env.FIP_BASE_URL}}"
KEY_HEADER = {
    "parameters": [
        {"name": "X-API-Key", "value": "={{$env.FIP_API_KEY}}"},
        {"name": "Content-Type", "value": "application/json"},
    ]
}


def webhook(name: str, path: str, wf_id: str) -> dict:
    return {
        "parameters": {
            "httpMethod": "POST",
            "path": path,
            "responseMode": "responseNode",
            "options": {"rawBody": False},
        },
        "id": f"{wf_id}-webhook",
        "name": name,
        "type": "n8n-nodes-base.webhook",
        "typeVersion": 2,
        "position": [0, 0],
        "webhookId": f"{wf_id}-{path.replace('/', '-')}",
    }


def http(name: str, method: str, path: str, body_expression: str | None = None, timeout: int = 180000) -> dict:
    params = {
        "method": method,
        "url": f"{BASE}{path}",
        "sendHeaders": True,
        "headerParameters": KEY_HEADER,
        "options": {"timeout": timeout, "response": {"response": {"neverError": False}}},
    }
    if body_expression:
        params.update({"sendBody": True, "specifyBody": "json", "jsonBody": body_expression})
    return {
        "parameters": params,
        "id": f"{name.lower().replace(' ', '-')}",
        "name": name,
        "type": "n8n-nodes-base.httpRequest",
        "typeVersion": 4.2,
        "position": [220, 0],
        "onError": "continueErrorOutput",
        "retryOnFail": name != "Start correlation and traffic analysis",
        "maxTries": 2,
        "waitBetweenTries": 2000,
    }


def set_node(name: str, assignments: dict, position=(440, -120)) -> dict:
    return {
        "parameters": {
            "assignments": {
                "assignments": [
                    {"id": k, "name": k, "value": v, "type": "string"} for k, v in assignments.items()
                ]
            },
            "options": {},
        },
        "id": name.lower().replace(" ", "-"),
        "name": name,
        "type": "n8n-nodes-base.set",
        "typeVersion": 3.4,
        "position": list(position),
    }


def if_node(name: str, left: str, right: str, position=(660, -120)) -> dict:
    return {
        "parameters": {
            "conditions": {
                "options": {"caseSensitive": True, "leftValue": "", "typeValidation": "loose", "version": 2},
                "conditions": [
                    {
                        "id": "cond-1",
                        "leftValue": left,
                        "rightValue": right,
                        "operator": {"type": "string", "operation": "equals"},
                    }
                ],
                "combinator": "and",
            },
            "options": {},
        },
        "id": name.lower().replace(" ", "-"),
        "name": name,
        "type": "n8n-nodes-base.if",
        "typeVersion": 2.2,
        "position": list(position),
    }


def wait(name: str, seconds: int, position=(660, 140)) -> dict:
    return {
        "parameters": {"amount": seconds, "unit": "seconds"},
        "id": name.lower().replace(" ", "-"),
        "name": name,
        "type": "n8n-nodes-base.wait",
        "typeVersion": 1.1,
        "position": list(position),
        "webhookId": f"wait-{seconds}",
    }


def respond(name: str, body_expression: str, code: int = 200, position=(1100, -120)) -> dict:
    return {
        "parameters": {
            "respondWith": "json",
            "responseBody": body_expression,
            "options": {"responseCode": code},
        },
        "id": name.lower().replace(" ", "-"),
        "name": name,
        "type": "n8n-nodes-base.respondToWebhook",
        "typeVersion": 1.1,
        "position": list(position),
    }


def error_set(name: str = "Build error response") -> dict:
    return {
        "parameters": {
            "assignments": {
                "assignments": [
                    {"id": "error", "name": "status", "value": "failed", "type": "string"},
                    {"id": "message", "name": "error", "value": "={{$json.error?.message || $json.message || 'backend call failed'}}", "type": "string"},
                    {"id": "workflow", "name": "workflow", "value": "={{$workflow.name}}", "type": "string"},
                ]
            },
            "options": {},
        },
        "id": name.lower().replace(" ", "-"),
        "name": name,
        "type": "n8n-nodes-base.set",
        "typeVersion": 3.4,
        "position": [880, 240],
    }


def respond_error() -> dict:
    return respond("Respond with error", "={{$json}}", 502, (1100, 240))


def workflow(wf_id: str, name: str, nodes: list[dict], connections: dict, notes: str) -> dict:
    return {
        "id": wf_id,
        "name": name,
        "nodes": nodes,
        "connections": connections,
        "active": False,
        "settings": {"executionOrder": "v1", "saveManualExecutions": True, "callerPolicy": "workflowsFromSameOwner"},
        "staticData": None,
        "pinData": {},
        "versionId": "1",
        "meta": {"templateCredsSetupCompleted": True, "description": notes},
        "notes": notes,
    }


def link(*pairs: tuple[str, str, int]) -> dict:
    out: dict = {}
    for source, target, index in pairs:
        out.setdefault(source, {"main": []})
        main = out[source]["main"]
        while len(main) <= index:
            main.append([])
        main[index].append({"node": target, "type": "main", "index": 0})
    return out


def merge(*parts: dict) -> dict:
    out: dict = {}
    for part in parts:
        for source, conn in part.items():
            out.setdefault(source, {"main": []})
            for idx, targets in enumerate(conn["main"]):
                while len(out[source]["main"]) <= idx:
                    out[source]["main"].append([])
                out[source]["main"][idx].extend(targets)
    return out


def build() -> list[dict]:
    workflows = []

    # ---------------- WF1: ingestion ----------------
    nodes = [
        webhook("Ingest Request", "fip/ingest", "fip-wf-01"),
        http(
            "Send to backend ingestion",
            "POST",
            "/api/n8n/ingest-path",
            "={{ JSON.stringify($json.body || {}) }}",
        ),
        set_node(
            "Ingestion summary",
            {
                "status": "ingested",
                "upload_id": "={{$json.upload.id}}",
                "dataset_type": "={{$json.upload.dataset_type}}",
                "filename": "={{$json.upload.original_filename}}",
                "rows": "={{$json.upload.row_count}}",
                "warnings": "={{($json.upload.warnings || []).join('; ')}}",
                "upload": "={{ JSON.stringify($json.upload) }}",
            },
        ),
        error_set(),
        respond("Respond ingestion", "={{$json}}", 200, (660, -120)),
        respond_error(),
    ]
    connections = merge(
        link(("Ingest Request", "Send to backend ingestion", 0), ("Send to backend ingestion", "Ingestion summary", 0), ("Ingestion summary", "Respond ingestion", 0)),
        link(("Send to backend ingestion", "Build error response", 1), ("Build error response", "Respond with error", 0)),
    )
    workflows.append(
        workflow(
            "fip-wf-01",
            "FIP - 01 File Ingestion",
            nodes,
            connections,
            "Receives a path to a file dropped into uploads/, validates it, auto-detects columns, normalises it and stores ingestion metadata. Portal uploads use the same backend import service.",
        )
    )

    # ---------------- WF2: correlation + traffic ----------------
    nodes = [
        webhook("Analysis Request", "fip/analyze", "fip-wf-02"),
        http(
            "Start correlation and traffic analysis",
            "POST",
            "/api/n8n/analyze",
            "={{ JSON.stringify($json.body || {}) }}",
            timeout=240000,
        ),
        # no retry: creating a run is not idempotent
        wait("Wait for analysis", 10, (440, 0)),
        http("Read run status", "GET", "/api/n8n/runs/{{ $json.run_id }}", None, 120000),
        set_node(
            "Analysis result",
            {
                "status": "accepted",
                "run_id": "={{$json.run_id}}",
                "run_status": "={{$json.status}}",
                "rules": "={{$json.counts?.rules ?? 0}}",
                "recommendations": "={{$json.counts?.recommendations ?? 0}}",
                "keep": "={{$json.stats?.keep ?? 0}}",
                "review": "={{$json.stats?.review ?? 0}}",
                "disable": "={{$json.stats?.disable ?? 0}}",
                "delete": "={{$json.stats?.delete ?? 0}}",
                "matched_log_events": "={{$json.stats?.traffic?.rows_matched ?? 0}}",
                "summary": "={{ JSON.stringify($json.stats) }}",
            },
        ),
        error_set(),
        respond("Respond analysis", "={{$json}}", 202, (900, -120)),
        respond_error(),
    ]
    connections = merge(
        link(("Analysis Request", "Start correlation and traffic analysis", 0), ("Start correlation and traffic analysis", "Wait for analysis", 0), ("Wait for analysis", "Read run status", 0), ("Read run status", "Analysis result", 0), ("Analysis result", "Respond analysis", 0)),
        link(("Start correlation and traffic analysis", "Build error response", 1), ("Build error response", "Respond with error", 0)),
        link(("Read run status", "Build error response", 1)),
    )
    workflows.append(
        workflow(
            "fip-wf-02",
            "FIP - 02 Firewall Rule Correlation",
            nodes,
            connections,
            "Triggers the correlation + traffic pipeline (rule UID -> number+device -> name+device matching, change-record linking, per-rule traffic metrics) and returns run statistics. The backend performs the data work in its background worker.",
        )
    )

    # ---------------- WF3: traffic analysis monitor ----------------
    nodes = [
        webhook("Status Request", "fip/traffic", "fip-wf-03"),
        http("Read run detail", "GET", "/api/n8n/runs/{{ $json.body.run_id }}", None, 120000),
        wait("Wait for traffic metrics", 8, (440, 0)),
        http("Read run detail again", "GET", '/api/n8n/runs/{{ $json.run_id ?? $("Read run detail").item.json.run_id }}', None, 120000),
        set_node(
            "Traffic metrics summary",
            {
                "run_id": "={{$json.run_id}}",
                "status": "={{$json.status}}",
                "stage": "={{$json.stage}}",
                "progress": "={{$json.progress}}",
                "rows_scanned": "={{$json.stats?.traffic?.rows_scanned ?? 0}}",
                "rows_matched": "={{$json.stats?.traffic?.rows_matched ?? 0}}",
                "rows_unmatched": "={{$json.stats?.traffic?.rows_unmatched ?? 0}}",
                "log_coverage_days": "={{$json.stats?.traffic?.coverage_days ?? 0}}",
                "identity_space_ok": "={{$json.stats?.traffic?.identity_space_ok ?? false}}",
                "inactive_rules": "={{$json.stats?.with_zero_traffic ?? 0}}",
                "summary": "={{ JSON.stringify($json.stats?.traffic || {}) }}",
            },
        ),
        error_set(),
        respond("Respond traffic", "={{$json}}", 200, (880, -120)),
        respond_error(),
    ]
    connections = merge(
        link(("Status Request", "Read run detail", 0), ("Read run detail", "Wait for traffic metrics", 0), ("Wait for traffic metrics", "Read run detail again", 0), ("Read run detail again", "Traffic metrics summary", 0), ("Traffic metrics summary", "Respond traffic", 0)),
        link(("Read run detail", "Build error response", 1), ("Build error response", "Respond with error", 0)),
        link(("Read run detail again", "Build error response", 1)),
    )
    workflows.append(
        workflow(
            "fip-wf-03",
            "FIP - 03 Traffic Analysis",
            nodes,
            connections,
            "Reads the aggregated traffic metrics produced by the streaming log analysis (frequency, last-hit age, observation-period counts, inactive rules, identity-space coverage) and returns them for automation.",
        )
    )

    # ---------------- WF4: AI review ----------------
    nodes = [
        webhook("AI Review Request", "fip/ai", "fip-wf-04"),
        http("Queue AI narration", "POST", "/api/n8n/ai/{{ $json.body.run_id }}", "={{ JSON.stringify({ limit: ($json.body && $json.body.limit) || 200 }) }}", 120000),
        wait("Wait for AI worker", 5, (440, 0)),
        set_node(
            "AI review queued",
            {
                "status": "queued",
                "run_id": "={{$('AI Review Request').item.json.body.run_id}}",
                "job_id": "={{$json.job_id}}",
                "model": "={{$env.FIP_AI_MODEL || 'qwen2.5:1.5b'}}",
                "note": "Narration is generated locally and validated against the policy engine; the recommendation itself is never changed by the model.",
            },
        ),
        error_set(),
        respond("Respond AI", "={{$json}}", 202, (660, -120)),
        respond_error(),
    ]
    connections = merge(
        link(("AI Review Request", "Queue AI narration", 0), ("Queue AI narration", "Wait for AI worker", 0), ("Wait for AI worker", "AI review queued", 0), ("AI review queued", "Respond AI", 0)),
        link(("Queue AI narration", "Build error response", 1), ("Build error response", "Respond with error", 0)),
    )
    workflows.append(
        workflow(
            "fip-wf-04",
            "FIP - 04 AI Review",
            nodes,
            connections,
            "Queues local Ollama narration for the analysed rules. Prompts contain aggregated evidence only (never raw logs); responses are validated against the deterministic recommendation and rejected if they invent facts or contradict measured traffic.",
        )
    )

    # ---------------- WF5: report generation ----------------
    nodes = [
        webhook("Report Request", "fip/report", "fip-wf-05"),
        http(
            "Generate reports",
            "POST",
            "/api/n8n/report/{{ $json.body.run_id }}",
            "={{ JSON.stringify({ kinds: ($json.body && $json.body.kinds) || ['full','keep','review','disable','delete','missing_info','no_change','zero_traffic','executive'], formats: ($json.body && $json.body.formats) || ['xlsx','pdf'] }) }}",
            300000,
        ),
        set_node(
            "Report summary",
            {
                "status": "generated",
                "run_id": "={{$('Report Request').item.json.body.run_id}}",
                "count": "={{$json.count}}",
                "reports": "={{ JSON.stringify($json.reports) }}",
            },
        ),
        error_set(),
        respond("Respond reports", "={{$json}}", 200, (660, -120)),
        respond_error(),
    ]
    connections = merge(
        link(("Report Request", "Generate reports", 0), ("Generate reports", "Report summary", 0), ("Report summary", "Respond reports", 0)),
        link(("Generate reports", "Build error response", 1), ("Build error response", "Respond with error", 0)),
    )
    workflows.append(
        workflow(
            "fip-wf-05",
            "FIP - 05 Report Generation",
            nodes,
            connections,
            "Generates the Excel and PDF report set for a run (complete review, each recommendation, missing information, no change history, zero traffic, executive summary) and returns the stored file paths.",
        )
    )

    # ---------------- WF6: re-analysis comparison ----------------
    nodes = [
        webhook("Compare Request", "fip/compare", "fip-wf-06"),
        http("Compare runs", "POST", "/api/n8n/compare", "={{ JSON.stringify($json.body || {}) }}", 240000),
        set_node(
            "Comparison summary",
            {
                "status": "compared",
                "new_rules": "={{$json.summary?.new_rules ?? 0}}",
                "removed_rules": "={{$json.summary?.removed_rules ?? 0}}",
                "changed_rules": "={{$json.summary?.changed_rules ?? 0}}",
                "recommendation_changes": "={{$json.summary?.recommendation_changes ?? 0}}",
                "traffic_changes": "={{$json.summary?.traffic_changes ?? 0}}",
                "newly_linked_changes": "={{$json.summary?.newly_linked_changes ?? 0}}",
                "details": "={{ JSON.stringify($json.details) }}",
            },
        ),
        error_set(),
        respond("Respond comparison", "={{$json}}", 200, (660, -120)),
        respond_error(),
    ]
    connections = merge(
        link(("Compare Request", "Compare runs", 0), ("Compare runs", "Comparison summary", 0), ("Comparison summary", "Respond comparison", 0)),
        link(("Compare runs", "Build error response", 1), ("Build error response", "Respond with error", 0)),
    )
    workflows.append(
        workflow(
            "fip-wf-06",
            "FIP - 06 Re-Analysis Comparison",
            nodes,
            connections,
            "Compares a baseline run with a newer run and returns new rules, removed rules, changed configuration, traffic deltas, recommendation changes and newly linked change records.",
        )
    )
    return workflows


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    items = build()
    for wf in items:
        path = OUT / f"{wf['id']}.json"
        path.write_text(json.dumps(wf, indent=2), encoding="utf-8")
        print("wrote", path.name)
    manifest = [
        {"id": wf["id"], "name": wf["name"], "webhook": next(n["parameters"]["path"] for n in wf["nodes"] if n["type"].endswith("webhook")), "file": f"{wf['id']}.json"}
        for wf in items
    ]
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
