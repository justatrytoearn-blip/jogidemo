"""Generate the hosted n8n chat workflow.

The chat window is served by n8n itself. A message is posted to the backend chat
endpoint, which either runs the review or answers a model/connection command. The
final Set node emits `{ output: ... }` because the Chat Trigger uses last-node mode.

Run: python n8n/build_chat_workflow.py
"""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent / "workflows"
BASE = "={{$env.FIP_BASE_URL}}"


def main() -> None:
    nodes = [
        {
            "parameters": {
                "public": True,
                "mode": "hostedChat",
                "initialMessages": (
                    "Welcome to the Firewall Rule Intelligence demo.\n\n"
                    "Type **demo** to run the full fictional review, or **help** for commands. "
                    "You can also use `set model <name>`, `test model <name>`, `models` and `connection`."
                ),
                "options": {
                    "title": "Firewall Rule Intelligence",
                    "subtitle": "Demo and model control",
                    "responseMode": "lastNode",
                },
            },
            "id": "fip-chat-trigger",
            "name": "Chat",
            "type": "@n8n/n8n-nodes-langchain.chatTrigger",
            "typeVersion": 1.4,
            "position": [0, 0],
            "webhookId": "fip-chat",
        },
        {
            "parameters": {
                "method": "POST",
                "url": f"{BASE}/api/n8n/chat",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "X-API-Key", "value": "={{$env.FIP_API_KEY}}"},
                        {"name": "Content-Type", "value": "application/json"},
                    ]
                },
                "sendBody": True,
                "specifyBody": "json",
                "jsonBody": "={{ JSON.stringify({ message: $json.chatInput, sessionId: $json.sessionId }) }}",
                "options": {
                    "timeout": 600000,
                    "response": {"response": {"neverError": False}},
                },
            },
            "id": "fip-chat-backend",
            "name": "FIP chat backend",
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": 4.2,
            "position": [240, 0],
            "onError": "continueErrorOutput",
            "retryOnFail": False,
        },
        {
            "parameters": {
                "assignments": {
                    "assignments": [
                        {
                            "id": "output",
                            "name": "output",
                            "value": "={{$json.output || ('Request failed: ' + ($json.message || $json.error || 'unknown error'))}}",
                            "type": "string",
                        }
                    ]
                },
                "options": {},
            },
            "id": "fip-chat-reply",
            "name": "Chat reply",
            "type": "n8n-nodes-base.set",
            "typeVersion": 3.4,
            "position": [480, -100],
        },
        {
            "parameters": {
                "assignments": {
                    "assignments": [
                        {
                            "id": "output-error",
                            "name": "output",
                            "value": "={{'The backend request failed: ' + ($json.message || $json.error || 'check the API and n8n key')}}",
                            "type": "string",
                        }
                    ]
                },
                "options": {},
            },
            "id": "fip-chat-error",
            "name": "Chat error reply",
            "type": "n8n-nodes-base.set",
            "typeVersion": 3.4,
            "position": [480, 120],
        },
    ]

    connections = {
        "Chat": {"main": [[{"node": "FIP chat backend", "type": "main", "index": 0}]]},
        "FIP chat backend": {
            "main": [
                [{"node": "Chat reply", "type": "main", "index": 0}],
                [{"node": "Chat error reply", "type": "main", "index": 0}],
            ]
        },
    }

    workflow = {
        "id": "fip-wf-chat",
        "name": "FIP - Chat Demo & Model Control",
        "nodes": nodes,
        "connections": connections,
        "active": False,
        "settings": {"executionOrder": "v1", "saveManualExecutions": True, "callerPolicy": "workflowsFromSameOwner"},
        "staticData": None,
        "pinData": {},
        "versionId": "1",
        "meta": {
            "templateCredsSetupCompleted": True,
            "description": (
                "Hosted n8n chat for customer demos. Runs the full review from a prompt and "
                "supports model/connection commands without opening the workflow editor."
            ),
        },
        "notes": (
            "Open the hosted chat URL, type demo to run. Commands: help, models, connection, "
            "set model <name>, test model <name>, status <run_id>. The workflow calls the FIP "
            "backend chat endpoint; no firewall changes are made."
        ),
    }

    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "fip-wf-chat.json"
    path.write_text(json.dumps(workflow, indent=2), encoding="utf-8")
    print("wrote", path)


if __name__ == "__main__":
    main()
