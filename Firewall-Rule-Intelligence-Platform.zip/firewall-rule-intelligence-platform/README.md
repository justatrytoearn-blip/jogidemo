# Firewall Rule Intelligence Platform

A locally hosted workspace for reviewing firewall rule estates: import the rule inventory,
ServiceNow change records and firewall logs, correlate them, measure real traffic, and produce
defensible **KEEP / REVIEW / DISABLE / DELETE** recommendations with Excel and PDF reports.

> **This tool never changes a firewall.** It performs analysis only and records evidence for
> change management. All processing runs on this machine; no customer data is sent to an
> external LLM or cloud service.

![stack](https://img.shields.io/badge/backend-FastAPI%20%2B%20pandas-0b7285) ![stack](https://img.shields.io/badge/frontend-React%20%2B%20Vite-1c7ed6) ![stack](https://img.shields.io/badge/db-SQLite%20(PostgreSQL--ready)-495057) ![stack](https://img.shields.io/badge/ai-Ollama%20(local)-7048e8)

---

## Quick start (Windows)

```bat
setup.bat        :: one-time: Python venv, dependencies, frontend build, Ollama model, n8n container
start.bat        :: start the API and open http://127.0.0.1:8080
health_check.bat :: check API, portal, n8n, Ollama and the database
stop.bat         :: stop the API and the n8n container
```

Requirements:

- Python 3.11+ (tested with 3.14)
- Node.js 20+ only if you change the frontend (a built `frontend/dist` is used at runtime)
- Docker Desktop only for n8n orchestration (the portal works without it)
- Ollama only for AI explanations (deterministic recommendations and reports work without it)

`setup.bat` detects which of these exist instead of assuming they are installed.

| Service | URL |
| --- | --- |
| Portal | http://127.0.0.1:8080 |
| OpenAPI docs | http://127.0.0.1:8080/docs |
| Health | http://127.0.0.1:8080/api/health |
| n8n (optional) | http://127.0.0.1:5679 |

Default bind address is `127.0.0.1` only. Authentication is **off** by default for local use; set
`FIP_AUTH_ENABLED=true` to require login (the bootstrap admin password is generated on first start
into `config/admin_credentials.txt`).

---

## What the portal does

### Executive dashboard
Fourteen clickable metrics (total rules, KEEP/REVIEW/DISABLE/DELETE, rules with traffic, rules with
no traffic, rules without change records, missing owners, missing information, matched/unmatched
rules, change records, coverage) and eight charts (recommendation mix, traffic trend, top rules,
top sources/destinations, protocols, change status, risk mix). Every number is computed from the
selected run, and clicking a card opens the matching filtered rule list.

### File upload centre
Three datasets (firewall rules, ServiceNow change records, firewall logs), drag-and-drop,
automatic sheet selection and column mapping, manual mapping override, validation results,
duplicate detection (checksum), a 20-row preview, downloadable templates, and replacement uploads
that keep the previous file for audit. Original uploads are never overwritten.

### Rule review
Server-side pagination and filtering (search, recommendation, risk, action, section, device,
traffic state, change state, owner, expiry, match method), row selection, bulk approve/reject,
and export of the current selection. Approved decisions are recorded as evidence, not pushed to a
firewall.

### Rule detail (sections A-D)
A. rule identity and change history, B. traffic evidence (counts, last hit, trends, sources,
destinations, protocols), C. the deterministic recommendation with triggers, missing evidence,
risk, confidence and required approvals, D. local AI narrative with validation status and a
regenerate button.

### Runs and comparison
Each analysis is stored as a run with its own rules, metrics, recommendations and reports.
Comparing two runs shows new/removed rules, changed rule configuration, traffic deltas,
recommendation changes and newly linked change records.

### Reports
Excel and PDF for: complete review, KEEP, REVIEW, DISABLE, DELETE, missing information, no change
history, zero traffic and executive summary. The complete review sheet carries the full
traceability set (28+ columns: rule identity, device, section, action, change references, owner,
traffic window, last hit, days since, match method/confidence, recommendation, risk, confidence,
triggers, missing evidence, approvals, expiry, source file/sheet and more).

### Policy settings
Observation window, last-hit threshold, post-disable monitoring, minimum log coverage, approval
requirements, frequency thresholds and expiry handling. Changes apply to new runs; existing runs
keep the policy they were analysed with.

---

## Recommendation rules

Every rule starts at **REVIEW**. Categories only escalate when the evidence is present.

| Category | Required evidence |
| --- | --- |
| **KEEP** | Recent matching log traffic in the observation window, a linked and documented change record, a known owner, not expired, no conflicting change data |
| **REVIEW** | Default. Used whenever evidence is missing, logs do not share the inventory identity space, coverage is too short, there are conflicts, or approvals are outstanding |
| **DISABLE** | No matching traffic for the full observation window, last hit older than the threshold, business confirmation recorded, no conflicts |
| **DELETE** | All DISABLE evidence plus recorded deletion approval, obsolescence confirmation, and a completed disable-and-monitor period with no traffic after disabling |

**Zero traffic alone never triggers DISABLE or DELETE.** If a supplied log file does not contain a
single identifier from the inventory, the platform records that the identity space did not match
and treats absence as *no evidence*, not as proof of inactivity. Inventory hit counters are never
presented as log event counts.

Matching hierarchy (the method and confidence are stored per rule and shown in the UI):
rule UID → rule number + device → rule name + device → explicit mapping in comments. Similar
names are never merged; ambiguous keys produce no match plus an explanation.

---

## AI explanations (local only)

Ollama generates plain-language review notes from **aggregated evidence only** - never raw logs.
The deterministic engine decides the category; the model may not change it. Responses are rejected
when they invent IP addresses, contradict the measured traffic (for example "no hits" when events
exist), claim documentation that is not recorded, or drift to another category. Rejected narrations
fall back to the deterministic text.

Configure model and URL on the Settings page or with `FIP_OLLAMA_MODEL` / `FIP_OLLAMA_URL`.
On CPU-only hardware, `qwen2.5:1.5b` takes about 10 seconds per rule; batch narration runs in a
background job so the portal stays usable.

---

## n8n orchestration (optional)

`n8n/docker-compose.yml` runs a dedicated n8n container (`fip-n8n`) on port 5679, separate from any
existing n8n instance. Six workflows are imported and activated by `setup.bat`:

| Workflow | Webhook | Purpose |
| --- | --- | --- |
| FIP - 01 File Ingestion | `POST /webhook/fip/ingest` | Validate a file dropped into `uploads/`, map columns, store metadata |
| FIP - 02 Firewall Rule Correlation | `POST /webhook/fip/analyze` | Create a run: match rules to changes and log events |
| FIP - 03 Traffic Analysis | `POST /webhook/fip/traffic` | Return traffic metrics and identity-space coverage for a run |
| FIP - 04 AI Review | `POST /webhook/fip/ai` | Queue local narration and validation |
| FIP - 05 Report Generation | `POST /webhook/fip/report` | Generate Excel/PDF report sets |
| FIP - 06 Re-Analysis Comparison | `POST /webhook/fip/compare` | Compare a baseline run with a newer run |

Example:

```bash
curl -X POST http://127.0.0.1:5679/webhook/fip/analyze \
  -H "Content-Type: application/json" \
  -d '{"rules_upload_id":1,"changes_upload_id":2,"logs_upload_id":3,"label":"Weekly review","ai_explanations":false}'
```

The backend endpoints under `/api/n8n/*` require the `X-API-Key` header. The key is generated once
into `config/n8n_api_key.txt` and injected into `n8n/.env`; it is never hardcoded or committed.

To rebuild the workflow JSON after editing `n8n/build_workflows.py`:

```bash
python n8n/build_workflows.py
docker exec fip-n8n n8n import:workflow --separate --input=/workflows
```

---

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| `FIP_HOST` / `FIP_PORT` | `127.0.0.1` / `8080` | API bind |
| `FIP_DATA_DIR` | project root | Relocates uploads, caches, reports and DB (used by tests) |
| `DATABASE_URL` | `sqlite:///database/fip.db` | PostgreSQL DSN supported by SQLAlchemy |
| `FIP_AUTH_ENABLED` | `false` | Require local login |
| `FIP_MAX_UPLOAD_MB` | `512` | Upload size limit |
| `FIP_CHUNK_SIZE` | `200000` | Log streaming chunk size |
| `FIP_OLLAMA_URL` | `http://127.0.0.1:11434` | Local model endpoint |
| `FIP_OLLAMA_MODEL` | `qwen2.5:1.5b` | Model name |
| `FIP_AI_ENABLED` | `true` | AI narration on/off |
| `FIP_AI_MAX_RULES` | `400` | Batch narration cap |
| `FIP_N8N_API_KEY` | generated | Overrides the stored n8n key |

Policy defaults live in `backend/config.py` (`DEFAULT_POLICY`), can be overridden in
`config/default_policy.json`, and are edited from the Settings page (stored in
`config/settings.json`). Guard rails clamp the observation window (7-730 days) and keep the
last-hit threshold at least as long as the window.

### Data and reset

- `uploads/` original files, `processed/` gzipped normalised caches, `reports/` generated files,
  `database/fip.db` SQLite database (WAL mode).
- Raw log rows are **not** persisted; only aggregates are stored.
- To reset the local demo: stop the API, delete `database/fip.db*`, clear `uploads/*`, `processed/*`
  and `reports/*`, then re-run the import/analysis from the portal.

### Tests

```bash
.venv\Scripts\python -m pytest -q
```

The suite runs against a temporary `FIP_DATA_DIR` and never touches portal data. It covers parsing
and section-heading detection, the matching hierarchy and ambiguity rules, all four recommendation
gates (including zero-traffic safety), the full pipeline on real and synthetic files, independent
recomputation of every rule's traffic counts from the CSV, Excel/PDF generation with 28+ columns,
and API smoke tests.

---

## Troubleshooting

| Symptom | Resolution |
| --- | --- |
| `start.bat` says the API did not become healthy | Check `logs/server.log`; run `health_check.bat`; ensure port 8080 is free |
| Portal loads but API calls fail | The API must be running; check `http://127.0.0.1:8080/api/health` |
| Wrong recommendation counts after changing settings | Policy applies to new runs; start a new analysis |
| All rules are REVIEW on the real sample logs | Expected: the supplied log workbook uses different rule UIDs and does not share the inventory identity space. The platform refuses to treat that as zero-traffic evidence |
| AI narration slow or unavailable | Check Ollama is running (`ollama list`), the model name matches settings, and see `/api/health` for AI status |
| n8n webhook 404 | Container must be running and workflows active: `docker compose -f n8n/docker-compose.yml up -d`; `docker exec fip-n8n n8n list:workflow` |
| n8n cannot reach the API | Keep the API on 127.0.0.1; Docker Desktop forwards `host.docker.internal`. Verify with `docker exec fip-n8n wget -qO- http://host.docker.internal:8080/api/health` |
| Port 5678 already used | This project uses 5679 and a separate container, so an existing n8n is untouched |
| Excel/PDF download missing | Reports are written to `reports/`; check the run has completed and the file is not open in Excel |

Logs: `logs/server.log` (API), `logs/platform.log` (application), `docker logs fip-n8n` (n8n).

---

## Limitations

- CPU-only host: AI uses a 1.5B model and is intended for drafting narrative, not analysis.
- The supplied real log workbook cannot validate recommendations against the supplied inventory
  because their rule identity spaces differ; the synthetic dataset is clearly labelled and exists
  solely to prove the calculations.
- PostgreSQL support is configuration-level and has not been exercised on this machine.
- n8n webhooks are unauthenticated but bound to localhost; the backend API key protects the
  `/api/n8n/*` endpoints.

## Single-prompt review (new)

The customer can drive the entire platform from one n8n workflow, **FIP - 00 Full Review
(one prompt)**. It accepts a prompt, runs ingestion, correlation, traffic analysis, local AI
narration and the full report set, waits for completion, and returns category counts plus
clickable portal links.

Two ways to start it:

1. **Form:** open http://127.0.0.1:5679 and run **FIP - 00 Full Review (one prompt)**, or use
   the form URL `http://127.0.0.1:5679/form/fip/review-form`.
2. **Webhook:** `POST http://127.0.0.1:5679/webhook/fip/review` with `{"prompt": "..."}`.

Prompt keys (all optional except a demo or file reference):

```
demo                                   use the fictional demo dataset
label: Weekly customer review          run label shown in the portal
model: qwen2.5:3b                      per-run model (must be installed)
ai_limit: 20                           number of rules to narrate
rules: uploads/firewall_rules/x.xlsx   existing upload
changes: uploads/change_records/y.csv
logs: uploads/firewall_logs/z.csv
no ai                                  skip AI narration
```

Example: `demo label: Customer demo model: qwen2.5:1.5b ai_limit: 8`.

To stop AI or reports in a structured call, send `{"prompt": "demo", "ai": false,
"reports": false}`. The same job can also be started directly with
`POST /api/n8n/full-review` (header `X-API-Key`) and polled at
`GET /api/n8n/full-review/{run_id}`; both are what the workflow uses.

## Chat demo inside n8n (no editor)

The workflow **FIP - Chat Demo & Model Control** serves a hosted chat page directly from
n8n:

**http://127.0.0.1:5679/webhook/fip-chat/chat**

Type `demo` to run the complete fictional review. The reply contains the run id, category
counts, matched events, AI/model, report count and clickable portal links. The chat also
supports:

- `help` — commands and examples
- `models` — installed local models and the current default
- `connection` — backend, portal and Ollama status
- `set model <name>` — change the default LLM
- `test model <name>` — live model test without changing the default
- `status <run_id>` — progress and counts for a run
- `no ai` / `no reports` — faster demo

This means the customer demo and the model/connection check do not require opening the n8n
workflow editor. The chat workflow passes messages to `POST /api/n8n/chat`, which uses the
same deterministic pipeline, policy engine, AI validation and reports as the portal.

## Changing the AI model

Open **Policy & Settings → Local AI**. The model field lists every model installed in Ollama
and also accepts a typed name. **Refresh** re-reads the installed list, **Test this model
(before saving)** sends a live prompt using the unsaved model, and **Save AI settings** makes
it the default. To install another model first run `ollama pull <model>` in a terminal.
The n8n prompt can override the model for one run with `model:` without changing the default.

## Accepting a rule recommendation

Every rule row in **Firewall Rule Review** has an **Accept** button, and the rule detail page
has **Accept recommendation**. Acceptance is stored as `review_accepted` with the reviewer
name, time and note in the audit trail. It records that a human reviewed the rule; it does
**not** change the policy category. Only the dedicated business/deletion approvals and
disable-monitoring evidence can move a rule to DISABLE or DELETE.

## Customer demo data

The `samples/demo/` files are fictional but use the customer's exact headers:
`Firewall_Rule_Inventory_DEMO.xlsx`, `ServiceNow_Change_Tasks_DEMO.xlsx` and
`Firewall_Logs_DEMO.csv` (3,585 events). They are generated on demand by
`backend/services/demo_data.py` and cover KEEP, all REVIEW variants, DISABLE and DELETE.
The demo run records labelled fixture approvals so all four categories appear:
23 KEEP, 27 REVIEW, 6 DISABLE and 4 DELETE. See `docs/DEMO.md` for the walkthrough.

## Project layout

```
backend/        FastAPI app, services, analytics, recommendation engine, reports, jobs
frontend/       React + TypeScript portal (Vite)
n8n/            docker-compose, generated workflow JSON, workflow builder
scripts/        synthetic data generation, demo seeding, run cleanup
samples/        supplied POC workbooks and labelled synthetic logs
tests/          pytest suite (temporary database)
documentation/  architecture, recommendation rules, operations
start.bat / stop.bat / setup.bat / health_check.bat
```
