@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Firewall Rule Intelligence Platform - health check

echo ============================================================
echo  Health check
echo ============================================================

echo.
echo [API]    http://127.0.0.1:8080/api/health
curl -s http://127.0.0.1:8080/api/health
echo.

echo [Portal] http://127.0.0.1:8080/
curl -s -o nul -w "HTTP %%{http_code}\n" http://127.0.0.1:8080/
echo.

echo [n8n]    http://127.0.0.1:5679/healthz
curl -s -o nul -w "HTTP %%{http_code}\n" http://127.0.0.1:5679/healthz
curl -s -o nul -w "n8n port 5679 reachable\n" http://127.0.0.1:5679/healthz
echo.

echo [Ollama] http://127.0.0.1:11434/api/tags
curl -s -o nul -w "HTTP %%{http_code}\n" http://127.0.0.1:11434/api/tags
echo.

echo [Docker]
where docker >nul 2>&1
if errorlevel 1 (
  echo Docker not installed - n8n workflows unavailable.
) else (
  docker ps --filter name=fip-n8n --format "fip-n8n: {{.Status}}"
)
echo.

echo [Database]
if exist "database\fip.db" (
  for %%A in ("database\fip.db") do echo database\fip.db  %%~zA bytes
) else (
  echo database\fip.db not created yet - start the portal once.
)
echo.
echo Tip: open /api/health in a browser for models, policy and auth status.
echo.
pause
